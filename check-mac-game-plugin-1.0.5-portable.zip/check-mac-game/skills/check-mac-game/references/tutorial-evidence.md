# How-to and Tutorial Evidence

Read this reference before answering any CrossOver result or a result with a
possible active community workaround. The goal is to answer “how do I play it?”
with a current reproducible route, not merely a rating.

## Search before writing

Run one batched how-to search after the title and primary verdict are resolved:

1. Check title-specific CodeWeavers Tips, recent user feedback, linked gameplay
   videos, and current forum posts.
2. Search Bilibili platform-wide using the exact title and verified aliases with
   combinations of `Mac`, `CrossOver`, `Preview`, `DXVK`, `D3DMetal`, `DXMT`,
   `MoltenVK`, `Vulkan`, `补丁`, and `教程`. Also run the dedicated search for
   `我是艾文喵` UID `687912805`; this is an additional source, not an allowlist.
3. Check current title-specific MacGamingDB entries and any video or original
   project linked from a recent compatibility report.

Verify the exact game/edition, date, device, macOS, CrossOver version, backend,
patch version, launcher, and whether the source actually reaches gameplay. A
title-only listing, install success, generic CrossOver guide, or unrelated PC
tutorial is not a working Mac route.

## Classify each route

- `官方步骤`: current CodeWeavers title-specific recipe or support instruction.
- `社区方案（可复现）`: current title-specific demonstration with enough versioned
  steps to reproduce and visible gameplay.
- `相关实测`: gameplay is visible but one or more setup details are missing. Cite
  it and summarize what is known; do not manufacture the missing steps.
- `旧方案/排障线索`: stale, different-version, or incomplete report. Keep it out
  of the main route unless no current route exists.

Within a reproducible community route, distinguish:

- `该社区方案必需`: the source explicitly reports failure without this component
  and success with it, or the current tutorial's tested path depends on it.
- `实测设置`: used by the tester but not proven necessary.
- `可选优化`: affects convenience or performance after the game already runs.

“Unofficial” describes provenance, not necessity. Do not omit an unofficial patch
that the demonstrated route requires. Instead say what fails without it, what it
modifies, the tested environment, and how to back up and revert it.

## Download and modification safety

- Prefer the original source repository and tagged release over URL shorteners,
  cloud mirrors, affiliate pages, or repacks.
- If a tutorial links only a mirror, inspect redirects and metadata when safe,
  then state that the binary's provenance is unverified. Do not present the mirror
  as trusted merely because the video works.
- A patch that replaces files inside `CrossOver.app` affects CrossOver globally,
  not just one bottle. State that scope, back up the original file, and expect a
  CrossOver update to overwrite or invalidate the patch.
- A bottle configuration change is bottle-scoped. A game executable hex edit is
  game-build-specific; back up the executable and expect verification or updates
  to restore it.
- Never link piracy, cracked executables, activation bypasses, or shared commercial
  installers. A legitimate open-source patch may be linked to its original release.

## Answer order

In `怎么玩`, put the best-supported working route first:

1. Name the exact route and tested CrossOver version.
2. List required components and actions in execution order.
3. Separate optional cache/performance work from launch requirements.
4. For Chinese answers, add a qualifying Bilibili tutorial before tutorials on other platforms. Put `发布于 YYYY-MM-DD` directly beside every tutorial link. If the Bilibili source only demonstrates gameplay, label it `B站实机演示（非完整教程）`, place it first among media links, and retain the reproducible steps from the detailed guide or original project.
5. Put alternatives and older reports after the primary route.

Then write `适用设备`, `关键限制`, user feedback, confidence, and dated sources.
