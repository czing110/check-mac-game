# Share Card Export

Read this reference only after a non-ambiguous single-title compatibility result
has a final practical verdict. Recommendation lists do not receive cards in v1.

## Eligibility and content

Generate a card only when the title is resolved and at least one usable source
supports the result. Do not generate one for candidate-selection answers, a
completely offline result, or an unresolved title.

The 1080x1440 card is an editorial review poster. The current user-facing
directions are the entries returned by:

```bash
python3 scripts/render_share_card.py --default-set
```

That command is the single source of truth for the style set and its count. Do not
assume a fixed number of directions, and do not add or drop a direction anywhere
else without updating the renderer's style table. Each direction is described in
[Poster styles](#poster-styles) below.

They share the same dynamic content contract. It contains:

- game title;
- primary practical conclusion;
- five-star rating or `未评级`;
- an official game key visual or screenshot when available;
- `check-mac-game｜输入游戏名，查询 Mac 游戏兼容性` promotion line.

Every user-facing poster title must read `我在Mac上玩《游戏名称》`. Visually separate
the smaller `我在Mac上玩` prefix from the dominant bracketed game name. Prefer the
bracketed game name on one line: when it does not fit, first shrink the title
type (shrink-to-fit), and only when a single line is still impossible let the
break fall between `我在Mac上玩` and `《游戏名称》` — the prefix occupies its own
line and the bracketed game name occupies the next line as an unbreakable unit
(`white-space: nowrap` on the bracketed span). Never break inside `《…》`, never
split a word, hyphen, or numeral away from its name, and never strand a lone
`》` at the start of a line. Emphasize only the game name, compatibility
conclusion, and rating. Do not place review copy, play instructions, device
details, key-limit lists, confidence, query dates, source lists, user-feedback
quotes, tutorial links, or download promotions on the image; those details
remain in the accompanying compatibility answer.

Content text follows a deliberate alignment rule: the `type-monument`,
`cover-story`, and `glitch-sys` directions use one consistent left edge for the
`我在Mac上玩` prefix, game title, compatibility conclusion, rating, and promotion
line. Each remaining direction keeps its title, conclusion, and rating grouped
within its own alignment system. Decorative motifs and image composition may
remain independent of that content axis.

For a method-specific result that requires Preview, configuration changes, or a
third-party component, keep that practical method as the main conclusion. If a
numeric database rating exists, pass `--rating-context standard` so the small
caption reads `标准兼容评级`; the rating must not look like it scores the
third-party route. Otherwise use `--rating-context primary`.

For every concrete, resolved single-game result, generate one card per approved
direction listed by `--list-styles` and put them behind one aggregate share page.
Do not generate a card or page for candidate-selection, completely offline, or
unresolved-title results.

## Visual assets

Use assets in this order:

1. Prefer an official publisher/developer press kit, official product page, or
   official store page for key art and screenshots.
2. Prefer a transparent official character PNG. A clean, clearly licensed press
   image with a simple background is the next choice.
3. If the character source is not transparent and the host can edit images, make
   one background-removal attempt. Preserve the character's face, costume,
   silhouette, and colors; remove logos and background only. The renderer also
   cleans connected light/checkerboard backgrounds.
4. If the subject cannot be isolated reliably, omit the character. Never insert
   an unrelated character, fan art of unclear provenance, or an unofficial logo.

Treat character isolation as optional enhancement, never a rendering dependency.
If the host has no image-editing capability, or the single removal attempt fails,
omit `--character` and recompose with the official key art using crop,
`object-position`, masks, gradients, and negative space. Do not block export,
substitute a generated copyrighted character, or show a fake checkerboard cutout.

Game art is runtime evidence/artwork. Save it under
`artifacts/check-mac-game/assets/`, not inside the Skill or GitHub repository.
Keep its source URL in working evidence so the answer can attribute the source.

The renderer typesets all text and stars in HTML/CSS, then captures the fixed
1080x1440 viewport as PNG. Never ask an image model to draw text, ratings, logos,
UI, glass, or a replacement game character.

### Mandatory artwork ratio and crop pass

Before rendering, inspect and record each candidate image's pixel width, pixel
height, aspect ratio, source URL, and intended focal point. Do not select an image
only because it is official or visually attractive. Reject thumbnails and any
asset that must be enlarged more than roughly 1.5× along the dimension used by
the final crop when a larger official source is available.

Search for multiple official assets when the layouts require incompatible crops.
Prefer up to three complementary files rather than forcing one image into every
card:

- **Portrait/full-bleed:** use 3:4 or 2:3 key art, preferably at least 1080×1440,
  for `glitch-sys`, `frosted-band`, `macos-desktop`, and other tall backgrounds.
- **Landscape/window/band:** use 16:9, 3:2, or wider artwork, preferably at least
  1600×900, for `type-monument`, `cover-story`, `imac-aluminum`,
  `about-this-mac`, `message-tube`, `play-it-mac`, `running-macos`,
  `monitor-terminal`, `industrial-plate`, `letterbox`, `serif-study`, `polaroid`,
  and `blur-stage`.
- **Centered/square crop:** use a near-square image or an image with the main
  face/character/action safely centered, preferably at least 1000×1000, for
  `circle-window` and any circular or tightly masked treatment.

When a direction from `--list-styles` is not named above, infer its group from the
crop shape its template rules actually apply before assigning an image.

These groups are crop requirements, not a license rule: every selected file must
still come from the official-source order above. When only one official image is
available, assign it only to layouts it can survive, adjust that layout's
`background-position`/`object-position`, and use a conservative contained or
letterboxed treatment for incompatible layouts. Never crop a face, essential
character silhouette, game logo, or focal action merely to fill the box.

Prefer clean screenshots or key art without embedded marketing copy when text
will be overlaid. A source dominated by a large logo is unsuitable for a shallow
horizontal band because the crop can become “logo only.” Search the official
press kit, publisher media gallery, and official store screenshot set for a
better-oriented alternative.

After rendering, inspect the artwork crop separately from the text audit at full
size and thumbnail size. Verify that the intended subject remains recognizable,
no face or essential action is cut at the frame edge, no low-resolution softness
is obvious, and the same focal point is not blindly reused across portrait,
landscape, and circular styles. If a crop fails, change the source image first;
change the crop position second; use a different layout treatment third.

## Poster styles

The reusable HTML template in `assets/share-card-template-v2.html` is the design
source. It implements every approved reference direction listed by
`--list-styles`. Use `type-monument` by default and offer every approved direction
when the user asks to choose:

- `type-monument` — giant typographic motif, black field, narrow monochrome image
  band, and a red game title. This is the default.
- `cover-story` — pale editorial cover with a masthead, image window, serif title,
  and restrained red accents.
- `glitch-sys` — dark system interface with red/cyan channel offsets, signal
  tearing, scanlines, a monospaced HUD, and a boxed conclusion.
- `imac-aluminum` — an aluminum iMac construction using a rounded monitor with
  chin, trapezoid stand, silver foot, and a centered compatibility readout.
  Its geometry uses `aspect-ratio: 3 / 4`, `container-type: inline-size`, and
  `cqw` units so the device scales with the poster width.
- `about-this-mac` — the visual language of the macOS “About This Mac” window:
  a pale gray field, compact MacBook artwork frame, and hairline-separated rows
  for platform, practical conclusion, and rating. Its poster uses
  `aspect-ratio: 3 / 4`, `container-type: inline-size`, and `cqw` type; add or
  remove specification rows only by duplicating or deleting one `.m6-srow`.
- `message-tube` — the “横幅信筒” direction: two solid color fields frame a
  single 24cqw-high horizontal artwork band, clamped by gold hairlines. Its
  image lives on `.m3-band`; change the band height with `height` and the line
  color with `border-top-color` / `border-bottom-color`.
- `frosted-band` — the “磨砂横带” direction: a full-bleed game image sits
  behind a lower translucent band beginning at `top: 56%`. Keep
  `backdrop-filter: blur(18px)` (and its WebKit prefix) to preserve the frosted
  image treatment; tune the blur value or the band start position in the m7
  rules without changing the text contract.
- `circle-window` — the “圆窗” direction: a 44cqw circular crop of the key art
  is centered inside two gold hairline rings (`.m8-ring` at 48cqw and
  `.m8-ring2` at 56cqw). The ring layers use `border-radius: 50%`; duplicate
  `.m8-ring` and change its size or border opacity to add another ring.
- `play-it-mac` — the “PLAY IT / on Mac.” direction: a compact black 3:4 card
  with a pastel gradient title, a macOS traffic-light window, and a blue
  conclusion pill beside the rating. The window artwork uses `cover` and a
  centered focal position so any supplied key art remains contained.
- `running-macos` — the “RUNNING ON macOS · 窗口悬浮” direction: two rotated
  translucent ghost windows sit behind a larger macOS traffic-light window;
  the main window carries the key art and a compact conclusion/rating row.
- `monitor-terminal` — the “监控终端” direction: a dark blue-black surveillance
  feed with scanlines, targeting corners, a command-terminal overlay, a bright
  compatibility verdict box, and a five-segment readiness meter.
- `industrial-plate` — the “工业铭牌” direction: a charcoal metal plate with
  yellow hazard stripes, a grayscale key-art inspection window, stencil lettering,
  rivets, and a hard-shadow verdict plaque with barcode metadata.
- `terminal-app` — the “Terminal.app” direction: a deep-black macOS terminal
  window with traffic lights, frosted glass, command lines, and a centered result chip.
- `macos-desktop` — the “macOS 桌面” direction: game art becomes the wallpaper,
  framed by a frosted menu bar, a large compatibility notification, and a translucent Dock.
- `letterbox` — the “T06 LETTERBOX 宽银幕” direction: a 30%-high horizontal
  artwork strip sits between two black typographic fields. Preserve the darkened
  left/right edge gradients so arbitrary artwork merges into the field; tune the
  reusable gold accent and crop without introducing external font dependencies.
- `serif-study` — the “09 衬线白 / Serif Study” direction: a pale book-page
  field uses bold Songti for the Chinese title, a Didot/Bodoni italic Latin line,
  a narrow framed illustration, restrained red accents, and a lightly sunken
  image shadow (`0 .8cqw 2.4cqw`).
- `polaroid` — the “T08 POLAROID 拍立得” direction: a warm dark wall holds a
  slightly rotated white photo with an oversized lower border, two translucent
  tape strips, a handwritten-style game/verdict note, and gold rating accents.
  Its inner frame is approximately 4:3; portrait-only artwork automatically uses
  `contain` rather than sacrificing the subject to an aggressive crop.
- `blur-stage` — the “T05 BLUR STAGE 焦外舞台” direction: the same artwork is
  enlarged beyond the canvas and blurred at 26px as a dark atmospheric backdrop,
  while a clear 44%-high foreground card carries the focal image. Keep the
  negative inset so blur never exposes a pale edge, and retain the large shadow
  plus one-pixel highlight that separates the clear card from its background.

Do not merge these visual languages into another hybrid. The title must always
read `我在Mac上玩《游戏名称》`, with both the prefix and bracketed name present.
Keep the conclusion and rating in a compact visual group and preserve sufficient
contrast at social-feed thumbnail size.

Fit oversized decorative motifs and repeated outline words from the browser's
actual rendered font metrics. Do not rely on one fixed font size: long status
words such as `CROSSOVER` must shrink until the complete first and last glyph are
inside the poster. Include these decorative words in the DOM overflow audit.

The browser capture is the only accepted output for the approved poster set
because it reproduces the reference layout, masks, channel effects, and exact
typography. If capture is unavailable, stop before creating any user-facing
poster. Do not export Pillow, SVG, or placeholder substitutes. Intermediate HTML
is inspection-only and is never a deliverable poster.

### Mandatory post-render text review

Do not deliver a share card immediately after the renderer exits. Inspect the
finished PNG or SVG at full size and again at roughly 25% thumbnail size. Verify
that the game title, practical conclusion, and stars are all readable; no glyph
is cropped; no line escapes its panel; no busy artwork obscures text; text blocks
do not collide; promotional/footer text remains readable; text-bearing surfaces
do not create unexplained dead
zones far wider than their content; and small labels retain sufficient contrast. Treat
thumbnail readability as the acceptance standard because the card will normally
be viewed in a social feed.

As part of the same review, verify the title-wrapping rule: prefer the bracketed
game name on one line (shrink-to-fit first); if it must wrap, the break between
`我在Mac上玩` and `《游戏名称》` is the only acceptable line break inside the
title block. A bracketed game name must never split across lines, lose its
closing `》`, break a word or numeral in the middle, or overflow its panel
horizontally.

For rotated or perspective text treatments, the text container and its backing
surface must share the same transform origin and coordinate system. A matching
rotation angle alone is insufficient: mismatched origins can move legible text
outside the backing's clipped visible area even when rectangular overflow checks
pass.

If any check fails, revise the copy or layout and render again. Prefer shortening
the review, allowing safe line breaks, enlarging the type, widening its opaque
backing surface, or moving artwork before reducing body text. Never solve overflow
by shrinking essential text below a comfortably readable social-card size. When
the host cannot inspect raster output, run the template's deterministic DOM text
overflow check and use the conservative opaque-panel layout; disclose that only
the structural check was possible rather than claiming a visual review passed.

### Image-generation capability

Image generation is not required for either rendering path. When it is
unavailable, use official key art and any already-transparent official character;
HTML/CSS still produces the complete poster and glass. When image generation is
available, it may make one background-removal attempt or create a custom
text-free background only when the user explicitly requests one. Never generate
glass, text, stars, logos, UI, or a replacement copyrighted character. A supplied
custom background may be passed with `--background`, but official key art remains
preferred.

## Renderer call

Resolve the script path relative to this Skill directory:

```bash
python3 scripts/render_share_card.py \
  --game "GAME" \
  --verdict "PRIMARY CONCLUSION" \
  --status native|rosetta|crossover|third_party|unavailable|unknown \
  --review "ONE CONCRETE EDITORIAL SENTENCE" \
  --method "PRACTICAL PLAY METHOD" \
  --rating 1 \
  --rating-context primary|standard \
  [--key-art "/absolute/path/to/official-key-art.jpg"] \
  [--character "/absolute/path/to/character-cutout.png"] \
  [--background "/absolute/path/to/subtle-background.png"] \
  [--style STYLE_ID] \
  [--format png] \
  --json
```

Valid `--style` values are the ids printed by `scripts/render_share_card.py
--list-styles`; read them at call time rather than hard-coding a list here.

Omit `--rating` when no numeric rating exists. The renderer writes into
`artifacts/check-mac-game/share-cards/` under the current workspace by default,
prints structured metadata, and returns the ready Markdown link. The default
style is `type-monument`. It writes the bundled HTML/CSS template and captures
it with an available Chrome, Chromium, or Edge headless browser. Set
`CHECK_MAC_GAME_BROWSER` only when the browser executable is in a nonstandard
location. Run `scripts/portable_preflight.py` before generating the first final
poster; a false `approved_poster_ready` means the agent must report that poster
generation is unavailable and must not publish any substitute image.

Use `--format html --allow-nonfinal-html` only for local layout inspection. This
writes a self-contained 1080×1440 HTML inspection file, not a shareable poster.
Its embedded audit records text overflow, block collisions, verdict centering,
backing proportions, and transform-origin alignment in `body[data-text-audit]`;
do not describe this structural audit as a finished-image visual review.

## Aggregate share page

Build the user-facing page after one poster HTML file exists for every style
returned by `--list-styles`. Pass one `--card` per poster, in the same order as
that list:

```bash
python3 scripts/build_share_gallery.py \
  --game "GAME" \
  --output "/absolute/path/to/share-page/index.html" \
  --card "/absolute/path/to/card-1.html" \
  --card "/absolute/path/to/card-2.html" \
  --card "/absolute/path/to/card-N.html"
```

The count of `--card` arguments must equal the count reported by
`--list-styles --json`. Do not pad the page with a repeated card and do not
publish with fewer previews than that count.

The page contains only the game title, one responsive preview per card, and one
`下载海报` button under each preview. It must not show style names, comparison
copy, audit badges, source lists, or compatibility explanations. The button
is a short content-width pill with a translucent frosted-glass treatment, and
inlines the selected sibling PNG or JPG. If no raster image file exists, it
must stop instead of publishing a placeholder, SVG, HTML document, or another
style's image. Before writing the page, hash every raster download and reject
duplicates across different poster cards. Inline data URLs make the button trigger
a direct image download even when the page is opened from `file://`.

Place the returned aggregate-page link inside the final `### 分享与反馈` block,
above the feedback form link. When the CrossOver download footer is emitted by
its separate rate gate, place that footer on the first line below the H2 result
heading. The compatibility feedback link remains the final line of the full
answer.
