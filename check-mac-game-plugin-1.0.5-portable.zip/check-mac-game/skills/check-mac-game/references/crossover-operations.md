# CrossOver Operations

Use this reference whenever a compatibility answer includes CrossOver setup or
troubleshooting. It summarizes current CodeWeavers documentation rather than
game-specific community recipes. Last reviewed: 2026-08-25.

## Safe baseline

1. Prefer the game's listed CrossOver entry. A listed install profile can select
   installation details and required dependencies; an unlisted application has no
   such defaults.
2. Keep the game in its own bottle. Graphics choices, synchronization options,
   registry changes, dependencies, and patches can affect every application in
   that bottle.
3. On CrossOver 26 or later, start with the `Auto` graphics selection. Auto uses
   CodeWeavers' per-game backend database and falls back to Wine's `wined3d` when
   the database has no selection. This is the baseline test, not proof that Auto
   is best for every game. A current, reproducible community route may instead
   require a forced backend or patch; present that as a separate route and follow
   its exact versioned combination rather than Auto.
4. Before changing a working or valuable bottle, archive it. Change one setting at
   a time and compare launch, rendering, input, cutscenes, and the required game
   modes. Revert changes that do not help.
5. When purchase risk matters, use the current CrossOver trial with the user's
   exact game build and launcher. A database rating cannot guarantee a different
   chip, macOS, launcher, or game update.

## Graphics choices in CrossOver 26+

The graphics choices apply bottle-wide. Do not describe them as independent
performance switches to enable together.

| Choice | Official role | Advice boundary |
|---|---|---|
| `Auto` | Selects a per-game backend from CodeWeavers' database; otherwise uses `wined3d`. | First test for a listed game. |
| `DXMT` | Metal-based Direct3D 11 implementation. | Force only for a dated title-specific recipe or a controlled comparison. |
| `D3DMetal` | Game Porting Toolkit translation layer for DirectX 11 and 12. | Do not recommend merely because a game uses DX12; require title-specific evidence. |
| `DXVK` | Vulkan-based translation layer for Direct3D 10 and 11. | “Enable DXVK” is not universal Mac advice and is not suitable evidence for a DX12-only path. |
| `Wine` | Wine's `wined3d` implementation. | A fallback/forced choice, not shorthand for “no acceleration.” |

Related options:

- `DLSS` through MetalFX only takes effect when the game also enables DLSS, and
  CodeWeavers documents it for D3DMetal and DXMT. Do not promise improvement;
  some games perform worse.
- `MSync` is a Mach-semaphore synchronization option. CodeWeavers says some
  applications improve and others show no difference. Treat it as a sourced
  game-specific setting or a one-at-a-time experiment.
- High Resolution Mode disables pixel doubling and reports 192 DPI. Some
  applications render incorrectly, so it is a display choice rather than a
  general performance recommendation.
- Performance Enhanced Graphics (CSMT) has been enabled by default since
  CrossOver 23.x and no longer has a visible toggle. Do not tell current users to
  enable it.
- Do not mention `ESync` as a current UI step unless the cited CrossOver version
  and source explicitly expose or require it.

## How to turn source notes into instructions

Classify each item before writing `怎么玩`:

- `官方配置`: a current, title-specific CodeWeavers install profile, Tips entry,
  or support recipe. State the exact applicable CrossOver version.
- `实测建议`: a dated game-specific community test. Phrase it as “该记录在
  CrossOver X 上使用 Y 成功”，not “必须开启 Y”. If it is over 18 months old,
  explicitly call it an old record and do not put it in the baseline steps.
- `排障尝试`: an inference-supported comparison after the baseline fails. Say
  what symptom it targets, change one item, and make clear that success is not
  established for the user's device.

Do not promote a raw note to a required step merely because it uses imperative
language. CodeWeavers customer feedback and AppleGamingWiki notes report what a
tester did; they do not define CrossOver defaults. Never merge settings from
different CrossOver versions or sources into one recipe without a single test
that verifies the combination.

An unofficial component can nevertheless be required for a specific demonstrated
community route. If the source shows that the game fails without it and reaches
gameplay with it, call it `该社区方案必需`, include it in the main steps, and keep
its unofficial status, modification scope, backup/revert path, tested environment,
and original release source visible. Do not generalize that requirement to other
CrossOver versions.

## Official sources

- [CrossOver Mac 26 advanced settings](https://support.codeweavers.com/en_US/advanced-settings-in-crossover-mac-26) — graphics choices, DLSS, MSync, high-resolution mode, and CSMT; modified 2026-02-10.
- [CrossOver Mac user guide](https://support.codeweavers.com/user-guides/crossover-mac-user-guide) — listed/unlisted installs, bottles, archives, trial, and troubleshooting; modified 2026-05-06 when reviewed.
- [Editing bottle registry keys](https://support.codeweavers.com/common-actions/editing-bottle-registry-keys) — registry changes are bottle-wide and separate bottles are recommended; modified 2024-06-27.
