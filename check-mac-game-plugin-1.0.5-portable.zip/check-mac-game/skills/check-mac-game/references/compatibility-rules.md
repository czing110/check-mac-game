# Compatibility Rules

## Source priority

1. Current publisher pages, official stores, and platform metadata establish whether an official macOS build exists.
2. The CodeWeavers Compatibility Center macOS review establishes current CrossOver rating, tested version, and test date.
3. AppleGamingWiki supplies Apple-silicon, Rosetta 2, device-test, anti-cheat, online-mode, and workaround details.
4. MacGamingDB can supplement Apple-silicon, CrossOver, Parallels, GPTK, and performance details when a title-specific report identifies its hardware, method, and test date.
5. Porting Kit can show that a community-maintained Wine wrapper or installation recipe exists, but the listing alone does not prove that the current game, macOS, or CrossOver version works.
6. Current title-specific Bilibili videos can supplement setup, CrossOver/GPTK graphics configuration, troubleshooting, and gameplay demonstrations. Use them only after a primary route is verified, unless the user specifically requests possible workarounds.
7. Other community reports can fill a gap but cannot overrule newer official evidence without a clear, dated reproduction.

Steam platform metadata is authoritative only for the Steam build. A negative Steam flag cannot exclude a Mac App Store, GOG, Epic, or publisher-direct Mac release.

## User-facing Steam links

Keep Steam metadata in the raw evidence used to identify the title and determine
whether that Steam build has a Mac version. In the final `来源` block, render the
collector's `answer_sources`, not raw `sources`:

- Include a Steam Store link only when `verdict` is `native_mac` and
  `native.steam_mac` is exactly `true`.
- Hide Steam links for CrossOver, third-party-plugin, virtual-machine,
  unavailable, and unknown results.
- Installing or purchasing the Windows build through Steam as part of a
  compatibility-layer route does not make its store page a native Mac source.
- Other exact evidence links remain visible. Do not remove Steam from the raw
  structured evidence because it is still needed for title and platform checks.

## Primary verdicts

## Fail-closed handling for incomplete retrieval

A transport, DNS, timeout, HTTP, parser, or rate-limit error is evidence that a
source could not be checked—not evidence that the title is absent or
unplayable. Before writing the headline, apply this gate:

- If a decisive source has a usable, dated result, classify from that result and
  retain any unrelated source errors as limitations.
- If all decisive sources failed or returned no usable evidence, the only valid
  classification is `unavailable_or_unknown / unknown / low`; write “暂时无法确认”.
- Use `not_playable` only when a source explicitly reports installation failure,
  launch failure, anti-cheat blocking, or another concrete incompatibility.
- Never convert `errors`, an empty `sources` list, a missing search match, or a
  collector timeout into “当前不可玩”. If the structured result says
  `verdict_detail: unknown`, the user-facing answer must not claim a negative
  verdict.

This gate applies again after any fallback web search and immediately before
rendering the final Markdown response.

## Required fallback recovery after collector failure

When the bundled collector returns source errors with no usable match, do not
stop at its empty result. Run a bounded web recovery pass before answering:

1. Resolve a Chinese/localized title through an official publisher or store
   page and record the canonical English title/slug it exposes.
2. Query CodeWeavers directly with that canonical title and inspect the exact
   `/compatibility/crossover/<slug>` page, not only a search-result snippet.
3. Query the official store page for platform metadata using the canonical title.
4. Treat a failed query, an empty search page, or a search miss as inconclusive;
   it is never proof that the CodeWeavers entry does not exist.

Only after these recovery queries have either produced evidence or independently
failed may the answer remain “暂时无法确认”.

Use these machine values and user-facing labels:

| `verdict` | `verdict_detail` | Chinese label | Meaning |
|---|---|---|---|
| `native_mac` | `apple_silicon_native` | 原生 Mac 版 | An official Apple-silicon-capable macOS build is confirmed. |
| `native_mac` | `official_mac_arch_unknown` | 原生 Mac 版 | An official macOS build exists but its binary architecture is not confirmed. |
| `native_mac` | `official_mac_rosetta` | 官方 macOS 版，需 Rosetta 2 | An official Intel Mac build runs through Rosetta 2. |
| `crossover` | `recommended` | 需要 CrossOver | Recent evidence rates it 4–5 stars or equivalent. |
| `crossover` | `limited` | 需要 CrossOver，但功能有限 | Evidence rates it 3 stars or equivalent. |
| `unavailable_or_unknown` | `not_playable` | 当前不可玩 | Recent evidence explicitly says it will not install, run, or pass required anti-cheat. |
| `unavailable_or_unknown` | `unknown` | 暂时无法确认 | Evidence is absent, stale-only, or irreconcilably conflicting. |
| `unavailable_or_unknown` | `ambiguous` | 需要确认具体游戏 | More than one title or edition plausibly matches. |

An official Intel Mac build belongs to `native_mac`; Rosetta 2 is not CrossOver.

## Chinese nicknames and abbreviations

Resolve Chinese nicknames, abbreviations, transliterations, and region suffixes before compatibility classification:

- Normalize full-width characters, punctuation, spacing, and discovery-only suffixes such as `国服`, `国际服`, `中国版`, `PC版`, and `Windows版`; keep the suffix as an edition constraint instead of discarding it.
- Accept a sole canonical candidate as `single_non_exact` only after checking its publisher, platform/build, and edition against live sources. Lower confidence internally, but do not print the resolved Chinese-to-English mapping or mention alias/non-exact matching in the final answer.
- If more than one plausible title, remake, DLC, or mobile/PC build remains, return `ambiguous`, output only numbered candidates with their exact titles/editions/stores/URLs, and end with `请选择 1/2` (or the matching count). Do not add an explanation, verdict, star rating, device assumptions, or setup advice.
- Do not use a remembered nickname mapping as proof. An unresolved alias is `unknown`, not `not_playable`.

## Headline output

When no verified method-specific playable route exists, place the primary verdict and star rating first:

```markdown
## 结果：当前不可玩｜★★☆☆☆
```

Use `★★★★★`, `★★★★☆`, `★★★☆☆`, `★★☆☆☆`, or `★☆☆☆☆` for ratings 5 through 1. When the macOS rating is absent, write `未评级`; never print `CodeWeavers：` or an English rating label in the headline, and never borrow a Linux rating. Keep the canonical English `rating_label` in structured evidence for classification and detailed source notes only.

When a dated, game-specific tutorial explicitly reports that the exact title and edition reaches gameplay through an in-scope non-official desktop method, replace the standard verdict headline with the practical playable result:

```markdown
## 结果：使用CrossOver+第三方插件可玩
```

- `结果：使用CrossOver+第三方插件可玩`: a CrossOver route also requires a patch, modified library, mod, or extra component. Use this exact compact spelling.
- `结果：使用 CrossOver Preview 可玩`: Preview is the distinguishing requirement without an extra third-party component.
- `结果：调整 CrossOver 配置后可玩`: non-default CrossOver settings are sufficient.
- `结果：使用 Windows 虚拟机可玩`: a verified Windows-VM route is the method.
- `结果：使用第三方工具可玩`: fallback only when no narrower label applies.

Do not add stars or a second standard-status heading to a method-specific playable result. The standard rating does not score the third-party route. If the database still reports failure, mention the conflict briefly under `关键限制` or `可信度` only when useful. Never print the generic line `社区方案可玩`. Require the tutorial to identify a concrete method such as a CrossOver/Preview version, script, patch, graphics backend, launcher workaround, or translation layer. Verify its game edition and publication/test date. Do not use the method-specific headline for PlayCover/iOS sideloading, a generic setup guide, a title-only database entry, an install success without gameplay, a mismatched region/version, or a report older than 18 months. Explain the method and risks later under `怎么玩` and `关键限制`.

## Page-style response layout

Every non-ambiguous result is a single, self-contained Markdown page. Do not add
progress chatter, raw JSON, or an unstructured paragraph before the result. After
the single result heading, use these H3 blocks in
order:

```markdown
### 怎么玩
### 适用设备
### 关键限制
### CodeWeavers 用户反馈
### 可信度
### 来源
```

The feedback block is omitted when no user notes are returned. Keep each block
short and scannable; use bullets or a compact table when useful, and do not repeat
the same fact across blocks. Ambiguous title matches remain the special exception:
output only the numbered candidates and `请选择` as specified above.

Confidence explanations describe the evidence itself: source authority,
freshness, conflicts, missing device coverage, or reproducibility. Do not expose
internal title-matching labels or add a sentence saying that a Chinese title maps
to an English canonical title after the match has been verified.

## CrossOver rating mapping

- 5 — Runs Great → `crossover/recommended`
- 4 — Runs Well → `crossover/recommended`
- 3 — Limited Functionality → `crossover/limited`
- 2 — Installs, Will Not Run → `unavailable_or_unknown/not_playable`
- 1 — Will Not Install → `unavailable_or_unknown/not_playable`
- Unrated → no conclusion by itself

Use only the Mac review. Record the exact CrossOver version and test date instead of describing it as “latest.”

## CodeWeavers user feedback

The collector checks the three newest macOS rating breakdowns and stops at the newest version containing non-empty BetterTester or customer notes. It exposes them as `crossover.user_feedback`. CodeWeavers staff notes are not mislabeled as user feedback.

- List every returned feedback item; do not select only positive or negative comments.
- Translate `original_text` faithfully into Chinese and retain the original text immediately after it.
- Include the author, submitted star rating, feedback date, and the exact CrossOver version attached to that rating breakdown.
- Preserve negation, uncertainty, performance figures, resolutions, hardware names, graphics backends, and workarounds. Do not polish a rough comment into a stronger claim.
- Treat each item as user-submitted evidence. It may corroborate a limitation or setup detail but cannot override the canonical macOS rating, official evidence, or a newer reproducible test.
- Mark feedback older than 18 months as stale. An undated comment remains supplementary and low-confidence.

## Out-of-scope mobile wrappers

Do not list PlayCover, iOS/iPadOS sideloading, or mobile-device wrappers as ways to play a Mac game. Do not use their tutorials, reports, or success claims as evidence for `native_mac`, `crossover`, `unavailable_or_unknown`, or a method-specific playable heading. If a title is only shown working through one of these methods, keep the result based on native/CrossOver evidence or return `unknown`.

AppleGamingWiki `perfect`, `playable`, and `runs` are positive; `unplayable` is negative; `unknown`, empty, and `na` are inconclusive for CrossOver.

MacGamingDB and Porting Kit are supplementary rather than decisive:

- Cite the exact game page and preserve its reported hardware, macOS version, compatibility method, game/store build, test date, and limitations when present.
- A fresh, detailed report may corroborate a verdict or supply risks and setup notes, but cannot be the sole reason to change `unknown` into `native_mac`, `crossover`, or `not_playable`.
- Do not map a Porting Kit port to a CodeWeavers star rating. Its wrapper, Wine engine, patches, and dependencies may not transfer to a CrossOver bottle.
- Do not treat MacGamingDB performance figures as guarantees for different chips, memory sizes, macOS versions, or game builds.

## Chinese video evidence

## Poster trigger gate

Show `生成海报：回复“海报”` only after a playable route has been verified.
Never show this trigger for `当前不可玩`, `暂时无法确认`, source-free,
unresolved, or ambiguous results; those results must end with compatibility
feedback only and must not start poster generation.

Use Bilibili as an optional title-specific tutorial source rather than a single-creator allowlist:

- After a primary CrossOver route is verified, run at most three relevant Bilibili searches in parallel, with a 20-second combined budget. Choose only terms relevant to the route, such as `Mac CrossOver 教程` or `Mac 实机`; do not exhaust a fixed keyword list.
- Do not run Bilibili recovery for an unresolved primary verdict unless the user asks specifically for possible workarounds. A missing video never delays or weakens a verified CodeWeavers verdict. Open any exact user-supplied Bilibili URL directly.
- Verify the uploader UID of every cited video and cite the exact `bilibili.com/video/BV...` page and publication date. Preserve any stated game/region version, CrossOver version, macOS version, chip, graphics backend, launcher, patch, and limitation.
- For Chinese answers, prioritize a current, exact-title Bilibili tutorial over tutorials on other video platforms. Put its publication date directly beside the link as `发布于 YYYY-MM-DD` so the user can judge freshness.
- If a Bilibili video reaches gameplay but does not teach the reproducible setup, label it `B站实机演示（非完整教程）`. It may be the first media link for Chinese users, but the actual steps must still come from a detailed guide or the original patch project.
- Do not expose source-selection notes in the answer. In particular, never append labels such as `B站参考（中文优先）`, `中文优先`, `检索优先`, or `补充证据`; cite the actual video title, uploader, and publication date instead.
- A creator list URL is only a discovery aid. Follow its visible `bvid` to the exact video URL and verify the uploader, title, date, game edition, and desktop method before citing it.
- Use a generic CrossOver tutorial only for baseline setup guidance. It is not evidence that a particular game currently runs.
- A current, dated, game-specific demonstration may establish that its particular community route reaches gameplay and may define that route's required steps. It cannot become an official macOS build or CodeWeavers rating by itself.
- Affiliate or promotional links do not invalidate visible title-specific gameplay, but they do not establish download safety. Remove commercial links from the answer. For an unofficial patch, prefer its original source repository/release; if only a cloud mirror exists, cite the tutorial, state that provenance could not be verified, and do not provide the binary link.
- Never cite cracked games, activation bypasses, license workarounds, or shared copyrighted installers.

## Conflicts and freshness

- Consider evidence older than 18 months stale. Staleness lowers confidence but does not automatically invert a verdict.
- When dated positive and negative evidence conflict, prefer the newer observation only when it is at least 90 days newer and clearly covers the same platform and method.
- Otherwise return `unknown`, cite both sources, and explain the conflict.
- Prefer a recent CodeWeavers macOS test over an older, unreferenced community note.
- Do not compare a game-version test with a materially different remake, edition, or online service.

## Confidence

- `high`: current official store confirmation for a Mac build, or a fresh CodeWeavers 4–5/1–2 macOS test with no conflict.
- `medium`: a fresh CodeWeavers 3-star test, or a dated AppleGamingWiki device report with no stronger evidence.
- `low`: a single undated community report, stale-only evidence, a non-exact title match, or a partial-source result.

Downgrade one level for a non-exact single title match or stale decisive evidence. Do not downgrade below `low`.

## Limitations and advice

- If anti-cheat blocks only multiplayer, retain a playable verdict and state `仅离线可玩`.
- If anti-cheat blocks an online-only game, use `not_playable`.
- Extract D3DMetal, DXMT, DXVK, MSync, ESync, launcher, resolution, and performance advice only from dated source notes. Use `crossover.setting_advice`, not the raw `settings` strings, when deciding how to present it.
- A setting observed in AppleGamingWiki, MacGamingDB, a video, or CodeWeavers user feedback is not a CrossOver default. It becomes `该社区方案必需` only when a current reproducible route explicitly depends on it; preserve its CrossOver version, date, scope, and conditional wording.
- When recent user feedback and an older community note recommend different backends, list them as separate observations. Prefer the recent same-version observation for an optional first comparison, but do not call either backend mandatory and do not merge their other settings.
- Follow [crossover-operations.md](crossover-operations.md) for the current official meaning of bottle, Auto, DXVK, D3DMetal, DXMT, Wine, MSync, DLSS, high-resolution mode, and safe troubleshooting order.
- Follow [tutorial-evidence.md](tutorial-evidence.md) to find and rank current setup guides before writing `怎么玩`.
- Separate “launches” from “fully playable.” Do not infer performance from an install success.
- Always include the query date because compatibility changes with game, launcher, macOS, and CrossOver updates.

End every completed compatibility answer with the feedback link
`兼容反馈：[填写反馈](https://wj.qq.com/s2/27740110/7ceg/)`. It must be the final
line, after sources and any download footer. Omit it for ambiguous candidate-only
answers.

## Chinese CrossOver response wording

- A verified CrossOver result is expressed affirmatively: the first sentence
  below the result heading is exactly `需要 CrossOver 玩。` Do not use a contrast
  such as `可以玩，但不是原生 Mac 版` unless the user has specifically asked whether
  a native Mac build exists.
- Do not expose Linux compatibility, Linux ratings, or macOS/Linux comparison
  text in a Chinese user-facing answer. The Mac-only evidence separation remains
  an internal verification requirement.
- Before sending, verify that the final `### 分享与反馈` block exists. For a
  verified playable result before poster generation, it contains exactly the
  poster trigger followed by the feedback link, with the feedback link as the
  response's final line.
