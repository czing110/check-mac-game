# Recovery from incomplete collection

Use this procedure when `retrieval.final_answer_allowed` is false. Exit code 2
is a handoff to recovery, not a compatibility result. Preserve the collector's
JSON as `result.json`; do not compose a final verdict from that pending result.

## Obtain evidence

1. The entire recovery pass has a 60-second budget. For DNS or sandbox network
   failure, retry once using the host's authorized network capability. Respect
   approval refusals. Do not repeat the same blocked request or bypass a refusal
   through another tool. If that authorized retry succeeds, inspect its retrieval
   gate too; HTTP 403 and partial table results can remain.
2. If the game is unresolved, find an official store page with both the requested
   localized name and its English title. Record the Steam App ID. Do not ask the
   user to find an English name that the official page provides.
3. When the collector reports CodeWeavers HTTP 403, robots blocking, a timeout,
   an empty result, or no match, first open the resolved exact CodeWeavers URL
   with an agent-controlled real browser. Wait for normal page loading and read
   the game heading, Mac Rating, Last Tested version, stale-rating warning,
   Tips, and Forum. The browser has different JavaScript, cookie, session, and
   anti-bot behavior from the collector, so a collector 403 does not justify
   skipping this step. A page the user already opened is a lead, not evidence:
   the agent must inspect it through its own available browser control. If a
   CAPTCHA, login, or human verification is required, stop and ask the user to
   complete that verification; do not classify the game while it is pending.
4. Only if no agent-controlled browser is available, or that browser cannot
   expose the exact page after normal loading, run the title-specific
   CodeWeavers search supplied in `retrieval.exact_lookup` using the resolved
   English name. Open the exact matching detail URL. A slug constructed from a
   title is a discovery candidate, not identity evidence. If that exact page
   remains unavailable, use the host search tool once with
   `site:codeweavers.com/compatibility/crossover/<exact-slug> "Mac Rating"`.
   Inspect the indexed **exact page**, its game heading, Mac Rating label and
   Last Tested version. A generic search such as `How to Fish CrossOver` is not
   this step. Do not stop because that generic query returned unrelated pages.
   Do not use Wayback, archive.today, CDX, repeated search engines, or repeated
   exact-page requests. Historical snapshots are not live compatibility evidence.
   A page merely visible in the user's browser or in an ambient screenshot is
   not agent evidence. It may be used only as a lead. The agent must inspect the
   exact URL itself with an available browser/search tool, or the user must
   provide the exact URL and readable page text. Only then may the excerpt be
   copied into the evidence record and used for recovery.
   If this one fallback cannot expose the required Mac block, stop recovery and
   report `暂时无法确认` with the attempted official URL and query.
5. Preserve the source excerpt verbatim, its URL, lookup query, retrieval method
   and retrieval timestamp. Five bullet/star placeholders in extracted text do
   not mean five filled stars: `Runs Well` means four, `Runs Great` means five.
   Never use the Linux block or an unscoped search-table rating as the Mac review.
   If multiple Mac review blocks conflict or a rating is explicitly marked
   outdated (including a warning heading), keep it pending for reconciliation.
   Boolean values are not numeric ratings. Malformed evidence must be rejected
   explicitly rather than interpreted as an incompatible game.

## Write back and validate

After host tools find the evidence, write `evidence.json` containing:

```json
{
  "query": "original user game name",
  "identity": {
    "english_title": "official English title",
    "url": "https://store.steampowered.com/app/APP_ID/",
    "text": "verbatim official excerpt linking both titles",
    "retrieved_at": "ISO timestamp with timezone"
  },
  "codeweavers": {
    "url": "https://www.codeweavers.com/compatibility/crossover/EXACT_SLUG",
    "method": "exact_page_index",
    "lookup_query": "the exact-path query actually executed, including Mac Rating",
    "text": "verbatim page excerpt including game heading, Mac Rating label and Last Tested version",
    "retrieved_at": "ISO timestamp with timezone"
  }
}
```

Use `direct_page_text` for text copied from an opened exact page, and
`exact_page_index` only for an indexed exact-page result. Save real evidence,
never fill the excerpt from an expected answer or memory. Numeric ratings passed
in the JSON are ignored: the validator extracts
them from the Mac section. These records are auditable inputs, not proof that a
search occurred; the assistant is responsible for using actual tool outputs.

Run relative to the skill folder:

```bash
python3 scripts/recover_game.py --result result.json --evidence evidence.json --output verified.json
```

The validator rejects mismatched games, unrelated domains, generic-search-only
evidence, missing Mac labels/versions, conflicting Mac detail ratings, and old
retrieval records. Failure exits 2 without writing a new result. Do not read a
previous output after a failed command. Success preserves raw source text and
the initial failures in the resulting JSON. Inspect the gate in `verified.json`
and use its rating and version in the answer. Never edit `final_answer_allowed`
manually or substitute an unsupported verbal conclusion.

After a successful recovery, append one `recovery_verified` item to the
structured `query_log` with the exact URL, retrieval method, elapsed time, and
the recovered rating/version. Do not put the raw log in the user-facing reply.

This helper covers Steam-backed title identity and numeric Mac ratings. For
non-Steam identities, unrated entries, or a genuine source conflict, keep the
result pending and explain the specific evidence limitation; do not manufacture
a Steam mapping or a rating to satisfy the validator. Run tutorial discovery
after recovery only when the user asks how to play or requests a workaround.
Tips, Forum, hardware, test dates, and frame rates are not inferred from the
rating excerpt. A retrieval date is not a test date.

If every permitted recovery path fails, report that verification is incomplete
and list the attempted exact URL/query and failure. Do not claim the entry or
test record does not exist. Do not offer posters for an unverified result. Never
expose recovery retries, archive attempts, or validator file names in the
user-facing answer.
