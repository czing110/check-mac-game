# Mac Game Recommendation Rules

Read this reference for configuration-based, preference-based, and similar-game
recommendations. Single-title compatibility checks continue to use the ordinary
workflow.

## Modes

- `configuration`: questions such as “我的 M3 Air 16GB 能玩什么”. Use supplied
  hardware. When the user explicitly says “这台 Mac” and the execution environment
  is their Mac, `recommend_games.py --detect-this-mac` may read local model, chip,
  memory, and macOS. Otherwise ask only for the missing chip and memory when they
  materially change the result.
- `preference`: questions such as “我喜欢动作游戏，有什么推荐”. Extract genre,
  controller, online/co-op, Chinese-language, native-only, and setup-tolerance
  constraints. Do not ask about every optional preference; use stated constraints.
- `similar`: questions such as “推荐类似 Elden Ring、但能在 Mac 上玩的游戏”.
  Resolve the seed title, discover live candidates from its Steam genres, and say
  that similarity is genre-based unless a stronger source is available.

Run:

```bash
python3 scripts/recommend_games.py [--genre "动作"] [--similar-to "GAME"] \
  [--chip "M3 Pro"] [--memory-gb 18] [--macos "15.6"] \
  [--storage-free-gb 200] [--controller] [--online] [--chinese] \
  [--native-only] [--max-setup simple|medium|complex] [--limit 6] --json
```

## Ranking and evidence

Use two stages so recommendation requests do not slow single-title checks:

1. Discover current candidates from Steam's live search and tag taxonomy. A tag
   mapping is acceptable; do not maintain a hand-curated game allowlist.
2. Deep-check only the shortlist with the existing compatibility collector. Rank
   confirmed official Mac releases first, then current recommended CrossOver
   results, then limited CrossOver results. Exclude unknown and not-playable titles.

The complete recommendation result is cached for six hours, while an empty result
is cached for 30 minutes. Reuse the cache by default. Use `--refresh` only for an
explicit fresh recheck and `--no-cache` only for debugging.

When `--max-setup complex` is allowed, the collector returns at most two strong
negative/unknown matches under `manual_review_candidates`. The agent may perform
the normal current tutorial pass for those candidates only. Include one only when
a fresh, reproducible desktop route reaches
gameplay. Apply the normal third-party patch and Bilibili evidence rules.

Never rank popularity above compatibility. Never infer a frame rate, resolution,
graphics preset, or thermal result from the chip name. Official minimum memory and
storage requirements can exclude an under-spec device, but meeting them is not a
performance guarantee. CrossOver uses Windows requirements only as a reference and
must label that limitation.

## Setup effort

- `simple / 简单`: official Mac release; normal store installation.
- `medium / 中等`: current CrossOver route without a required third-party patch.
- `complex / 复杂`: verified CrossOver route requiring a patch, modified library,
  script, executable edit, or similarly fragile setup.
- `not_recommended / 不建议`: unavailable, unknown, blocked online-only play, or
  evidence too weak to recommend.

Respect `--max-setup`. If the user says “不想折腾”, use `simple`; if they accept
CrossOver but not patches, use `medium`.

## Response shape

Start with `## 最适合你的游戏` and show a compact table:

```markdown
| 游戏 | 类型 | 运行方式 | 配置适配 | 安装难度 | 主要限制 |
```

Then add `### 最推荐的 3 款` with one concrete reason per game, followed by
`### 配置说明` and dated source links. Keep “兼容性已确认” separate from
“性能已实测”. If exact-device performance evidence is absent, write `性能待实测`.

For similar-game requests, state the similarity basis. For an empty result, report
which constraint removed the candidates and suggest relaxing only that constraint;
do not silently return incompatible games.

## Boundaries

- Continue excluding PlayCover and mobile sideloading.
- Cloud gaming is not local Mac compatibility and appears only when the user asks.
- Do not link cracks, shared installers, activation bypasses, or unverifiable patch
  mirrors.
- Prices, availability, launcher behavior, and compatibility are live facts; cite
  query dates and recheck before a purchase recommendation.
