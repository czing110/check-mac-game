import importlib.util
import tempfile
import unittest
from pathlib import Path
from datetime import datetime, timezone

collector = Path(__file__).with_name('check_game.py')
spec = importlib.util.spec_from_file_location('collector', collector)
m = importlib.util.module_from_spec(spec)
spec.loader.exec_module(m)

class Offline:
    def get_text(self, *args, **kwargs):
        raise OSError('DNS lookup failed')
    get_json = get_text

class GateTests(unittest.TestCase):
    def test_search_failure_recovers_exact_page(self):
        class DirectOnly:
            def get_text(self, url):
                if url != 'https://www.codeweavers.com/compatibility/crossover/how-to-fish':
                    raise OSError('search unavailable')
                return '''<script type="application/ld+json">[
                  {"@type":"VideoGame","name":"How to Fish"},
                  {"@type":"Review","reviewAspect":"macOS","reviewRating":{"ratingValue":4},"about":{"softwareVersion":"26.3.0"}},
                  {"@type":"Review","reviewAspect":"Linux","reviewRating":{"ratingValue":1}}
                ]</script>'''
        r = m.fetch_codeweavers(DirectOnly(), 'How to Fish', '2026-09-09')
        self.assertEqual(r['data']['rating'], 4)
        self.assertEqual(r['data']['last_tested_version'], '26.3.0')
        self.assertEqual(r['selected']['name'], 'How to Fish')

    def test_slug_collision_does_not_accept_other_game(self):
        class WrongTitle:
            def get_text(self, url):
                return '<script type="application/ld+json">{"@type":"VideoGame","name":"Another Game"}</script>'
        r = m.fetch_codeweavers(WrongTitle(), 'How to Fish', '2026-09-09')
        self.assertIsNone(r['selected'])
        self.assertIsNone(r['data']['rating'])

    def test_recovery_handoff_has_exact_path_and_requires_translation(self):
        self.assertTrue(m.codeweavers_recovery_plan('渔力全开')['requires_official_english_title'])
        p = m.codeweavers_recovery_plan('How to Fish')
        self.assertEqual(p['candidate_url'], 'https://www.codeweavers.com/compatibility/crossover/how-to-fish')
        self.assertIn('how-to-fish "Mac Rating"', p['queries'][1])

    def test_network_failure_end_to_end(self):
        with tempfile.TemporaryDirectory() as d:
            r = m.collect_game('传送门 2', client=Offline(), cache_dir=Path(d))
            self.assertEqual(r['verdict_detail'], 'unknown')
            self.assertEqual(r['retrieval']['status'], 'recovery_required')
            self.assertFalse(r['retrieval']['final_answer_allowed'])
            self.assertIsNone(r['crossover']['rating'])
            self.assertEqual(list(Path(d).glob('*.json')), [])
            self.assertIn('查询未完成', m.human_summary(r))

    def test_native_unavailable_is_not_game_unplayable(self):
        v, detail, _, _ = m.classify({'available':False}, {}, None, datetime.now(timezone.utc), 'exact', [], [])
        self.assertEqual(detail, 'unknown')

    def test_cw_positive_survives_detail_error(self):
        r = {'verdict':'crossover','verdict_detail':'recommended', 'crossover':{'rating':4,'last_tested_version':'26.3.0','url':'https://www.codeweavers.com/compatibility/crossover/portal-2'}, 'errors':[{'source':'codeweavers_detail','error':'403'}]}
        m.apply_retrieval_gate(r)
        self.assertTrue(r['retrieval']['final_answer_allowed'])
        self.assertEqual(r['crossover']['rating'],4)
        self.assertEqual(m.result_cache_ttl(r),0)

    def test_unchecked_negative_is_blocked(self):
        r={'verdict':'unavailable_or_unknown','verdict_detail':'not_playable','crossover':{}}
        m.apply_retrieval_gate(r)
        self.assertEqual(r['verdict_detail'],'unknown')
        self.assertFalse(r['retrieval']['final_answer_allowed'])

    def test_table_rating_without_version_requires_exact_page(self):
        r={'verdict':'crossover','verdict_detail':'recommended','crossover':{'rating':5,'url':'https://www.codeweavers.com/compatibility/crossover/how-to-fish'}}
        m.apply_retrieval_gate(r)
        self.assertFalse(r['retrieval']['final_answer_allowed'])
        self.assertEqual(r['crossover']['rating'],5)

    def test_missing_rating_is_not_zero(self):
        for rating in [None,0,False]:
            r={'verdict_detail':'unknown','crossover':{'rating':rating,'url':'https://example.com'}}
            m.apply_retrieval_gate(r)
            self.assertFalse(r['retrieval']['final_answer_allowed'])

    def test_old_error_cache_rejected(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'cache.json'
            m.store_cached_result(p,{'errors':[{'error':'DNS'}],'verdict_detail':'unknown'},300)
            self.assertIsNone(m.load_cached_result(p))

    def test_pending_result_has_structured_query_log(self):
        with tempfile.TemporaryDirectory() as d:
            r = m.collect_game('传送门 2', client=Offline(), cache_dir=Path(d))
            log = r['query_log']
            self.assertEqual(log['schema_version'], 1)
            self.assertEqual(log['skill_version'], m.SKILL_VERSION)
            self.assertEqual(log['stages'][-1]['stage'], 'retrieval_gate')
            self.assertEqual(log['stages'][-1]['status'], 'recovery_required')

if __name__=='__main__':
    unittest.main()
