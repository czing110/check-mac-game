#!/usr/bin/env python3
"""Reject a completed Chinese compatibility reply that leaks internal delivery logs."""

from __future__ import annotations

import argparse
from pathlib import Path
import sys


FEEDBACK = "兼容反馈：[填写反馈](https://wj.qq.com/s2/27740110/7ceg/)"
POSTER_TRIGGER = "生成海报：回复“海报”"
DOWNLOAD_PREFIX = "下载海报：[立即下载]("
INTERNAL_MARKERS = (
    "md5", "sha256", "hash", "聚合页", "验收", "交付前", "抽样检查",
    "画廊顺序", "style", "png", "素材没串", "现在抓取", "我再试",
    "中文优先", "检索优先", "补充证据", "B站参考",
    "页面无法核验", "Mac 评级未能取得", "跑 footer gate", "验证结果正常",
)


def validate(text: str) -> list[str]:
    lines = [line.rstrip() for line in text.splitlines()]
    nonempty = [line for line in lines if line.strip()]
    errors: list[str] = []
    if nonempty.count("### 分享与反馈") != 1:
        errors.append("response must contain exactly one 分享与反馈 heading")
        return errors
    heading = nonempty.index("### 分享与反馈")
    tail = nonempty[heading + 1:]
    if len(tail) not in {1, 2}:
        errors.append("分享与反馈 must be the final block with one or two rows")
    if not nonempty or nonempty[-1] != FEEDBACK:
        errors.append("feedback link must be the final non-empty line")
    if len(tail) == 2 and not (tail[0] == POSTER_TRIGGER or tail[0].startswith(DOWNLOAD_PREFIX)):
        errors.append("first 分享与反馈 row must be the poster trigger or download link")
    if len(tail) == 1 and tail[0] != FEEDBACK:
        errors.append("single 分享与反馈 row must be the feedback link")
    visible = "\n".join(nonempty)
    leaked = [marker for marker in INTERNAL_MARKERS if marker.casefold() in visible.casefold()]
    if leaked:
        errors.append("internal delivery language is visible: " + ", ".join(leaked))
    return errors


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--file", type=Path, required=True)
    args = parser.parse_args()
    try:
        errors = validate(args.file.read_text(encoding="utf-8"))
    except OSError as exc:
        parser.exit(2, f"Cannot read response draft: {exc}\n")
    if errors:
        parser.exit(2, "Response gate rejected: " + "; ".join(errors) + "\n")
    print("response gate: OK")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
