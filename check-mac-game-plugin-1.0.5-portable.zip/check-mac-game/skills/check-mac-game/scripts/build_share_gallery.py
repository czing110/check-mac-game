#!/usr/bin/env python3
"""Build a minimal multi-poster share page for check-mac-game."""

from __future__ import annotations

import argparse
import base64
import html
import hashlib
import mimetypes
import os
from pathlib import Path
import re
from typing import Iterable, Optional


def slugify(value: str) -> str:
    value = re.sub(r"[^\w\-\u3400-\u9fff]+", "-", value, flags=re.UNICODE).strip("-_")
    return (value[:48] or "game").lower()


def relative_href(path: Path, output: Path) -> str:
    return Path(os.path.relpath(path.resolve(), output.resolve().parent)).as_posix()


def download_target(card: Path) -> Optional[Path]:
    """Return a raster image sibling; HTML and SVG are never downloads."""
    for suffix in (".png", ".jpg", ".jpeg"):
        candidate = card.with_suffix(suffix)
        if candidate.is_file():
            return candidate
    return None


def download_data_uri(path: Path) -> str:
    mime = mimetypes.guess_type(path.name)[0] or "application/octet-stream"
    encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    return f"data:{mime};base64,{encoded}"


def build_gallery(game: str, cards: Iterable[Path], output: Path, embed: bool = False) -> Path:
    cards = [Path(card).resolve() for card in cards]
    if not cards:
        raise ValueError("at least one card is required")
    missing = [str(card) for card in cards if not card.is_file()]
    if missing:
        raise FileNotFoundError("share cards not found: " + ", ".join(missing))
    output = output.resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    stem = slugify(game)
    tiles = []
    seen_downloads: dict[str, Path] = {}
    for index, card in enumerate(cards, start=1):
        target = download_target(card)
        if target is None:
            raise FileNotFoundError(f"raster download missing for share card: {card}")
        fingerprint = hashlib.sha256(target.read_bytes()).hexdigest()
        if fingerprint in seen_downloads:
            raise ValueError(
                "duplicate raster downloads for different share cards: "
                f"{seen_downloads[fingerprint]} and {target}"
            )
        seen_downloads[fingerprint] = target
        download_href = download_data_uri(target) if embed else relative_href(target, output)
        download_suffix = target.suffix
        download_name = f"{stem}-海报-{index:02d}{download_suffix}"
        poster_id = f"poster-{index}"
        tiles.append(
            "<figure class=\"tile\">"
            f"<div class=\"preview\"><img id=\"{poster_id}\" src=\"{download_href}\" alt=\"《{html.escape(game, quote=True)}》分享海报 {index}\" loading=\"lazy\" decoding=\"async\"></div>"
            f"<a class=\"download\" href=\"#{poster_id}\" data-download-from=\"{poster_id}\" download=\"{html.escape(download_name, quote=True)}\" aria-label=\"下载《{html.escape(game, quote=True)}》海报 {index}\">↓ 下载海报</a>"
            "</figure>"
        )
    document = f'''<!doctype html>
<html lang="zh-CN">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>我在Mac上玩《{html.escape(game)}》</title>
  <style>
    :root {{ color-scheme:dark; --night:#25282b; --ivory:#eef0f3; --cobalt:#59616d; --signal:#d9dde3; --ease:cubic-bezier(.2,.75,.2,1); }}
    * {{ box-sizing:border-box; }}
    html {{ background:#090a0b; }}
    body {{ margin:0; min-width:320px; background:#090a0b; color:var(--ivory); font-family:"Avenir Next","PingFang SC","Microsoft YaHei",sans-serif; }}
    ::selection {{ background:var(--signal); color:#08090b; }}
    .archive {{ position:relative; isolation:isolate; width:min(2000px,100%); min-height:100svh; margin:auto; overflow:hidden; padding:clamp(32px,4.2vw,72px); border-radius:20px; background:linear-gradient(135deg,#303338,#282c2f 58%,#222527); box-shadow:inset 0 1px rgba(255,255,255,.08),0 24px 80px rgba(0,0,0,.5); }}
    .archive::before {{ content:""; position:absolute; inset:0; z-index:-1; pointer-events:none; opacity:.42; background:repeating-linear-gradient(0deg,rgba(255,255,255,.032) 0 1px,transparent 1px 5px),radial-gradient(ellipse at 50% 20%,transparent 0 35%,rgba(255,255,255,.045) 35.1% 35.2%,transparent 35.3% 54%,rgba(255,255,255,.025) 54.1% 54.2%,transparent 54.3%); }}
    .archive::after {{ content:""; position:absolute; inset:0; z-index:-1; pointer-events:none; border-radius:20px; background:linear-gradient(90deg,transparent 0 49.7%,rgba(255,255,255,.025) 49.8%,transparent 50.2% 100%); }}
    .constellation {{ display:none; }}
  .masthead{{
    position:relative; text-align:center;
    max-width:1420px; margin:0 auto clamp(44px,6vh,76px);
  }}
  .eyebrow{{
    display:flex; align-items:center; justify-content:center; gap:11px;
    margin:0 0 18px; font-size:11px; font-weight:600; letter-spacing:.36em; text-indent:.36em;
    color:#e9edf7; text-transform:uppercase;
  }}
  .eyebrow::before{{
    content:""; width:4px; height:4px; flex:0 0 4px;
    background:#e9edf7; border-radius:50%;
    box-shadow:0 0 0 3px rgba(255,255,255,.12);
  }}
  h1{{ margin:0; font-weight:700; line-height:1.05; text-wrap:balance; }}
  h1 .lead{{
    display:block; margin-bottom:12px;
    font-size:clamp(14px,1.4vw,18px); font-weight:500; letter-spacing:.26em;
    color:rgba(242,245,251,.60);
  }}
  h1 .game{{
    display:block;
    font-family:"Songti SC","STSong","Noto Serif SC",serif;
    font-size:clamp(48px,6.6vw,96px); letter-spacing:.03em;
    color:#f2f5fb; text-shadow:0 6px 40px rgba(0,0,0,.5);
  }}

    .grid {{ display:grid; grid-template-columns:repeat(4,minmax(0,1fr)); gap:48px 30px; align-items:start; max-width:1200px; margin:auto; }}
    /* 按传入顺序展示八张海报，顺序由默认模板统一定义。 */
    .tile {{ position:relative; min-width:0; margin:0; transition:transform .34s cubic-bezier(.22,.9,.28,1.24); }}
    .tile:hover {{ transform:scale(1.025); }}
    .tile:nth-child(2),.tile:nth-child(4) {{ margin-top:0; }}
    .preview {{ width:100%; aspect-ratio:3/4; overflow:hidden; background:#111; box-shadow:0 30px 68px rgba(0,0,0,.48); transition:box-shadow .45s var(--ease); }}
    .preview img {{ display:block; width:100%; height:100%; object-fit:contain; }}
    .download {{ display:flex; width:max-content; min-width:116px; min-height:42px; margin:16px auto 0; align-items:center; justify-content:center; padding:9px 20px; border:1px solid rgba(238,240,243,.42); border-radius:999px; background:#e9ecf2; box-shadow:0 10px 28px rgba(0,0,0,.32),inset 0 1px rgba(255,255,255,.12); color:#20242b; font-size:14px; font-weight:700; text-decoration:none; transition:background .25s,color .25s,border-color .25s; }}
    .download:hover {{ background:var(--signal); border-color:var(--signal); color:#08090b;  }}
    .download:active {{ transform:translateY(0); }}
    .download:focus-visible {{ outline:3px solid var(--signal); outline-offset:4px; }}
    @media (max-width:980px) {{ .masthead {{ margin-bottom:58px; }} .grid {{ grid-template-columns:repeat(2,minmax(0,1fr)); max-width:760px; }} .tile:nth-child(2),.tile:nth-child(4) {{ margin-top:0; }} }}
    @media (max-width:620px) {{ .archive {{ padding:28px 18px 46px; }} .masthead {{ margin-bottom:44px; }} h1 .game {{ font-size:clamp(32px,8vw,48px); }} .grid {{ grid-template-columns:1fr; max-width:390px; gap:42px; }} }}
    @media (prefers-reduced-motion:reduce) {{ .tile,.download {{ transition:none; }} }}
  </style>
</head>
<body>
  <main class="archive">
    <div class="constellation" aria-hidden="true"></div>
    <header class="masthead"><div class="eyebrow">CHECK-MAC-GAME · 兼容性分享</div><h1><span class="lead">我在 Mac 上玩</span><span class="game">《{html.escape(game)}》</span></h1></header>
    <section class="grid">{''.join(tiles)}</section>
  </main>
  <script>
    document.querySelectorAll('[data-download-from]').forEach((button) => {{
      const poster = document.getElementById(button.dataset.downloadFrom);
      if (poster) button.href = poster.currentSrc || poster.src;
    }});
  </script>
</body>
</html>
'''
    output.write_text(document, encoding="utf-8")
    return output


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game", required=True)
    parser.add_argument("--output", type=Path, required=True)
    parser.add_argument("--card", action="append", type=Path, required=True, help="poster HTML path; repeat for each poster")
    parser.add_argument("--embed", action="store_true", help="inline raster images as base64 (self-contained but large); default references files")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    print(build_gallery(args.game, args.card, args.output, embed=args.embed))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
