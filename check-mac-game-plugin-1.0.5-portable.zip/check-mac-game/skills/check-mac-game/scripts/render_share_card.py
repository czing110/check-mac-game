#!/usr/bin/env python3
"""Render an editorial game-compatibility poster for check-mac-game."""

from __future__ import annotations

import argparse
import base64
import hashlib
import html
import io
import json
import mimetypes
import os
from pathlib import Path
import re
import shutil
import subprocess
import sys
import tempfile
import time
import unicodedata
from typing import Any, Optional


WIDTH = 1080
HEIGHT = 1440
TEMPLATE_PATH = Path(__file__).resolve().parents[1] / "assets" / "share-card-template-v2.html"
CAPTURE_HELPER_PATH = Path(__file__).resolve().with_name("capture_share_card.mjs")
DEFAULT_STYLE = "type-monument"

# Default share-card set: render exactly these 8 styles for every concrete,
# resolved single-game result unless the user explicitly asks for the full
# --list-styles set. This is the single source of truth for the default set;
# the agent must not hard-code a different 7-style list elsewhere.
DEFAULT_POSTER_STYLES = (
    "imac-aluminum",  # aluminum iMac device frame, landscape key art
    "polaroid",       # warm wall + rotated photo, portrait-friendly crop
    "serif-study",    # pale editorial page, landscape key art
    "frosted-band",   # full-bleed art behind a lower translucent frosted band
    "glitch-sys",     # dark signal interface
    "about-this-mac", # pale About This Mac window
    "industrial-plate", # dark industrial inspection plate
    "macos-desktop",  # real macOS desktop notification and Dock
)
USER_FACING_STYLES = (
    "type-monument",
    "cover-story",
    "glitch-sys",
    "imac-aluminum",
    "about-this-mac",
    "message-tube",
    "frosted-band",
    "circle-window",
    "play-it-mac",
    "running-macos",
    "monitor-terminal",
    "industrial-plate",
    "terminal-app",
    "macos-desktop",
    "letterbox",
    "serif-study",
    "polaroid",
    "blur-stage",
)
SHARE_CARD_STYLES = {
    "type-monument": {"class": "style-type-monument", "label": "TYPE MONUMENT"},
    "cover-story": {"class": "style-cover-story", "label": "COVER STORY"},
    "glitch-sys": {"class": "style-glitch-sys", "label": "GLITCH SYS"},
    "imac-aluminum": {"class": "style-imac-aluminum", "label": "IMAC ALUMINUM"},
    "about-this-mac": {"class": "style-about-this-mac", "label": "ABOUT THIS MAC"},
    "message-tube": {"class": "style-message-tube", "label": "MESSAGE TUBE"},
    "frosted-band": {"class": "style-frosted-band", "label": "FROSTED BAND"},
    "circle-window": {"class": "style-circle-window", "label": "CIRCLE WINDOW"},
    "play-it-mac": {"class": "style-play-it-mac", "label": "PLAY IT / ON MAC"},
    "running-macos": {"class": "style-running-macos", "label": "RUNNING ON MACOS"},
    "monitor-terminal": {"class": "style-monitor-terminal", "label": "MONITOR TERMINAL"},
    "industrial-plate": {"class": "style-industrial-plate", "label": "INDUSTRIAL PLATE"},
    "terminal-app": {"class": "style-terminal-app", "label": "TERMINAL.APP"},
    "macos-desktop": {"class": "style-macos-desktop", "label": "MACOS DESKTOP"},
    "letterbox": {"class": "style-letterbox", "label": "LETTERBOX"},
    "serif-study": {"class": "style-serif-study", "label": "SERIF STUDY"},
    "polaroid": {"class": "style-polaroid", "label": "POLAROID"},
    "blur-stage": {"class": "style-blur-stage", "label": "BLUR STAGE"},
}
STATUS_COLORS = {
    "native": "#35D07F",
    "rosetta": "#35D07F",
    "crossover": "#4C8DFF",
    "third_party": "#FF8A3D",
    "unavailable": "#FF4D55",
    "unknown": "#8A8F98",
}
STATUS_MOTIFS = {
    "native": "NATIVE MAC",
    "rosetta": "ROSETTA",
    "crossover": "CROSSOVER",
    "third_party": "PATCHED",
    "unavailable": "UNAVAILABLE",
    "unknown": "UNKNOWN",
}
REFERENCE_GLASS_STYLE = {
    # Ported from the approved Mac-selected site treatment: pale neutral canvas,
    # a thin bright rim, three translucent white/tinted stops, deep soft shadow,
    # and blur/saturation that preserves the artwork beneath the glass.
    "canvas_top": "#F6F7F9",
    "canvas_middle": "#F2F4F7",
    "canvas_bottom": "#F7F8FA",
    "ink": "#16181D",
    "muted": "#6F7480",
    "glass_start": (255, 255, 255, 158),
    "glass_middle": (247, 250, 255, 87),
    "glass_end": (226, 234, 248, 66),
    "border": (255, 255, 255, 184),
    "inner_top": (255, 255, 255, 240),
    "inner_bottom": (255, 255, 255, 92),
    "shadow": (26, 35, 58, 34),
    "blur_radius": 28,
    "saturation": 1.38,
}
RATING_LABELS = {
    "primary": "兼容评级",
    "standard": "标准兼容评级",
}


def display_width(text: str) -> float:
    width = 0.0
    for character in text:
        width += 1.0 if unicodedata.east_asian_width(character) in {"W", "F", "A"} else 0.56
    return width


def truncate_units(text: str, maximum: float) -> str:
    text = " ".join(str(text or "").split())
    if display_width(text) <= maximum:
        return text
    output = ""
    for character in text:
        if display_width(output + character + "…") > maximum:
            break
        output += character
    return output.rstrip() + "…"


def wrap_units(text: str, maximum: float, max_lines: int) -> list[str]:
    remaining = " ".join(str(text or "").split())
    lines: list[str] = []
    while remaining and len(lines) < max_lines:
        if display_width(remaining) <= maximum:
            lines.append(remaining)
            remaining = ""
            break
        cut = 0
        for index in range(1, len(remaining) + 1):
            if display_width(remaining[:index]) > maximum:
                break
            cut = index
        cut = max(1, cut)
        space = remaining.rfind(" ", 0, cut + 1)
        if space > max(1, cut // 2):
            cut = space
        lines.append(remaining[:cut].strip())
        remaining = remaining[cut:].strip()
    if remaining and lines:
        lines[-1] = truncate_units(lines[-1] + remaining, maximum)
    return lines or [""]


def star_display(rating: Optional[int]) -> str:
    if isinstance(rating, int) and 1 <= rating <= 5:
        return "★" * rating + "☆" * (5 - rating)
    return "未评级"


def image_data_uri(path: Optional[Path]) -> Optional[str]:
    if not path or not path.is_file():
        return None
    mime = mimetypes.guess_type(path.name)[0] or "image/png"
    if not mime.startswith("image/"):
        return None
    try:
        encoded = base64.b64encode(path.read_bytes()).decode("ascii")
    except OSError:
        return None
    return f"data:{mime};base64,{encoded}"


def image_dimensions(path: Path) -> Optional[tuple[int, int]]:
    """Read common raster dimensions without requiring Pillow."""
    try:
        data = path.read_bytes()
    except OSError:
        return None
    if data.startswith(b"\x89PNG\r\n\x1a\n") and len(data) >= 24:
        return int.from_bytes(data[16:20], "big"), int.from_bytes(data[20:24], "big")
    if data.startswith(b"GIF") and len(data) >= 10:
        return int.from_bytes(data[6:8], "little"), int.from_bytes(data[8:10], "little")
    if data.startswith(b"\xff\xd8"):
        offset = 2
        sof_markers = {0xC0, 0xC1, 0xC2, 0xC3, 0xC5, 0xC6, 0xC7, 0xC9, 0xCA, 0xCB, 0xCD, 0xCE, 0xCF}
        while offset + 8 < len(data):
            if data[offset] != 0xFF:
                offset += 1
                continue
            while offset < len(data) and data[offset] == 0xFF:
                offset += 1
            if offset >= len(data):
                break
            marker = data[offset]
            offset += 1
            if marker in {0xD8, 0xD9}:
                continue
            if offset + 2 > len(data):
                break
            length = int.from_bytes(data[offset:offset + 2], "big")
            if length < 2 or offset + length > len(data):
                break
            if marker in sof_markers and length >= 7:
                height = int.from_bytes(data[offset + 3:offset + 5], "big")
                width = int.from_bytes(data[offset + 5:offset + 7], "big")
                return width, height
            offset += length
    return None


def character_data_uri(path: Optional[Path]) -> Optional[str]:
    """Return a browser-ready character cutout when local image tools exist."""
    if not path or not path.is_file():
        return None
    modules = pillow_modules()
    if modules is None:
        return image_data_uri(path)
    try:
        cutout = _prepare_character(path, (480, 760))
        output = io.BytesIO()
        cutout.save(output, format="PNG", optimize=True)
        encoded = base64.b64encode(output.getvalue()).decode("ascii")
        return f"data:image/png;base64,{encoded}"
    except (OSError, RuntimeError, ValueError):
        return image_data_uri(path)


def svg_text_lines(
    lines: list[str],
    *,
    x: int,
    y: int,
    size: int,
    line_height: int,
    fill: str,
    weight: int = 800,
    letter_spacing: int = 0,
) -> str:
    tspans = []
    for index, line in enumerate(lines):
        dy = 0 if index == 0 else line_height
        tspans.append(f'<tspan x="{x}" dy="{dy}">{html.escape(line)}</tspan>')
    return (
        f'<text x="{x}" y="{y}" fill="{fill}" font-size="{size}" '
        f'font-weight="{weight}" letter-spacing="{letter_spacing}" '
        'font-family="PingFang SC,Hiragino Sans GB,Noto Sans CJK SC,Arial Unicode MS,sans-serif">'
        + "".join(tspans)
        + "</text>"
    )


def build_svg(
    *,
    game: str,
    verdict: str,
    status: str,
    method: str,
    rating: Optional[int],
    rating_context: str,
    review: str = "",
    background: Optional[Path] = None,
    key_art: Optional[Path] = None,
    character: Optional[Path] = None,
) -> str:
    accent = STATUS_COLORS[status]
    title_lines = wrap_units(f"《{game}》", 10.8, 2)
    title_size = 74 if len(title_lines) == 1 else 60
    verdict_lines = wrap_units(verdict, 18, 2)
    background_uri = image_data_uri(background)
    key_art_uri = image_data_uri(key_art)
    character_uri = image_data_uri(character)
    scene_uri = key_art_uri or background_uri
    backdrop_layer = (
        f'<image href="{scene_uri}" x="120" y="120" width="1040" height="700" '
        'preserveAspectRatio="xMidYMid slice" filter="url(#ambience)" opacity="0.13"/>'
        if scene_uri else ""
    )
    if key_art_uri:
        art_layer = (
            f'<image href="{key_art_uri}" x="52" y="226" width="976" height="504" '
            'preserveAspectRatio="xMidYMid slice" clip-path="url(#artClip)"/>'
        )
    else:
        art_layer = (
            '<rect x="52" y="226" width="976" height="504" rx="32" fill="#E9EDF3"/>'
            f'<circle cx="820" cy="350" r="300" fill="{accent}" opacity="0.16"/>'
        )
    character_layer = (
        f'<image href="{character_uri}" x="610" y="130" width="450" height="720" '
        'preserveAspectRatio="xMidYMid meet" filter="url(#shadow)"/>'
        if character_uri
        else ""
    )
    refracted_layer = (
        f'<image href="{scene_uri}" x="0" y="0" width="1080" height="1440" '
        'preserveAspectRatio="xMidYMid slice" clip-path="url(#glassClip)" filter="url(#glassBackdrop)" opacity="0.30"/>'
        if scene_uri
        else ""
    )

    return f'''<?xml version="1.0" encoding="UTF-8"?>
<svg xmlns="http://www.w3.org/2000/svg" width="{WIDTH}" height="{HEIGHT}" viewBox="0 0 {WIDTH} {HEIGHT}">
  <defs>
    <linearGradient id="paper" x1="0" y1="0" x2="0" y2="1">
      <stop offset="0" stop-color="#F6F7F9"/>
      <stop offset="0.48" stop-color="#F2F4F7"/>
      <stop offset="1" stop-color="#F7F8FA"/>
    </linearGradient>
    <linearGradient id="glassFill" x1="0" y1="0" x2="1" y2="1">
      <stop offset="0" stop-color="#FFFFFF" stop-opacity="0.62"/>
      <stop offset="0.46" stop-color="#F7FAFF" stop-opacity="0.34"/>
      <stop offset="1" stop-color="#E2EAF8" stop-opacity="0.26"/>
    </linearGradient>
    <radialGradient id="washOne"><stop stop-color="{accent}" stop-opacity="0.12"/><stop offset="1" stop-color="{accent}" stop-opacity="0"/></radialGradient>
    <radialGradient id="washTwo"><stop stop-color="#FF725B" stop-opacity="0.075"/><stop offset="1" stop-color="#FF725B" stop-opacity="0"/></radialGradient>
    <clipPath id="artClip"><rect x="52" y="226" width="976" height="504" rx="32"/></clipPath>
    <clipPath id="glassClip"><path d="M52 654 L1028 640 L1012 1302 L68 1318 Z"/></clipPath>
    <filter id="ambience" x="-20%" y="-20%" width="140%" height="140%">
      <feGaussianBlur stdDeviation="28"/>
    </filter>
    <filter id="glassBackdrop" x="-20%" y="-20%" width="140%" height="140%" color-interpolation-filters="sRGB">
      <feGaussianBlur stdDeviation="28"/>
      <feColorMatrix type="saturate" values="1.38"/>
    </filter>
    <filter id="shadow" x="-30%" y="-20%" width="170%" height="170%">
      <feDropShadow dx="0" dy="24" stdDeviation="28" flood-color="#1A233A" flood-opacity="0.16"/>
    </filter>
  </defs>
  <rect width="1080" height="1440" fill="url(#paper)"/>
  <ellipse cx="30" cy="650" rx="460" ry="420" fill="url(#washOne)"/>
  <ellipse cx="1050" cy="270" rx="430" ry="360" fill="url(#washTwo)"/>
  {backdrop_layer}
  <rect x="52" y="54" width="12" height="38" rx="6" fill="{accent}"/>
  <text x="82" y="82" fill="#16181D" font-size="23" font-weight="900" letter-spacing="2" font-family="Arial Black,PingFang SC,sans-serif">CHECK / MAC / GAME</text>
  <text x="52" y="121" fill="#6F7480" font-size="14" font-weight="800" letter-spacing="2" font-family="Arial Black,PingFang SC,sans-serif">EDITORIAL GLASS COMPATIBILITY REVIEW</text>
  <text x="52" y="160" fill="#16181D" font-size="25" font-weight="900" font-family="PingFang SC,Hiragino Sans GB,sans-serif">我在Mac上玩</text>
  {svg_text_lines(title_lines, x=52, y=218, size=title_size, line_height=title_size + 4, fill="#16181D", weight=900)}
  {art_layer}
  <rect x="52" y="226" width="976" height="504" rx="32" fill="none" stroke="#FFFFFF" stroke-opacity="0.76" stroke-width="2"/>
  {character_layer}
  {refracted_layer}
  <path d="M52 654 L1028 640 L1012 1302 L68 1318 Z" fill="url(#glassFill)" stroke="#FFFFFF" stroke-opacity="0.72" stroke-width="2" filter="url(#shadow)"/>
  <path d="M68 671 L1011 658" fill="none" stroke="#FFFFFF" stroke-opacity="0.94" stroke-width="2"/>
  <path d="M84 1298 L994 1283" fill="none" stroke="#FFFFFF" stroke-opacity="0.36" stroke-width="2"/>
  <path d="M742 646 L825 645 L602 1309 L522 1311 Z" fill="#FFFFFF" fill-opacity="0.10"/>
  <g transform="rotate(-0.8 540 990)">
    <rect x="94" y="705" width="132" height="34" rx="17" fill="{accent}" fill-opacity="0.90"/>
    <text x="116" y="729" fill="#12151B" font-size="18" font-weight="900" font-family="PingFang SC,Hiragino Sans GB,sans-serif">兼容结论</text>
    {svg_text_lines(verdict_lines, x=94, y=806, size=48 if len(verdict_lines) == 1 else 38, line_height=47, fill="#16181D", weight=900)}
    <text x="94" y="930" fill="#6F7480" font-size="18" font-weight="900" font-family="PingFang SC,Hiragino Sans GB,sans-serif">{RATING_LABELS[rating_context]}</text>
    <text x="94" y="1004" fill="{accent}" font-size="58" font-weight="900" letter-spacing="6" font-family="Arial Unicode MS,DejaVu Sans,sans-serif">{star_display(rating)}</text>
    <text x="94" y="1266" fill="#4F5663" font-size="22" font-weight="800" font-family="PingFang SC,Hiragino Sans GB,Arial Unicode MS,sans-serif">check-mac-game｜输入游戏名，查询 Mac 游戏兼容性</text>
  </g>
  <line x1="52" y1="1360" x2="1028" y2="1360" stroke="#303540" stroke-opacity="0.16" stroke-width="1"/>
  <text x="52" y="1401" fill="#59616E" fill-opacity="0.82" font-size="15" font-weight="900" letter-spacing="1.5" font-family="Arial Black,sans-serif">CHECKED / PRACTICAL / SHAREABLE</text>
</svg>'''


def build_html(
    *,
    game: str,
    verdict: str,
    status: str,
    method: str,
    rating: Optional[int],
    rating_context: str,
    review: str = "",
    background: Optional[Path] = None,
    key_art: Optional[Path] = None,
    character: Optional[Path] = None,
    style: str = DEFAULT_STYLE,
) -> str:
    """Fill the reusable HTML/CSS poster template with exact, escaped content."""
    if not TEMPLATE_PATH.is_file():
        raise RuntimeError(f"share-card HTML template is missing: {TEMPLATE_PATH}")
    template = TEMPLATE_PATH.read_text(encoding="utf-8")
    if style not in SHARE_CARD_STYLES:
        raise ValueError(f"unknown share-card style: {style}")
    style_definition = SHARE_CARD_STYLES[style]
    art_uri = image_data_uri(key_art) or image_data_uri(background)
    title_units = display_width(game)
    verdict_units = display_width(verdict)
    title_size = 108 if title_units <= 8 else 92 if title_units <= 13 else 76 if title_units <= 20 else 62 if title_units <= 28 else 50
    verdict_size = 52 if verdict_units <= 11 else 44 if verdict_units <= 18 else 36 if verdict_units <= 26 else 30
    css_background_styles = {"imac-aluminum", "about-this-mac", "message-tube", "frosted-band", "circle-window", "play-it-mac", "running-macos", "monitor-terminal", "industrial-plate", "terminal-app", "macos-desktop", "letterbox", "serif-study", "polaroid", "blur-stage"}
    m17_fit = "cover"
    m17_art_path = key_art if key_art and key_art.is_file() else background
    if style == "polaroid" and m17_art_path and m17_art_path.is_file():
        dimensions = image_dimensions(m17_art_path)
        if dimensions and dimensions[0] / dimensions[1] < 1.0:
            m17_fit = "contain"
    escaped_art_uri = html.escape(art_uri or "", quote=True)
    replacements = {
        "{{ACCENT}}": STATUS_COLORS[status],
        "{{TITLE_SIZE}}": str(title_size),
        "{{VERDICT_SIZE}}": str(verdict_size),
        "{{MOTIF}}": html.escape(STATUS_MOTIFS[status]),
        "{{GAME}}": html.escape(" ".join(game.split())),
        "{{VERDICT}}": html.escape(" ".join(verdict.split())),
        "{{RATING_LABEL}}": html.escape(RATING_LABELS[rating_context]),
        "{{STARS}}": html.escape(star_display(rating)),
        "{{ART_URI}}": "" if style in css_background_styles else escaped_art_uri,
        "{{M9_ART_URI}}": escaped_art_uri if style == "imac-aluminum" else "",
        "{{M6_ART_URI}}": escaped_art_uri if style == "about-this-mac" else "",
        "{{M3_ART_URI}}": escaped_art_uri if style == "message-tube" else "",
        "{{M7_ART_URI}}": escaped_art_uri if style == "frosted-band" else "",
        "{{M8_ART_URI}}": escaped_art_uri if style == "circle-window" else "",
        "{{M10_ART_URI}}": escaped_art_uri if style == "play-it-mac" else "",
        "{{M11_ART_URI}}": escaped_art_uri if style == "running-macos" else "",
        "{{M5_ART_URI}}": escaped_art_uri if style == "monitor-terminal" else "",
        "{{M12_ART_URI}}": escaped_art_uri if style == "industrial-plate" else "",
        "{{M13_ART_URI}}": escaped_art_uri if style == "terminal-app" else "",
        "{{M14_ART_URI}}": escaped_art_uri if style == "macos-desktop" else "",
        "{{M15_ART_URI}}": escaped_art_uri if style == "letterbox" else "",
        "{{M16_ART_URI}}": escaped_art_uri if style == "serif-study" else "",
        "{{M17_ART_URI}}": escaped_art_uri if style == "polaroid" else "",
        "{{M17_ART_FIT}}": m17_fit,
        "{{M18_ART_URI}}": escaped_art_uri if style == "blur-stage" else "",
        "{{ART_CLASS}}": "is-hidden" if style in css_background_styles or not art_uri else "",
        "{{STYLE_CLASS}}": style_definition["class"],
        "{{STYLE_LABEL}}": style_definition["label"],
    }
    for marker, value in replacements.items():
        template = template.replace(marker, value)
    if re.search(r"\{\{[A-Z_]+\}\}", template):
        raise RuntimeError("share-card HTML template contains an unresolved placeholder")
    return template


def pillow_modules():
    try:
        from PIL import Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps
    except ImportError:
        return None
    return Image, ImageChops, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps


def _hex_color(value: str) -> tuple[int, int, int]:
    value = value.lstrip("#")
    return tuple(int(value[index:index + 2], 16) for index in (0, 2, 4))


def _font(ImageFont: Any, size: int, *, latin: bool = False):
    windows_fonts = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    candidates = [
        "/System/Library/Fonts/Hiragino Sans GB.ttc",
        "/System/Library/Fonts/PingFang.ttc",
        "/System/Library/Fonts/Supplemental/Arial Unicode.ttf",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc",
        str(windows_fonts / "msyh.ttc"),
        str(windows_fonts / "simhei.ttf"),
        str(windows_fonts / "simsun.ttc"),
        str(windows_fonts / "segoeui.ttf"),
    ]
    if latin:
        candidates = [
            "/System/Library/Fonts/Supplemental/Arial Black.ttf",
            "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf",
            str(windows_fonts / "arialbd.ttf"),
            str(windows_fonts / "segoeuib.ttf"),
            *candidates,
        ]
    for candidate in candidates:
        if Path(candidate).is_file():
            try:
                return ImageFont.truetype(candidate, size=size)
            except OSError:
                continue
    raise RuntimeError("no Unicode-capable font available")


def _serif_font(ImageFont: Any, size: int):
    windows_fonts = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    candidates = [
        "/System/Library/Fonts/Supplemental/Songti.ttc",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Bold.ttc",
        "/usr/share/fonts/opentype/noto/NotoSerifCJK-Regular.ttc",
        str(windows_fonts / "simsun.ttc"),
        str(windows_fonts / "simkai.ttf"),
    ]
    for candidate in candidates:
        if Path(candidate).is_file():
            try:
                return ImageFont.truetype(candidate, size=size)
            except OSError:
                continue
    return _font(ImageFont, size)


def _italic_latin_font(ImageFont: Any, size: int):
    windows_fonts = Path(os.environ.get("WINDIR", "C:/Windows")) / "Fonts"
    candidates = [
        "/Library/Fonts/Bodoni Bk BT Book Italic.ttf",
        "/System/Library/Fonts/Supplemental/Georgia Italic.ttf",
        "/usr/share/fonts/truetype/dejavu/DejaVuSerif-Italic.ttf",
        str(windows_fonts / "georgiai.ttf"),
        str(windows_fonts / "timesi.ttf"),
    ]
    for candidate in candidates:
        if Path(candidate).is_file():
            try:
                return ImageFont.truetype(candidate, size=size)
            except OSError:
                continue
    return _font(ImageFont, size, latin=True)


def _flat_image_data(image: Any) -> list[Any]:
    getter = getattr(image, "get_flattened_data", None)
    return list(getter() if getter else image.getdata())


def _prepare_character(path: Path, maximum: tuple[int, int]):
    """Load a cutout and remove a connected light/checkerboard background."""
    modules = pillow_modules()
    if modules is None:
        raise RuntimeError("Pillow is not installed")
    Image, _, ImageDraw, _, _, _, _ = modules
    source = Image.open(path).convert("RGBA")
    alpha = source.getchannel("A")
    if alpha.getextrema()[0] >= 245:
        pixels = _flat_image_data(source.convert("RGB"))
        candidate = Image.new("L", source.size)
        candidate.putdata([
            255 if max(pixel) - min(pixel) <= 30 and sum(pixel) / 3 >= 205 else 0
            for pixel in pixels
        ])
        candidate_pixels = candidate.load()
        width, height = source.size
        edge_points = []
        for x in range(0, width, max(1, width // 32)):
            edge_points.extend(((x, 0), (x, height - 1)))
        for y in range(0, height, max(1, height // 48)):
            edge_points.extend(((0, y), (width - 1, y)))
        for point in edge_points:
            if candidate_pixels[point] == 255:
                ImageDraw.floodfill(candidate, point, 128, thresh=0)
        old_alpha = _flat_image_data(alpha)
        connected = _flat_image_data(candidate)
        alpha.putdata([0 if marker == 128 else value for marker, value in zip(connected, old_alpha)])
        source.putalpha(alpha)
    bounds = source.getchannel("A").getbbox()
    if not bounds:
        raise ValueError("character image has no visible subject")
    source = source.crop(bounds)
    source.thumbnail(maximum, Image.Resampling.LANCZOS)
    return source


def _rounded_image(Image: Any, ImageDraw: Any, ImageOps: Any, source: Path, size: tuple[int, int], radius: int):
    image = Image.open(source).convert("RGB")
    image = ImageOps.fit(image, size, method=Image.Resampling.LANCZOS)
    mask = Image.new("L", size, 0)
    ImageDraw.Draw(mask).rounded_rectangle((0, 0, size[0], size[1]), radius=radius, fill=255)
    return image, mask


def _perspective_coefficients(
    destination: list[tuple[float, float]],
    source: list[tuple[float, float]],
) -> tuple[float, ...]:
    """Return Pillow perspective coefficients mapping destination to source."""
    matrix: list[list[float]] = []
    values: list[float] = []
    for (x, y), (u, v) in zip(destination, source):
        matrix.append([x, y, 1.0, 0.0, 0.0, 0.0, -u * x, -u * y])
        values.append(u)
        matrix.append([0.0, 0.0, 0.0, x, y, 1.0, -v * x, -v * y])
        values.append(v)
    size = len(values)
    for pivot in range(size):
        row = max(range(pivot, size), key=lambda index: abs(matrix[index][pivot]))
        if abs(matrix[row][pivot]) < 1e-12:
            raise ValueError("perspective transform is singular")
        matrix[pivot], matrix[row] = matrix[row], matrix[pivot]
        values[pivot], values[row] = values[row], values[pivot]
        divisor = matrix[pivot][pivot]
        matrix[pivot] = [value / divisor for value in matrix[pivot]]
        values[pivot] /= divisor
        for index in range(size):
            if index == pivot:
                continue
            factor = matrix[index][pivot]
            if factor == 0:
                continue
            matrix[index] = [
                current - factor * reference
                for current, reference in zip(matrix[index], matrix[pivot])
            ]
            values[index] -= factor * values[pivot]
    return tuple(values)


def _lens_sample_point(
    width: int,
    height: int,
    x: float,
    y: float,
    *,
    bevel: float = 48.0,
    strength: float = 22.0,
    magnification: float = 1.012,
) -> tuple[float, float]:
    """Map one lens pixel to the backdrop, concentrating refraction at the rim."""
    center_x = width / 2
    center_y = height / 2
    sample_x = center_x + (x - center_x) / magnification
    sample_y = center_y + (y - center_y) / magnification
    edge_x = max(0.0, 1.0 - min(x, width - x) / bevel) ** 2
    edge_y = max(0.0, 1.0 - min(y, height - y) / bevel) ** 2
    sample_x += (1.0 if x < center_x else -1.0) * strength * edge_x
    sample_y += (1.0 if y < center_y else -1.0) * strength * edge_y
    return (
        min(float(width - 1), max(0.0, sample_x)),
        min(float(height - 1), max(0.0, sample_y)),
    )


def _refract_bevel(image: Any, Image: Any, *, step: int = 24):
    """Warp a correctly aligned backdrop with a curved-edge lens mesh."""
    width, height = image.size
    mesh = []
    for top in range(0, height, step):
        bottom = min(height, top + step)
        for left in range(0, width, step):
            right = min(width, left + step)
            upper_left = _lens_sample_point(width, height, left, top)
            lower_left = _lens_sample_point(width, height, left, bottom)
            lower_right = _lens_sample_point(width, height, right, bottom)
            upper_right = _lens_sample_point(width, height, right, top)
            mesh.append((
                (left, top, right, bottom),
                (*upper_left, *lower_left, *lower_right, *upper_right),
            ))
    return image.transform(
        (width, height),
        Image.Transform.MESH,
        mesh,
        resample=Image.Resampling.BICUBIC,
    )


def _diagonal_gradient(Image: Any, size: tuple[int, int], stops: list[tuple[float, tuple[int, int, int, int]]]):
    """Create a smooth top-left to bottom-right RGBA gradient."""
    preview_size = 256
    pixels = bytearray()
    for y in range(preview_size):
        for x in range(preview_size):
            position = (x + y) / (2 * (preview_size - 1))
            left_position, left_color = stops[0]
            right_position, right_color = stops[-1]
            for index in range(1, len(stops)):
                if position <= stops[index][0]:
                    left_position, left_color = stops[index - 1]
                    right_position, right_color = stops[index]
                    break
            span = max(1e-9, right_position - left_position)
            amount = min(1.0, max(0.0, (position - left_position) / span))
            pixels.extend(round(start + (end - start) * amount) for start, end in zip(left_color, right_color))
    preview = Image.frombytes("RGBA", (preview_size, preview_size), bytes(pixels))
    return preview.resize(size, Image.Resampling.BICUBIC)


def _paper_canvas(Image: Any, ImageDraw: Any):
    top = _hex_color(REFERENCE_GLASS_STYLE["canvas_top"])
    middle = _hex_color(REFERENCE_GLASS_STYLE["canvas_middle"])
    bottom = _hex_color(REFERENCE_GLASS_STYLE["canvas_bottom"])
    canvas = Image.new("RGBA", (WIDTH, HEIGHT), (*top, 255))
    draw = ImageDraw.Draw(canvas, "RGBA")
    for y in range(HEIGHT):
        position = y / max(1, HEIGHT - 1)
        if position <= 0.48:
            amount = position / 0.48
            start, end = top, middle
        else:
            amount = (position - 0.48) / 0.52
            start, end = middle, bottom
        color = tuple(round(a + (b - a) * amount) for a, b in zip(start, end))
        draw.line((0, y, WIDTH, y), fill=(*color, 255))
    return canvas


def _render_cover_story_pillow(
    path: Path,
    *,
    game: str,
    verdict: str,
    rating: Optional[int],
    rating_context: str,
    key_art: Optional[Path],
    background: Optional[Path],
    Image: Any,
    ImageDraw: Any,
    ImageFont: Any,
    ImageOps: Any,
) -> None:
    """Portable raster version of the magazine cover layout."""
    paper = (245, 242, 236, 255)
    ink = (19, 19, 19, 255)
    muted = (138, 133, 120, 255)
    red = (163, 18, 14, 255)
    canvas = Image.new("RGBA", (WIDTH, HEIGHT), paper)
    draw = ImageDraw.Draw(canvas, "RGBA")

    margin = 86
    draw.text((margin, 62), "MAC·GAMING", fill=ink, font=_serif_font(ImageFont, 102))
    draw.line((margin, 230, WIDTH - margin, 230), fill=(19, 19, 19, 115), width=2)
    draw.text((margin, 248), "MAC GAME COMPATIBILITY", fill=muted, font=_font(ImageFont, 25, latin=True))
    draw.text((700, 248), "兼容性专题", fill=muted, font=_font(ImageFont, 25))
    draw.line((margin, 284, WIDTH - margin, 284), fill=(19, 19, 19, 115), width=2)

    art_box = (margin, 316, WIDTH - margin, 792)
    art_source = key_art if key_art and key_art.is_file() else background
    if art_source and art_source.is_file():
        art = Image.open(art_source).convert("RGB")
        art = ImageOps.fit(art, (art_box[2] - art_box[0], art_box[3] - art_box[1]), method=Image.Resampling.LANCZOS, centering=(0.5, 0.38))
        canvas.paste(art, art_box[:2])
    else:
        draw.rectangle(art_box, fill=(220, 216, 207, 255))

    draw.text((margin, 850), "我在Mac上玩", fill=ink, font=_serif_font(ImageFont, 36))
    title = f"《{game}》"
    title_size = 108 if display_width(game) <= 8 else 92 if display_width(game) <= 13 else 76
    title_font = _serif_font(ImageFont, title_size)
    while title_size > 52 and draw.textbbox((0, 0), title, font=title_font)[2] > WIDTH - 2 * margin:
        title_size -= 4
        title_font = _serif_font(ImageFont, title_size)
    # Align the first visible ink pixel with the editorial margin. This removes
    # the large optical side-bearing carried by the opening Chinese book mark.
    title_bbox = draw.textbbox((0, 0), title, font=title_font)
    title_x = margin - title_bbox[0] - round(title_size * .44)
    draw.text((title_x, 912), title, fill=red, font=title_font)

    draw.line((margin, 1152, 676, 1152), fill=(19, 19, 19, 180), width=2)
    draw.text((margin, 1177), RATING_LABELS[rating_context], fill=muted, font=_font(ImageFont, 25))
    draw.text((margin, 1217), verdict, fill=ink, font=_font(ImageFont, 52))
    draw.text((margin, 1290), star_display(rating), fill=red if rating else muted, font=_font(ImageFont, 52))
    draw.text((margin, 1370), "check-mac-game｜输入游戏名，查询 Mac 游戏兼容性", fill=muted, font=_font(ImageFont, 20))
    canvas.convert("RGB").save(path, format="PNG", optimize=True)


def _render_industrial_pillow(
    path: Path,
    *,
    game: str,
    verdict: str,
    rating: Optional[int],
    rating_context: str,
    key_art: Optional[Path],
    background: Optional[Path],
    Image: Any,
    ImageDraw: Any,
    ImageEnhance: Any,
    ImageFilter: Any,
    ImageFont: Any,
    ImageOps: Any,
) -> None:
    """Dependency-light raster fallback for the industrial plate direction."""
    canvas = Image.new("RGBA", (WIDTH, HEIGHT), (20, 20, 20, 255))
    draw = ImageDraw.Draw(canvas, "RGBA")
    accent = _hex_color("#f5c518")
    # Hazard bands remain visible even when no browser is available.
    stripe = 28
    for x in range(-80, WIDTH + 80, stripe * 2):
        draw.polygon([(x, 0), (x + stripe, 0), (x + stripe - 43, 43), (x - 43, 43)], fill=(*accent, 255))
    draw.rectangle((0, 43, WIDTH, 50), fill=(0, 0, 0, 255))
    right_strip = Image.new("RGBA", (WIDTH - 1014, HEIGHT), (20, 20, 20, 255))
    right_draw = ImageDraw.Draw(right_strip, "RGBA")
    for y in range(-HEIGHT, HEIGHT, stripe * 2):
        right_draw.polygon([(0, y), (WIDTH - 1014, y + WIDTH - 1014), (WIDTH - 1014, y + WIDTH - 1014 + stripe), (0, y + stripe)], fill=(*accent, 180))
    canvas.alpha_composite(right_strip, (1014, 0))

    plate = (54, 92, 1026, 697)
    draw.rectangle(plate, fill=(13, 13, 13, 255), outline=(58, 58, 58, 255), width=5)
    art_source = key_art if key_art and key_art.is_file() else background
    if art_source and art_source.is_file():
        try:
            art = Image.open(art_source).convert("RGB")
            art = ImageOps.fit(art, (964, 581), method=Image.Resampling.LANCZOS)
            art = ImageEnhance.Contrast(ImageOps.grayscale(art)).enhance(1.18)
            art = ImageEnhance.Brightness(art).enhance(.95).convert("RGBA")
            canvas.paste(art, (60, 100))
        except (OSError, ValueError):
            pass
    draw = ImageDraw.Draw(canvas, "RGBA")
    draw.rectangle((64, 104, 1016, 693), outline=(51, 51, 51, 255), width=2)

    stencil_font = _font(ImageFont, 138, latin=True)
    stencil = Image.new("RGBA", (900, 210), (0, 0, 0, 0))
    stencil_draw = ImageDraw.Draw(stencil, "RGBA")
    stencil_draw.text((450, 105), "COMPATIBLE", anchor="mm", font=stencil_font, fill=(0, 0, 0, 0), stroke_width=5, stroke_fill=(*accent, 125))
    stencil = stencil.rotate(7, resample=Image.Resampling.BICUBIC, expand=1)
    canvas.alpha_composite(stencil, (90, 280))

    tag_font = _font(ImageFont, 20, latin=True)
    draw = ImageDraw.Draw(canvas, "RGBA")
    draw.rectangle((82, 120, 335, 153), fill=(20, 20, 20, 210), outline=(*accent, 130), width=2)
    draw.text((98, 126), "CAM-04 · KEY ART FEED", fill=accent, font=tag_font)
    coord_font = _font(ImageFont, 18, latin=True)
    draw.text((744, 654), "N 37°46′29″ · W 122°25′09″", fill=(232, 230, 224, 190), font=coord_font)
    for x, y in ((76, 114), (994, 114), (76, 670), (994, 670)):
        draw.ellipse((x, y, x + 15, y + 15), fill=(80, 80, 80, 255), outline=(20, 20, 20, 255), width=2)

    draw.text((54, 740), "我在Mac上玩", fill=(184, 182, 174, 255), font=_font(ImageFont, 41))
    title_font_size = 106
    title = f"《{game}》"
    while title_font_size > 48:
        title_font = _font(ImageFont, title_font_size)
        if draw.textbbox((0, 0), title, font=title_font)[2] <= 972:
            break
        title_font_size -= 4
    draw.text((54, 795), title, fill=(242, 240, 234, 255), font=title_font)

    panel = (54, 956, 1026, 1088)
    draw.rectangle(panel, fill=(*accent, 255), outline=(20, 20, 20, 255), width=4)
    draw.rectangle((68, 974, 84, 990), fill=(20, 20, 20, 255))
    draw.text((96, 972), "兼容结论 / VERDICT", fill=(20, 20, 20, 255), font=_font(ImageFont, 24, latin=True))
    verdict_font_size = 66
    while verdict_font_size > 32:
        verdict_font = _font(ImageFont, verdict_font_size)
        if draw.textbbox((0, 0), verdict, font=verdict_font)[2] <= 700:
            break
        verdict_font_size -= 3
    draw.text((96, 1009), verdict, fill=(20, 20, 20, 255), font=verdict_font)
    draw.text((820, 1006), star_display(rating), fill=(20, 20, 20, 255), font=_font(ImageFont, 57))

    # Barcode and compact metadata at the foot of the plate.
    for x in range(54, 378, 7):
        draw.rectangle((x, 1252, x + (3 if x % 3 else 2), 1299), fill=(216, 214, 207, 255))
    footer_font = _font(ImageFont, 20, latin=True)
    draw.text((420, 1245), "MODEL: MAC-01 · CHECKED", fill=(138, 138, 138, 255), font=footer_font)
    draw.text((420, 1280), "check-mac-game｜输入游戏名，查询 Mac 游戏兼容性。", fill=accent, font=_font(ImageFont, 18))
    canvas.convert("RGB").save(path, format="PNG", optimize=True)


def _render_terminal_pillow(
    path: Path,
    *,
    game: str,
    verdict: str,
    rating: Optional[int],
    key_art: Optional[Path],
    background: Optional[Path],
    Image: Any,
    ImageDraw: Any,
    ImageEnhance: Any,
    ImageFilter: Any,
    ImageFont: Any,
    ImageOps: Any,
) -> None:
    """Dependency-light raster fallback for the Terminal.app direction."""
    canvas = Image.new("RGBA", (WIDTH, HEIGHT), (16, 16, 20, 255))
    art_source = key_art if key_art and key_art.is_file() else background
    if art_source and art_source.is_file():
        try:
            art = ImageOps.fit(Image.open(art_source).convert("RGB"), (WIDTH, HEIGHT), method=Image.Resampling.LANCZOS)
            art = ImageEnhance.Brightness(art).enhance(.16)
            art = ImageEnhance.Color(art).enhance(1.1).convert("RGBA")
            canvas.alpha_composite(art)
        except (OSError, ValueError):
            pass
    overlay = Image.new("RGBA", (WIDTH, HEIGHT), (16, 16, 20, 0))
    od = ImageDraw.Draw(overlay, "RGBA")
    od.rectangle((0, 0, WIDTH, HEIGHT), fill=(16, 16, 20, 125))
    canvas.alpha_composite(overlay)
    draw = ImageDraw.Draw(canvas, "RGBA")
    win = (54, 97, 1026, 820)
    draw.rounded_rectangle(win, radius=20, fill=(30, 30, 36, 224), outline=(255, 255, 255, 42), width=2)
    draw.rounded_rectangle((54, 97, 1026, 147), radius=20, fill=(60, 60, 66, 150))
    draw.rectangle((54, 124, 1026, 147), fill=(60, 60, 66, 150))
    for x, color in ((76, (255, 95, 87, 255)), (103, (254, 188, 46, 255)), (130, (40, 200, 64, 255))):
        draw.ellipse((x, 117, x + 17, 134), fill=color)
    bar_font = _font(ImageFont, 22)
    draw.text((350, 115), "兼容检测 — zsh — 92×26", fill=(255, 255, 255, 160), font=bar_font)
    mono = _font(ImageFont, 28)
    lines = [
        ("$", (50, 215, 75, 255)), (f" check-mac-game \"{game}\"", (232, 232, 237, 255)),
        ("$", (50, 215, 75, 255)), (" compatibility-scan --platform macOS", (142, 142, 147, 255)),
        ("✓ 兼容结论：", (50, 215, 75, 255)), (verdict, (255, 255, 255, 255)),
        ("★ 玩家评级：", (50, 215, 75, 255)), (star_display(rating), (255, 214, 10, 255)),
    ]
    y = 185
    for index in range(0, len(lines), 2):
        prefix, prefix_color = lines[index]
        suffix, suffix_color = lines[index + 1]
        draw.text((86, y), prefix, fill=prefix_color, font=mono)
        bbox = draw.textbbox((86, y), prefix, font=mono)
        draw.text((bbox[2], y), suffix, fill=suffix_color, font=mono)
        y += 58
    # Centered headline and frosted result chip.
    draw.text((WIDTH // 2, 615), "我在Mac上玩", anchor="mm", fill=(161, 161, 166, 255), font=_font(ImageFont, 38))
    title = f"《{game}》"
    size = 95
    while size > 46 and draw.textbbox((0, 0), title, font=_font(ImageFont, size))[2] > 940:
        size -= 3
    draw.text((WIDTH // 2, 680), title, anchor="mm", fill=(255, 255, 255, 255), font=_font(ImageFont, size))
    chip = (100, 860, 980, 952)
    draw.rounded_rectangle(chip, radius=46, fill=(255, 255, 255, 26), outline=(255, 255, 255, 66), width=2)
    draw.text((132, 890), "兼容结论", fill=(161, 161, 166, 255), font=_font(ImageFont, 25))
    verdict_size = 52
    while verdict_size > 30 and draw.textbbox((0, 0), verdict, font=_font(ImageFont, verdict_size))[2] > 490:
        verdict_size -= 2
    draw.text((285, 880), verdict, fill=(100, 210, 255, 255), font=_font(ImageFont, verdict_size))
    draw.text((760, 880), star_display(rating), fill=(255, 214, 10, 255), font=_font(ImageFont, 42))
    footer = "check-mac-game｜输入游戏名，查询 Mac 游戏兼容性。"
    draw.text((WIDTH // 2, 1350), footer, anchor="mm", fill=(134, 134, 139, 255), font=_font(ImageFont, 24))
    canvas.convert("RGB").save(path, format="PNG", optimize=True)


def _render_macos_desktop_pillow(
    path: Path,
    *,
    game: str,
    verdict: str,
    rating: Optional[int],
    rating_context: str,
    key_art: Optional[Path],
    background: Optional[Path],
    Image: Any,
    ImageDraw: Any,
    ImageEnhance: Any,
    ImageFilter: Any,
    ImageFont: Any,
    ImageOps: Any,
) -> None:
    """Dependency-light raster fallback for the macOS desktop direction."""
    canvas = Image.new("RGBA", (WIDTH, HEIGHT), (15, 18, 25, 255))
    art_source = key_art if key_art and key_art.is_file() else background
    if art_source and art_source.is_file():
        try:
            art = ImageOps.fit(Image.open(art_source).convert("RGB"), (WIDTH, HEIGHT), method=Image.Resampling.LANCZOS)
            art = ImageEnhance.Brightness(art).enhance(.92).convert("RGBA")
            canvas.alpha_composite(art)
        except (OSError, ValueError):
            pass
    shade = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shade, "RGBA")
    for y in range(HEIGHT):
        if y < 170:
            alpha = round(48 * (1 - y / 170))
        elif y > 1080:
            alpha = round(92 * min(1, (y - 1080) / 360))
        else:
            alpha = 0
        if alpha:
            sd.line((0, y, WIDTH, y), fill=(0, 0, 0, alpha))
    canvas.alpha_composite(shade)
    draw = ImageDraw.Draw(canvas, "RGBA")
    # Menu bar.
    draw.rectangle((0, 0, WIDTH, 52), fill=(0, 0, 0, 100))
    menu_font = _font(ImageFont, 22)
    draw.text((24, 15), "●  访达   文件   编辑   显示   帮助", fill=(255, 255, 255, 245), font=menu_font)
    draw.text((780, 15), "BAT   WiFi   周三 9:41", fill=(255, 255, 255, 235), font=menu_font)
    # Notification card.
    card = (86, 130, 994, 555)
    glass = Image.new("RGBA", (card[2] - card[0], card[3] - card[1]), (255, 255, 255, 0))
    gd = ImageDraw.Draw(glass, "RGBA")
    gd.rounded_rectangle((0, 0, glass.width - 1, glass.height - 1), radius=30, fill=(255, 255, 255, 216), outline=(255, 255, 255, 238), width=2)
    glass = glass.filter(ImageFilter.GaussianBlur(.35))
    canvas.alpha_composite(glass, (card[0], card[1]))
    draw = ImageDraw.Draw(canvas, "RGBA")
    draw.rounded_rectangle((120, 164, 190, 234), radius=18, fill=(94, 92, 230, 255))
    draw.text((155, 199), "C", anchor="mm", fill=(255, 255, 255, 255), font=_font(ImageFont, 40, latin=True))
    title = f"《{game}》· 兼容检测完成"
    title_size = 34
    while title_size > 24 and draw.textbbox((0, 0), title, font=_font(ImageFont, title_size))[2] > 740:
        title_size -= 2
    draw.text((214, 164), title, fill=(29, 29, 31, 255), font=_font(ImageFont, title_size))
    draw.text((214, 207), "check-mac-game 刚刚", fill=(110, 110, 115, 255), font=_font(ImageFont, 23))
    verdict_size = 68
    while verdict_size > 38 and draw.textbbox((0, 0), verdict, font=_font(ImageFont, verdict_size))[2] > 810:
        verdict_size -= 3
    draw.text((120, 275), verdict, fill=(0, 113, 227, 255), font=_font(ImageFont, verdict_size))
    draw.text((120, 370), star_display(rating), fill=(255, 159, 10, 255), font=_font(ImageFont, 52))
    draw.text((430, 386), RATING_LABELS[rating_context], fill=(110, 110, 115, 255), font=_font(ImageFont, 24))
    draw.line((120, 450, 960, 450), fill=(0, 0, 0, 22), width=2)
    prefix = f"我在Mac上玩《{game}》"
    prefix_size = 27
    while prefix_size > 20 and draw.textbbox((0, 0), prefix, font=_font(ImageFont, prefix_size))[2] > 830:
        prefix_size -= 1
    draw.text((120, 477), prefix, fill=(110, 110, 115, 255), font=_font(ImageFont, prefix_size))
    # Dock with six reusable system-colored app tiles.
    dock = (184, 1248, 896, 1375)
    draw.rounded_rectangle(dock, radius=28, fill=(255, 255, 255, 74), outline=(255, 255, 255, 92), width=2)
    colors = ((106, 92, 255), (255, 55, 95), (48, 209, 88), (10, 132, 255), (255, 159, 10), (94, 92, 230))
    symbols = ("G", "W", "M", "C", "P", "S")
    for index, (color, symbol) in enumerate(zip(colors, symbols)):
        x = 208 + index * 112
        y = 1268 - (10 if index == 0 else 0)
        draw.rounded_rectangle((x, y, x + 88, y + 88), radius=20, fill=(*color, 255))
        draw.text((x + 44, y + 44), symbol, anchor="mm", fill=(255, 255, 255, 255), font=_font(ImageFont, 42, latin=True))
        if index == 0:
            draw.ellipse((x + 40, y + 99, x + 48, y + 107), fill=(255, 255, 255, 255))
    draw.text((WIDTH // 2, 1412), "check-mac-game｜输入游戏名，查询 Mac 游戏兼容性。", anchor="mm", fill=(255, 255, 255, 225), font=_font(ImageFont, 21))
    canvas.convert("RGB").save(path, format="PNG", optimize=True)


def _render_letterbox_pillow(
    path: Path,
    *,
    game: str,
    verdict: str,
    rating: Optional[int],
    key_art: Optional[Path],
    background: Optional[Path],
    Image: Any,
    ImageDraw: Any,
    ImageEnhance: Any,
    ImageFont: Any,
    ImageOps: Any,
) -> None:
    """Dependency-light raster fallback for the T06 letterbox direction."""
    canvas = Image.new("RGBA", (WIDTH, HEIGHT), (13, 11, 9, 255))
    art_source = key_art if key_art and key_art.is_file() else background
    strip_top, strip_height = 432, 432
    if art_source and art_source.is_file():
        try:
            art = ImageOps.fit(
                Image.open(art_source).convert("RGB"),
                (WIDTH, strip_height),
                method=Image.Resampling.LANCZOS,
                centering=(.5, .45),
            )
            art = ImageEnhance.Brightness(art).enhance(.82).convert("RGBA")
            canvas.alpha_composite(art, (0, strip_top))
        except (OSError, ValueError):
            pass
    draw = ImageDraw.Draw(canvas, "RGBA")
    # Darken the strip edges so arbitrary artwork merges into the black bars.
    for x in range(190):
        alpha = round(104 * (1 - x / 190))
        draw.line((x, strip_top, x, strip_top + strip_height), fill=(13, 11, 9, alpha))
        draw.line((WIDTH - 1 - x, strip_top, WIDTH - 1 - x, strip_top + strip_height), fill=(13, 11, 9, alpha))
    draw.text((WIDTH // 2, 168), "MAC GAME CHECK", anchor="mm", fill=(232, 226, 214, 145), font=_font(ImageFont, 27, latin=True))
    draw.text((WIDTH // 2, 252), "我在Mac上玩", anchor="mm", fill=(232, 226, 214, 215), font=_font(ImageFont, 38))
    title = f"《{game}》"
    title_size = 96
    while title_size > 50 and draw.textbbox((0, 0), title, font=_font(ImageFont, title_size))[2] > 930:
        title_size -= 3
    draw.text((WIDTH // 2, 1010), title, anchor="mm", fill=(244, 238, 224, 255), font=_font(ImageFont, title_size))
    verdict_text = f"兼容结论 · {verdict}"
    verdict_size = 42
    while verdict_size > 27 and draw.textbbox((0, 0), verdict_text, font=_font(ImageFont, verdict_size))[2] > 900:
        verdict_size -= 2
    gold = (184, 134, 45, 255)
    draw.text((WIDTH // 2, 1162), verdict_text, anchor="mm", fill=gold, font=_font(ImageFont, verdict_size))
    draw.text((WIDTH // 2, 1260), star_display(rating), anchor="mm", fill=gold, font=_font(ImageFont, 44))
    draw.text((WIDTH // 2, 1384), "check-mac-game｜输入游戏名，查询 Mac 游戏兼容性", anchor="mm", fill=(255, 255, 255, 115), font=_font(ImageFont, 20))
    canvas.convert("RGB").save(path, format="PNG", optimize=True)


def _render_serif_study_pillow(
    path: Path,
    *,
    game: str,
    verdict: str,
    rating: Optional[int],
    key_art: Optional[Path],
    background: Optional[Path],
    Image: Any,
    ImageDraw: Any,
    ImageFilter: Any,
    ImageFont: Any,
    ImageOps: Any,
) -> None:
    """Dependency-light raster fallback for the pale Serif Study direction."""
    canvas = Image.new("RGBA", (WIDTH, HEIGHT), (250, 248, 244, 255))
    draw = ImageDraw.Draw(canvas, "RGBA")
    ink = (20, 18, 16, 255)
    muted = (138, 133, 120, 255)
    red = (179, 35, 27, 255)
    draw.text((86, 80), "CHECK-MAC-GAME", fill=muted, font=_font(ImageFont, 24, latin=True))
    draw.text((994, 80), "No. 09", anchor="ra", fill=muted, font=_font(ImageFont, 24, latin=True))
    draw.line((86, 126, 994, 126), fill=ink, width=2)
    draw.text((WIDTH // 2, 240), "我在Mac上玩", anchor="mm", fill=ink, font=_serif_font(ImageFont, 58))
    title = f"《{game}》"
    title_size = 96
    while title_size > 50 and draw.textbbox((0, 0), title, font=_serif_font(ImageFont, title_size))[2] > 900:
        title_size -= 3
    draw.text((WIDTH // 2, 345), title, anchor="mm", fill=ink, font=_serif_font(ImageFont, title_size))
    art_box = (86, 590, 994, 892)
    shadow = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    sd = ImageDraw.Draw(shadow, "RGBA")
    sd.rectangle((86, 602, 994, 916), fill=(20, 18, 16, 54))
    canvas.alpha_composite(shadow.filter(ImageFilter.GaussianBlur(18)))
    art_source = key_art if key_art and key_art.is_file() else background
    if art_source and art_source.is_file():
        try:
            art = ImageOps.fit(
                Image.open(art_source).convert("RGB"),
                (art_box[2] - art_box[0], art_box[3] - art_box[1]),
                method=Image.Resampling.LANCZOS,
                centering=(.5, .2),
            ).convert("RGBA")
            canvas.alpha_composite(art, (art_box[0], art_box[1]))
        except (OSError, ValueError):
            pass
    draw = ImageDraw.Draw(canvas, "RGBA")
    draw.rectangle(art_box, outline=ink, width=2)
    draw.text((WIDTH // 2, 950), "Game Compatibility on macOS", anchor="mm", fill=red, font=_italic_latin_font(ImageFont, 38))
    draw.text((WIDTH // 2, 1027), "兼 容 结 论", anchor="mm", fill=muted, font=_serif_font(ImageFont, 25))
    verdict_size = 54
    while verdict_size > 30 and draw.textbbox((0, 0), verdict, font=_serif_font(ImageFont, verdict_size))[2] > 860:
        verdict_size -= 2
    draw.text((WIDTH // 2, 1090), verdict, anchor="mm", fill=ink, font=_serif_font(ImageFont, verdict_size))
    draw.text((WIDTH // 2, 1215), star_display(rating), anchor="mm", fill=red, font=_font(ImageFont, 48))
    draw.line((86, 1325, 994, 1325), fill=(216, 210, 198, 255), width=2)
    draw.text((WIDTH // 2, 1370), "check-mac-game｜输入游戏名，查询 Mac 游戏兼容性。", anchor="mm", fill=muted, font=_font(ImageFont, 20))
    canvas.convert("RGB").save(path, format="PNG", optimize=True)


def _render_polaroid_pillow(
    path: Path,
    *,
    game: str,
    verdict: str,
    rating: Optional[int],
    key_art: Optional[Path],
    background: Optional[Path],
    Image: Any,
    ImageDraw: Any,
    ImageFilter: Any,
    ImageFont: Any,
    ImageOps: Any,
) -> None:
    """Dependency-light raster fallback for the taped Polaroid direction."""
    canvas = Image.new("RGBA", (WIDTH, HEIGHT), (31, 24, 17, 255))
    wall = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    wd = ImageDraw.Draw(wall, "RGBA")
    for y in range(HEIGHT):
        mix = y / max(1, HEIGHT - 1)
        wd.line((0, y, WIDTH, y), fill=(42 - round(19 * mix), 33 - round(15 * mix), 24 - round(12 * mix), 255))
    canvas.alpha_composite(wall)

    photo = Image.new("RGBA", (842, 770), (247, 244, 236, 255))
    pd = ImageDraw.Draw(photo, "RGBA")
    art_box = (43, 43, 799, 629)
    pd.rectangle(art_box, fill=(50, 42, 32, 255))
    art_source = key_art if key_art and key_art.is_file() else background
    if art_source and art_source.is_file():
        try:
            source = Image.open(art_source).convert("RGB")
            target_size = (art_box[2] - art_box[0], art_box[3] - art_box[1])
            if source.width / max(1, source.height) < 1.0:
                art = ImageOps.contain(source, target_size, method=Image.Resampling.LANCZOS).convert("RGBA")
                x = art_box[0] + (target_size[0] - art.width) // 2
                y = art_box[1] + (target_size[1] - art.height) // 2
                photo.alpha_composite(art, (x, y))
            else:
                art = ImageOps.fit(source, target_size, method=Image.Resampling.LANCZOS, centering=(.5, .5)).convert("RGBA")
                photo.alpha_composite(art, (art_box[0], art_box[1]))
        except (OSError, ValueError):
            pass
    hand_prefix = f"《{game}》 — "
    hand = hand_prefix + verdict
    hand_size = 31
    while hand_size > 21 and pd.textbbox((0, 0), hand, font=_font(ImageFont, hand_size))[2] > 735:
        hand_size -= 1
    hand_font = _font(ImageFont, hand_size)
    pd.text((45, 665), hand_prefix, fill=(58, 50, 39, 255), font=hand_font)
    prefix_width = pd.textbbox((45, 665), hand_prefix, font=hand_font)[2] - 45
    pd.text((45 + prefix_width, 665), verdict, fill=(138, 95, 28, 255), font=hand_font)

    shadow = Image.new("RGBA", photo.size, (0, 0, 0, 160)).filter(ImageFilter.GaussianBlur(28))
    shadow = shadow.rotate(2.4, resample=Image.Resampling.BICUBIC, expand=True)
    canvas.alpha_composite(shadow, (119, 144))
    photo = photo.rotate(2.4, resample=Image.Resampling.BICUBIC, expand=True)
    canvas.alpha_composite(photo, (105, 116))
    draw = ImageDraw.Draw(canvas, "RGBA")
    tape = (240, 228, 196, 190)
    left_tape = Image.new("RGBA", (250, 80), tape).rotate(45, resample=Image.Resampling.BICUBIC, expand=True)
    right_tape = Image.new("RGBA", (250, 80), tape).rotate(-45, resample=Image.Resampling.BICUBIC, expand=True)
    canvas.alpha_composite(left_tape, (-25, 70))
    canvas.alpha_composite(right_tape, (875, 70))
    draw = ImageDraw.Draw(canvas, "RGBA")
    draw.text((WIDTH // 2, 1044), "PHOTO · FOUND ON MAC", anchor="mm", fill=(232, 226, 214, 155), font=_font(ImageFont, 24, latin=True))
    title = "我在Mac上玩"
    draw.text((WIDTH // 2, 1147), title, anchor="mm", fill=(244, 238, 224, 255), font=_font(ImageFont, 68))
    draw.text((WIDTH // 2, 1277), star_display(rating), anchor="mm", fill=(184, 134, 45, 255), font=_font(ImageFont, 45))
    draw.text((WIDTH // 2, 1386), "check-mac-game｜输入游戏名，查询 Mac 游戏兼容性", anchor="mm", fill=(255, 255, 255, 112), font=_font(ImageFont, 20))
    canvas.convert("RGB").save(path, format="PNG", optimize=True)


def render_png_pillow(
    path: Path,
    *,
    game: str,
    verdict: str,
    status: str,
    method: str,
    rating: Optional[int],
    rating_context: str,
    review: str = "",
    background: Optional[Path] = None,
    key_art: Optional[Path] = None,
    character: Optional[Path] = None,
    style: str = DEFAULT_STYLE,
) -> None:
    modules = pillow_modules()
    if modules is None:
        raise RuntimeError("Pillow is not installed")
    Image, _, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps = modules
    if style == "cover-story":
        _render_cover_story_pillow(
            path,
            game=game,
            verdict=verdict,
            rating=rating,
            rating_context=rating_context,
            key_art=key_art,
            background=background,
            Image=Image,
            ImageDraw=ImageDraw,
            ImageFont=ImageFont,
            ImageOps=ImageOps,
        )
        return
    if style == "industrial-plate":
        _render_industrial_pillow(
            path,
            game=game,
            verdict=verdict,
            rating=rating,
            rating_context=rating_context,
            key_art=key_art,
            background=background,
            Image=Image,
            ImageDraw=ImageDraw,
            ImageEnhance=ImageEnhance,
            ImageFilter=ImageFilter,
            ImageFont=ImageFont,
            ImageOps=ImageOps,
        )
        return
    if style == "terminal-app":
        _render_terminal_pillow(
            path,
            game=game,
            verdict=verdict,
            rating=rating,
            key_art=key_art,
            background=background,
            Image=Image,
            ImageDraw=ImageDraw,
            ImageEnhance=ImageEnhance,
            ImageFilter=ImageFilter,
            ImageFont=ImageFont,
            ImageOps=ImageOps,
        )
        return
    if style == "macos-desktop":
        _render_macos_desktop_pillow(
            path,
            game=game,
            verdict=verdict,
            rating=rating,
            rating_context=rating_context,
            key_art=key_art,
            background=background,
            Image=Image,
            ImageDraw=ImageDraw,
            ImageEnhance=ImageEnhance,
            ImageFilter=ImageFilter,
            ImageFont=ImageFont,
            ImageOps=ImageOps,
        )
        return
    if style == "letterbox":
        _render_letterbox_pillow(
            path,
            game=game,
            verdict=verdict,
            rating=rating,
            key_art=key_art,
            background=background,
            Image=Image,
            ImageDraw=ImageDraw,
            ImageEnhance=ImageEnhance,
            ImageFont=ImageFont,
            ImageOps=ImageOps,
        )
        return
    if style == "serif-study":
        _render_serif_study_pillow(
            path,
            game=game,
            verdict=verdict,
            rating=rating,
            key_art=key_art,
            background=background,
            Image=Image,
            ImageDraw=ImageDraw,
            ImageFilter=ImageFilter,
            ImageFont=ImageFont,
            ImageOps=ImageOps,
        )
        return
    if style == "polaroid":
        _render_polaroid_pillow(
            path,
            game=game,
            verdict=verdict,
            rating=rating,
            key_art=key_art,
            background=background,
            Image=Image,
            ImageDraw=ImageDraw,
            ImageFilter=ImageFilter,
            ImageFont=ImageFont,
            ImageOps=ImageOps,
        )
        return
    accent = _hex_color(STATUS_COLORS[status])
    ink = _hex_color(REFERENCE_GLASS_STYLE["ink"])
    muted = _hex_color(REFERENCE_GLASS_STYLE["muted"])
    copy_color = (37, 42, 51)
    scene = _paper_canvas(Image, ImageDraw)

    # The approved background is intentionally quiet: a pale editorial canvas,
    # two low-opacity color washes, and official art used as atmosphere. A
    # generated sci-fi light field is not part of the default design.
    lights = Image.new("RGBA", (WIDTH, HEIGHT), (0, 0, 0, 0))
    light_draw = ImageDraw.Draw(lights, "RGBA")
    light_draw.ellipse((-340, 320, 480, 1120), fill=(*accent, 28))
    light_draw.ellipse((650, -180, 1390, 540), fill=(255, 114, 91, 18))
    scene.alpha_composite(lights.filter(ImageFilter.GaussianBlur(92)))

    ambience_source = background if background and background.is_file() else key_art
    if ambience_source and ambience_source.is_file():
        try:
            ambience = Image.open(ambience_source).convert("RGB")
            ambience = ImageOps.fit(ambience, (WIDTH, 760), method=Image.Resampling.LANCZOS)
            ambience = ImageEnhance.Color(ambience).enhance(0.75)
            ambience = ambience.filter(ImageFilter.GaussianBlur(1.0)).convert("RGBA")
            fade = Image.new("L", (WIDTH, 760), 0)
            fade_draw = ImageDraw.Draw(fade)
            for x in range(WIDTH):
                alpha = round(34 * min(1.0, max(0.0, (x / WIDTH - 0.05) / 0.45)))
                fade_draw.line((x, 0, x, 760), fill=alpha)
            ambience.putalpha(fade)
            scene.alpha_composite(ambience, (120, 80))
        except (OSError, ValueError):
            pass

    scene_draw = ImageDraw.Draw(scene, "RGBA")
    art_box = (52, 226, 1028, 730)
    art_source = key_art if key_art and key_art.is_file() else background
    if art_source and art_source.is_file():
        try:
            art, mask = _rounded_image(Image, ImageDraw, ImageOps, art_source, (976, 504), 32)
            scene.paste(art, (52, 226), mask)
        except (OSError, ValueError):
            scene_draw.rounded_rectangle(art_box, radius=32, fill=(233, 237, 243, 255))
    else:
        scene_draw.rounded_rectangle(art_box, radius=32, fill=(233, 237, 243, 255))
        scene_draw.ellipse((610, 170, 1160, 720), fill=(*accent, 34))
    scene_draw.rounded_rectangle(art_box, radius=32, outline=(255, 255, 255, 194), width=2)

    if character and character.is_file():
        try:
            cutout = _prepare_character(character, (450, 720))
            alpha = cutout.getchannel("A")
            shadow_alpha = alpha.filter(ImageFilter.GaussianBlur(16))
            shadow = Image.new("RGBA", cutout.size, (0, 0, 0, 0))
            shadow.putalpha(shadow_alpha.point(lambda value: int(value * 0.42)))
            character_x = 1060 - cutout.width
            character_y = 120 + max(0, (650 - cutout.height) // 2)
            scene.alpha_composite(shadow, (character_x + 14, character_y + 22))
            scene.alpha_composite(cutout, (character_x, character_y))
        except (OSError, RuntimeError, ValueError):
            pass

    scene_draw = ImageDraw.Draw(scene, "RGBA")
    scene_draw.rounded_rectangle((52, 54, 64, 92), radius=6, fill=accent)
    scene_draw.text((82, 56), "CHECK / MAC / GAME", fill=ink, font=_font(ImageFont, 23, latin=True))
    scene_draw.text((52, 103), "EDITORIAL GLASS COMPATIBILITY REVIEW", fill=muted, font=_font(ImageFont, 14, latin=True))
    title_lines = wrap_units(f"《{game}》", 10.8, 2)
    title_size = 74 if len(title_lines) == 1 else 60
    title_font = _font(ImageFont, title_size)
    scene_draw.text((52, 132), "我在Mac上玩", fill=ink, font=_font(ImageFont, 25))
    title_y = 174
    for line in title_lines:
        scene_draw.text((52, title_y), line, fill=ink, font=title_font)
        title_y += title_size + 4

    panel_width, panel_height = 936, 640
    destination = [(52.0, 654.0), (1028.0, 640.0), (1012.0, 1302.0), (68.0, 1318.0)]
    source_points = [
        (0.0, 0.0),
        (float(panel_width), 0.0),
        (float(panel_width), float(panel_height)),
        (0.0, float(panel_height)),
    ]
    # Match CSS backdrop-filter: sample the exact scene behind the pane, blur it,
    # and gently raise saturation before applying the translucent glass fill.
    extraction = _perspective_coefficients(source_points, destination)
    sample = scene.convert("RGB").transform(
        (panel_width, panel_height),
        Image.Transform.PERSPECTIVE,
        extraction,
        resample=Image.Resampling.BICUBIC,
    )
    sample = sample.filter(ImageFilter.GaussianBlur(REFERENCE_GLASS_STYLE["blur_radius"]))
    sample = ImageEnhance.Color(sample).enhance(REFERENCE_GLASS_STYLE["saturation"])

    glass_mask = Image.new("L", (panel_width, panel_height), 0)
    mask_draw = ImageDraw.Draw(glass_mask)
    mask_draw.rounded_rectangle((0, 0, panel_width - 1, panel_height - 1), radius=44, fill=255)
    panel = sample.convert("RGBA")
    glass_fill = _diagonal_gradient(Image, (panel_width, panel_height), [
        (0.0, REFERENCE_GLASS_STYLE["glass_start"]),
        (0.46, REFERENCE_GLASS_STYLE["glass_middle"]),
        (1.0, REFERENCE_GLASS_STYLE["glass_end"]),
    ])
    panel = Image.alpha_composite(panel, glass_fill)
    panel.putalpha(glass_mask)

    panel_draw = ImageDraw.Draw(panel, "RGBA")
    panel_draw.rounded_rectangle(
        (1, 1, panel_width - 2, panel_height - 2),
        radius=42,
        outline=REFERENCE_GLASS_STYLE["border"],
        width=2,
    )
    panel_draw.rounded_rectangle(
        (4, 4, panel_width - 5, panel_height - 5),
        radius=39,
        outline=(255, 255, 255, 34),
        width=1,
    )
    panel_draw.line((58, 15, panel_width - 160, 15), fill=REFERENCE_GLASS_STYLE["inner_top"], width=2)
    panel_draw.line((20, 64, 20, panel_height - 110), fill=(255, 255, 255, 132), width=2)
    panel_draw.line((150, panel_height - 15, panel_width - 54, panel_height - 15), fill=REFERENCE_GLASS_STYLE["inner_bottom"], width=2)
    reflection = Image.new("RGBA", (panel_width, panel_height), (0, 0, 0, 0))
    reflection_draw = ImageDraw.Draw(reflection, "RGBA")
    reflection_draw.polygon(
        [(652, -40), (718, -30), (500, panel_height + 20), (440, panel_height + 20)],
        fill=(255, 255, 255, 25),
    )
    reflection = reflection.filter(ImageFilter.GaussianBlur(18))
    panel.alpha_composite(reflection)
    panel_draw = ImageDraw.Draw(panel, "RGBA")

    panel_draw.rounded_rectangle((42, 36, 174, 70), radius=17, fill=(*accent, 226))
    panel_draw.text((64, 41), "兼容结论", fill=(18, 21, 27), font=_font(ImageFont, 18))
    verdict_lines = wrap_units(verdict, 18, 2)
    verdict_font = _font(ImageFont, 48 if len(verdict_lines) == 1 else 38)
    verdict_y = 88
    for line in verdict_lines:
        panel_draw.text((42, verdict_y), line, fill=ink, font=verdict_font)
        verdict_y += 47

    panel_draw.text((42, 208), RATING_LABELS[rating_context], fill=muted, font=_font(ImageFont, 18))
    panel_draw.text((42, 248), star_display(rating), fill=accent if rating else muted, font=_font(ImageFont, 58))
    panel_draw.text(
        (42, 582),
        "check-mac-game｜输入游戏名，查询 Mac 游戏兼容性",
        fill=(79, 86, 99),
        font=_font(ImageFont, 22),
    )

    coefficients = _perspective_coefficients(destination, source_points)
    warped = panel.transform(
        (WIDTH, HEIGHT),
        Image.Transform.PERSPECTIVE,
        coefficients,
        resample=Image.Resampling.BICUBIC,
        fillcolor=(0, 0, 0, 0),
    )
    shadow_alpha = warped.getchannel("A").filter(ImageFilter.GaussianBlur(28))
    shadow = Image.new("RGBA", (WIDTH, HEIGHT), REFERENCE_GLASS_STYLE["shadow"])
    shadow.putalpha(shadow_alpha.point(lambda value: int(value * 0.13)))
    scene.alpha_composite(shadow, (0, 24))
    scene.alpha_composite(warped)

    final_draw = ImageDraw.Draw(scene, "RGBA")
    final_draw.text((52, 1378), "CHECKED / PRACTICAL / SHAREABLE", fill=(89, 97, 110, 190), font=_font(ImageFont, 15, latin=True))
    final_draw.line((52, 1360, 1028, 1360), fill=(48, 53, 64, 40), width=1)
    scene.convert("RGB").save(path, format="PNG", optimize=True)


def slugify(value: str) -> str:
    value = re.sub(r"[^\w\-\u3400-\u9fff]+", "-", value, flags=re.UNICODE).strip("-_")
    return (value[:40] or "game").lower()


def unique_path(directory: Path, stem: str, suffix: str) -> Path:
    candidate_stem = stem
    index = 2
    while any((directory / f"{candidate_stem}{existing_suffix}").exists() for existing_suffix in {suffix, ".html", ".svg", ".png"}):
        candidate_stem = f"{stem}-{index}"
        index += 1
    return directory / f"{candidate_stem}{suffix}"


def headless_browser_candidates() -> list[Path]:
    candidates: list[Path] = []
    configured = os.environ.get("CHECK_MAC_GAME_BROWSER")
    if configured:
        candidates.append(Path(configured).expanduser())
    for name in (
        "google-chrome-stable",
        "google-chrome",
        "chromium",
        "chromium-browser",
        "microsoft-edge",
    ):
        executable = shutil.which(name)
        if executable:
            candidates.append(Path(executable))
    candidates.extend([
        Path("/Applications/Google Chrome.app/Contents/MacOS/Google Chrome"),
        Path("/Applications/Chromium.app/Contents/MacOS/Chromium"),
        Path("/Applications/Microsoft Edge.app/Contents/MacOS/Microsoft Edge"),
    ])
    for root_name in ("PROGRAMFILES", "PROGRAMFILES(X86)", "LOCALAPPDATA"):
        root = os.environ.get(root_name)
        if not root:
            continue
        candidates.extend([
            Path(root) / "Google" / "Chrome" / "Application" / "chrome.exe",
            Path(root) / "Chromium" / "Application" / "chrome.exe",
            Path(root) / "Microsoft" / "Edge" / "Application" / "msedge.exe",
        ])
    output: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        resolved = str(candidate)
        if resolved not in seen and candidate.is_file():
            output.append(candidate)
            seen.add(resolved)
    return output


def node_candidates() -> list[Path]:
    candidates: list[Path] = []
    configured = os.environ.get("CHECK_MAC_GAME_NODE")
    if configured:
        candidates.append(Path(configured).expanduser())
    executable = shutil.which("node")
    if executable:
        candidates.append(Path(executable))
    candidates.append(
        Path.home() / ".cache" / "codex-runtimes" / "codex-primary-runtime" /
        "dependencies" / "node" / "bin" / "node"
    )
    output: list[Path] = []
    seen: set[str] = set()
    for candidate in candidates:
        value = str(candidate)
        if value not in seen and candidate.is_file():
            output.append(candidate)
            seen.add(value)
    return output


def capture_html(html_path: Path, png_path: Path) -> tuple[bool, Optional[str]]:
    """Render local HTML with an available Chromium-family headless browser."""
    errors: list[str] = []
    browsers = headless_browser_candidates()
    browser_argument = str(browsers[0]) if browsers else ""
    if CAPTURE_HELPER_PATH.is_file():
        for node in node_candidates():
            png_path.unlink(missing_ok=True)
            try:
                process = subprocess.run(
                    [str(node), str(CAPTURE_HELPER_PATH), str(html_path), str(png_path), browser_argument],
                    check=False,
                    capture_output=True,
                    text=True,
                    timeout=15,
                )
            except (OSError, subprocess.SubprocessError) as exc:
                errors.append(f"{node.name}/Playwright: {exc}")
                continue
            if process.returncode == 0 and png_path.is_file() and png_path.stat().st_size > 0:
                return True, None
            detail = (process.stderr or process.stdout or f"exit {process.returncode}").strip()
            errors.append(f"{node.name}/Playwright: {detail[:180]}")
    for browser in browsers:
        for headless_flag in ("--headless=new", "--headless"):
            png_path.unlink(missing_ok=True)
            with tempfile.TemporaryDirectory(prefix="check-mac-game-browser-") as profile:
                command = [
                    str(browser),
                    headless_flag,
                    "--disable-gpu",
                    "--disable-extensions",
                    "--disable-background-networking",
                    "--disable-sync",
                    "--disable-crash-reporter",
                    "--hide-scrollbars",
                    "--no-first-run",
                    "--no-default-browser-check",
                    "--no-sandbox",
                    "--force-device-scale-factor=1",
                    "--run-all-compositor-stages-before-draw",
                    "--virtual-time-budget=1200",
                    f"--user-data-dir={profile}",
                    f"--window-size={WIDTH},{HEIGHT}",
                    f"--screenshot={png_path}",
                    html_path.resolve().as_uri(),
                ]
                try:
                    process = subprocess.Popen(
                        command,
                        stdout=subprocess.PIPE,
                        stderr=subprocess.PIPE,
                        text=True,
                    )
                    deadline = time.monotonic() + 8
                    last_size = -1
                    stable_polls = 0
                    screenshot_ready = False
                    while time.monotonic() < deadline:
                        if png_path.is_file():
                            size = png_path.stat().st_size
                            stable_polls = stable_polls + 1 if size > 0 and size == last_size else 0
                            last_size = size
                            if stable_polls >= 2:
                                screenshot_ready = True
                                break
                        # On macOS an application-bundle browser can hand work
                        # to a child process and let this launcher exit before
                        # the screenshot is written.  Do not mistake that early
                        # exit for a failed render: the PNG is the completion
                        # signal, so keep polling until the deadline.
                        if process.poll() is not None:
                            screenshot_ready = png_path.is_file() and png_path.stat().st_size > 0
                            if screenshot_ready:
                                break
                        time.sleep(0.1)
                    if process.poll() is None:
                        process.terminate()
                        try:
                            process.wait(timeout=1)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait(timeout=1)
                    stdout, stderr = process.communicate(timeout=1)
                except (OSError, subprocess.SubprocessError) as exc:
                    errors.append(f"{browser.name}: {exc}")
                    continue
            if screenshot_ready and png_path.is_file() and png_path.stat().st_size > 0:
                return True, None
            detail = (stderr or stdout or f"exit {process.returncode}").strip()
            errors.append(f"{browser.name}: {detail[:180]}")
    if not errors:
        return False, "no Chromium-family headless browser available"
    return False, "; ".join(errors)[-600:]


def convert_svg(svg_path: Path, png_path: Path) -> tuple[bool, Optional[str]]:
    commands: list[list[str]] = []
    if shutil.which("rsvg-convert"):
        commands.append(["rsvg-convert", "-w", str(WIDTH), "-h", str(HEIGHT), "-o", str(png_path), str(svg_path)])
    errors: list[str] = []
    for command in commands:
        try:
            subprocess.run(command, check=True, capture_output=True, text=True, timeout=30)
            if png_path.is_file() and png_path.stat().st_size > 0:
                return True, None
        except (OSError, subprocess.SubprocessError) as exc:
            errors.append(str(exc))
    return False, "; ".join(errors)[:300] if errors else "no SVG rasterizer available"


def render_card(
    *,
    game: str,
    verdict: str,
    status: str,
    method: str,
    rating: Optional[int] = None,
    rating_context: str = "primary",
    review: str = "",
    background: Optional[Path] = None,
    key_art: Optional[Path] = None,
    character: Optional[Path] = None,
    output_dir: Optional[Path] = None,
    output_format: str = "auto",
    style: str = DEFAULT_STYLE,
    require_html_css: bool = True,
) -> dict[str, Any]:
    if style not in SHARE_CARD_STYLES:
        raise ValueError(f"unknown share-card style: {style}")
    output_dir = (output_dir or Path.cwd() / "artifacts" / "check-mac-game" / "share-cards").resolve()
    output_dir.mkdir(parents=True, exist_ok=True)
    payload = "|".join([
        game,
        verdict,
        status,
        method,
        str(rating),
        rating_context,
        review,
        str(background or ""),
        str(key_art or ""),
        str(character or ""),
        style,
    ])
    digest = hashlib.sha256(payload.encode("utf-8")).hexdigest()[:8]
    stem = f"{slugify(game)}-{digest}"
    svg_path = unique_path(output_dir, stem, ".svg")
    html_path = svg_path.with_suffix(".html")
    svg = build_svg(
        game=game,
        verdict=verdict,
        status=status,
        method=method,
        rating=rating,
        rating_context=rating_context,
        review=review,
        background=background,
        key_art=key_art,
        character=character,
    )
    svg_path.write_text(svg, encoding="utf-8")
    final_path = svg_path
    final_format = "svg"
    renderer = "svg_fallback"
    fallback_reason: Optional[str] = None
    if output_format == "html":
        poster_html = build_html(
            game=game,
            verdict=verdict,
            status=status,
            method=method,
            rating=rating,
            rating_context=rating_context,
            review=review,
            background=background,
            key_art=key_art,
            character=character,
            style=style,
        )
        html_path.write_text(poster_html, encoding="utf-8")
        final_path = html_path
        final_format = "html"
        renderer = "html_css_source"
    if output_format in {"auto", "png"}:
        png_path = svg_path.with_suffix(".png")
        converted = False
        try:
            poster_html = build_html(
                game=game,
                verdict=verdict,
                status=status,
                method=method,
                rating=rating,
                rating_context=rating_context,
                review=review,
                background=background,
                key_art=key_art,
                character=character,
                style=style,
            )
            html_path.write_text(poster_html, encoding="utf-8")
            converted, browser_error = capture_html(html_path, png_path)
            if browser_error:
                fallback_reason = browser_error
            if converted:
                renderer = "html_css_browser"
        except (OSError, RuntimeError, ValueError) as exc:
            fallback_reason = str(exc)[:600]

        if require_html_css and not converted:
            html_path.unlink(missing_ok=True)
            png_path.unlink(missing_ok=True)
            raise RuntimeError(
                "HTML/CSS poster capture is unavailable. Install a Chromium-family "
                "browser plus Node.js/Playwright, then retry; no fallback poster was created. "
                f"Details: {fallback_reason or 'browser capture failed'}"
            )

        if converted:
            final_path = png_path
            final_format = "png"
            svg_path.unlink(missing_ok=True)
        if os.environ.get("CHECK_MAC_GAME_KEEP_HTML") != "1":
            html_path.unlink(missing_ok=True)
    label = {
        "png": "导出分享图（PNG）",
        "svg": "导出分享图（SVG）",
        "html": "打开分享图（HTML）",
    }[final_format]
    absolute = str(final_path.resolve())
    enhanced = any(image_data_uri(item) for item in (background, key_art, character))
    return {
        "status": "generated",
        "path": absolute,
        "format": final_format,
        "mime_type": {"png": "image/png", "svg": "image/svg+xml", "html": "text/html"}[final_format],
        "width": WIDTH,
        "height": HEIGHT,
        "visual_style": style if renderer in {"html_css_browser", "html_css_source"} else "editorial-fallback",
        "requested_style": style,
        "renderer": renderer,
        "html_renderer_used": renderer == "html_css_browser",
        "mode": "enhanced" if enhanced else "deterministic",
        "background_used": bool(image_data_uri(background)),
        "key_art_used": bool(image_data_uri(key_art)),
        "character_used": bool(image_data_uri(character)),
        "review_included": bool(review.strip()),
        "fallback_reason": fallback_reason if final_format == "svg" and output_format != "svg" else None,
        "markdown": f"[{label}](<{absolute}>)",
    }


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--game", required=True)
    parser.add_argument("--verdict", required=True)
    parser.add_argument("--status", choices=sorted(STATUS_COLORS), required=True)
    parser.add_argument("--method", required=True)
    parser.add_argument("--review", required=True)
    parser.add_argument("--rating", type=int, choices=range(1, 6))
    parser.add_argument("--rating-context", choices=sorted(RATING_LABELS), default="primary")
    parser.add_argument("--background", type=Path)
    parser.add_argument("--key-art", type=Path)
    parser.add_argument("--character", type=Path)
    parser.add_argument("--output-dir", type=Path)
    parser.add_argument("--format", choices=("auto", "png", "html"), default="png")
    parser.add_argument("--style", choices=sorted(SHARE_CARD_STYLES), default=DEFAULT_STYLE)
    parser.add_argument(
        "--allow-nonfinal-html",
        action="store_true",
        help="permit --format html for local layout inspection only; never a deliverable poster",
    )
    parser.add_argument("--json", action="store_true")
    parser.add_argument(
        "--list-styles",
        action="store_true",
        help="print the approved user-facing share-card style ids and exit",
    )
    parser.add_argument(
        "--default-set",
        action="store_true",
        help="print the default 8-poster share-card style ids (DEFAULT_POSTER_STYLES) and exit",
    )
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    raw_args = list(sys.argv[1:] if argv is None else argv)
    if "--list-styles" in raw_args:
        styles = list(USER_FACING_STYLES)
        if "--json" in raw_args:
            json.dump(
                {
                    "default_style": DEFAULT_STYLE,
                    "styles": styles,
                    "count": len(styles),
                    "default_poster_styles": list(DEFAULT_POSTER_STYLES),
                },
                sys.stdout,
                ensure_ascii=False,
                indent=2,
            )
            sys.stdout.write("\n")
        else:
            for style in styles:
                print(style)
        return 0
    if "--default-set" in raw_args:
        styles = list(DEFAULT_POSTER_STYLES)
        if "--json" in raw_args:
            json.dump(
                {"default_poster_styles": styles, "count": len(styles)},
                sys.stdout,
                ensure_ascii=False,
                indent=2,
            )
            sys.stdout.write("\n")
        else:
            for style in styles:
                print(style)
        return 0
    args = build_parser().parse_args(raw_args)
    if args.format == "html" and not args.allow_nonfinal_html:
        raise SystemExit("--format html is inspection-only; add --allow-nonfinal-html to use it")
    result = render_card(
        game=args.game,
        verdict=args.verdict,
        status=args.status,
        method=args.method,
        rating=args.rating,
        rating_context=args.rating_context,
        review=args.review,
        background=args.background,
        key_art=args.key_art,
        character=args.character,
        output_dir=args.output_dir,
        output_format=args.format,
        style=args.style,
        require_html_css=not args.allow_nonfinal_html,
    )
    if args.json:
        json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        print(result["path"])
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
