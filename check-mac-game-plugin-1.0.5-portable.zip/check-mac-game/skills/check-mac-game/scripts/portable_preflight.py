#!/usr/bin/env python3
"""Check that the portable poster renderer can make approved HTML/CSS cards."""

from __future__ import annotations

import json
import os
from pathlib import Path
import subprocess
import sys
import tempfile

from render_share_card import (
    CAPTURE_HELPER_PATH,
    TEMPLATE_PATH,
    capture_html,
    headless_browser_candidates,
    node_candidates,
)


def playwright_available(node: Path) -> bool:
    probe = "try { require('playwright-core'); process.exit(0) } catch { try { require('playwright'); process.exit(0) } catch { process.exit(1) } }"
    try:
        environment = os.environ.copy()
        bundled_modules = (
            Path.home() / ".cache" / "codex-runtimes" / "codex-primary-runtime" /
            "dependencies" / "node" / "node_modules"
        )
        existing = environment.get("NODE_PATH", "")
        environment["NODE_PATH"] = os.pathsep.join(
            item for item in (existing, str(bundled_modules)) if item
        )
        return subprocess.run(
            [str(node), "-e", probe],
            env=environment,
            stdout=subprocess.DEVNULL,
            stderr=subprocess.DEVNULL,
            timeout=8,
            check=False,
        ).returncode == 0
    except (OSError, subprocess.SubprocessError):
        return False


def capture_available() -> tuple[bool, str | None]:
    """Exercise the exact local HTML-to-PNG path, not merely dependency lookup."""
    with tempfile.TemporaryDirectory(prefix="check-mac-game-preflight-") as directory:
        root = Path(directory)
        html = root / "probe.html"
        png = root / "probe.png"
        html.write_text(
            "<!doctype html><meta charset='utf-8'><style>body{margin:0;background:#123;color:#fff;font:64px sans-serif}</style><body>OK</body>",
            encoding="utf-8",
        )
        return capture_html(html, png)


def main() -> int:
    nodes = node_candidates()
    browsers = headless_browser_candidates()
    result = {
        "python_ok": sys.version_info >= (3, 9),
        "template_ok": TEMPLATE_PATH.is_file(),
        "capture_helper_ok": CAPTURE_HELPER_PATH.is_file(),
        "browser_paths": [str(item) for item in browsers],
        "node_paths": [str(item) for item in nodes],
        "playwright_ok": any(playwright_available(item) for item in nodes),
    }
    result["capture_ok"], result["capture_error"] = capture_available()
    result["approved_poster_ready"] = all((
        result["python_ok"],
        result["template_ok"],
        result["capture_helper_ok"],
        bool(result["browser_paths"]),
        bool(result["node_paths"]),
        result["playwright_ok"],
        result["capture_ok"],
    ))
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0 if result["approved_poster_ready"] else 2


if __name__ == "__main__":
    raise SystemExit(main())
