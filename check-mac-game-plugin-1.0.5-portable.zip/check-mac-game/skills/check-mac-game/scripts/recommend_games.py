#!/usr/bin/env python3
"""Recommend currently compatible Mac games from live, no-key public data."""

from __future__ import annotations

import argparse
from concurrent.futures import ThreadPoolExecutor, as_completed
from html.parser import HTMLParser
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from typing import Any, Callable, Optional
from urllib.parse import urlencode


SCRIPT_DIR = Path(__file__).resolve().parent
if str(SCRIPT_DIR) not in sys.path:
    sys.path.insert(0, str(SCRIPT_DIR))

from check_game import (  # noqa: E402
    HttpClient,
    collect_game,
    compact_whitespace,
    fetch_steam_details,
    fetch_steam_searches,
    default_cache_dir,
    iso_now,
    load_cached_result,
    normalize_title,
    store_cached_result,
    strip_html_markup,
)


STEAM_SEARCH_RESULTS = "https://store.steampowered.com/search/results/"
STEAM_APP = "https://store.steampowered.com/app/"

# Steam tag identifiers are taxonomy, not a maintained game allowlist. Unknown
# preferences fall back to Steam's live text search.
GENRE_TAGS = {
    "action": 19,
    "动作": 19,
    "adventure": 21,
    "冒险": 21,
    "rpg": 122,
    "角色扮演": 122,
    "jrpg": 4434,
    "日式角色扮演": 4434,
    "soulslike": 29482,
    "souls like": 29482,
    "魂类": 29482,
    "shooter": 1774,
    "射击": 1774,
    "fps": 1663,
    "strategy": 9,
    "策略": 9,
    "simulation": 599,
    "模拟": 599,
    "racing": 699,
    "竞速": 699,
    "horror": 1667,
    "恐怖": 1667,
    "puzzle": 1664,
    "解谜": 1664,
    "casual": 597,
    "休闲": 597,
    "co op": 1685,
    "coop": 1685,
    "合作": 1685,
    "open world": 1695,
    "开放世界": 1695,
}

SETUP_ORDER = {"simple": 0, "medium": 1, "complex": 2, "not_recommended": 3}
RECOMMENDATION_CACHE_TTL_SECONDS = 6 * 60 * 60
EMPTY_RECOMMENDATION_CACHE_TTL_SECONDS = 30 * 60


class SteamResultsParser(HTMLParser):
    """Parse app rows from Steam's search-results HTML fragment."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.current: Optional[dict[str, Any]] = None
        self.anchor_depth = 0
        self.title_depth = 0
        self.results: list[dict[str, Any]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, Optional[str]]]) -> None:
        values = dict(attrs)
        classes = set((values.get("class") or "").split())
        if tag == "a" and "search_result_row" in classes:
            href = values.get("href") or ""
            app_id = values.get("data-ds-appid")
            if not app_id:
                match = re.search(r"/app/(\d+)", href)
                app_id = match.group(1) if match else None
            if app_id and str(app_id).isdigit():
                self.current = {
                    "id": int(app_id),
                    "name": "",
                    "url": href.split("?", 1)[0] or f"{STEAM_APP}{app_id}",
                }
                self.anchor_depth = 1
            return
        if self.current is None:
            return
        if tag == "a":
            self.anchor_depth += 1
        if tag == "span" and "title" in classes:
            self.title_depth = 1
        elif self.title_depth:
            self.title_depth += 1

    def handle_data(self, data: str) -> None:
        if self.current is not None and self.title_depth:
            self.current["name"] += data

    def handle_endtag(self, tag: str) -> None:
        if self.current is None:
            return
        if self.title_depth:
            self.title_depth -= 1
        if tag == "a":
            self.anchor_depth -= 1
            if self.anchor_depth == 0:
                self.current["name"] = compact_whitespace(self.current["name"])
                if self.current["name"]:
                    self.results.append(self.current)
                self.current = None


def parse_steam_results(payload: Any) -> list[dict[str, Any]]:
    if isinstance(payload, dict):
        document = str(payload.get("results_html") or "")
    else:
        document = str(payload or "")
    parser = SteamResultsParser()
    parser.feed(document)
    seen: set[int] = set()
    results: list[dict[str, Any]] = []
    for item in parser.results:
        if item["id"] in seen:
            continue
        seen.add(item["id"])
        results.append(item)
    return results


def genre_tag(genre: Optional[str]) -> Optional[int]:
    if not genre:
        return None
    key = normalize_title(genre)
    return GENRE_TAGS.get(key)


def build_search_url(genre: Optional[str], native_only: bool, count: int) -> str:
    params: dict[str, Any] = {
        "query": "",
        "start": 0,
        "count": max(1, min(count, 50)),
        "dynamic_data": "",
        "filter": "topsellers",
        "category1": 998,
        "force_infinite": 1,
        "infinite": 1,
        "l": "schinese",
        "cc": "US",
    }
    tag = genre_tag(genre)
    if tag:
        params["tags"] = tag
    elif genre:
        params["term"] = genre
    if native_only:
        params["os"] = "mac"
    return STEAM_SEARCH_RESULTS + "?" + urlencode(params)


def discover_games(
    client: Any,
    genre: Optional[str],
    native_only: bool,
    count: int,
) -> tuple[list[dict[str, Any]], str]:
    url = build_search_url(genre, native_only, count)
    payload = client.get_json(url)
    results = parse_steam_results(payload)
    for item in results:
        item["discovery_scope"] = "steam_mac" if native_only else "steam_all"
        item["discovery_url"] = url
    return results, url


def _number_before(text: str, suffix_pattern: str) -> Optional[float]:
    matches = re.findall(r"(\d+(?:\.\d+)?)\s*" + suffix_pattern, text, re.IGNORECASE)
    if not matches:
        return None
    return max(float(value) for value in matches)


def extract_requirements(details: dict[str, Any], native: bool) -> dict[str, Any]:
    key = "mac_requirements" if native else "pc_requirements"
    requirements = details.get(key) or {}
    if not isinstance(requirements, dict):
        requirements = {}
    minimum = strip_html_markup(requirements.get("minimum"))
    memory = _number_before(minimum, r"GB\s*(?:RAM|Memory)")
    storage = _number_before(minimum, r"GB\s*(?:available|free|storage)")
    if memory is None:
        memory_mb = _number_before(minimum, r"MB\s*(?:RAM|Memory)")
        memory = memory_mb / 1024 if memory_mb is not None else None
    if storage is None:
        storage_mb = _number_before(minimum, r"MB\s*(?:available|free|storage)")
        storage = storage_mb / 1024 if storage_mb is not None else None
    return {
        "basis": "official_mac_minimum" if native else "windows_minimum_reference",
        "minimum_text": minimum or None,
        "memory_gb": memory,
        "storage_gb": storage,
    }


def steam_metadata(candidate: dict[str, Any], details: dict[str, Any]) -> dict[str, Any]:
    platforms = details.get("platforms") or {}
    categories = [
        compact_whitespace(str(item.get("description") or ""))
        for item in details.get("categories") or []
        if isinstance(item, dict)
    ]
    genres = [
        compact_whitespace(str(item.get("description") or ""))
        for item in details.get("genres") or []
        if isinstance(item, dict)
    ]
    language_text = strip_html_markup(details.get("supported_languages"))
    category_text = " ".join(categories).casefold()
    chinese = any(
        token in language_text.casefold()
        for token in ("simplified chinese", "traditional chinese", "简体中文", "繁体中文")
    )
    controller = bool(details.get("controller_support")) or any(
        token in category_text for token in ("controller", "手柄")
    )
    online = any(
        token in category_text
        for token in ("multi-player", "multiplayer", "online co-op", "cross-platform", "多人", "在线合作")
    )
    native = bool(platforms.get("mac"))
    price = None
    if details.get("is_free"):
        price = "Free"
    elif isinstance(details.get("price_overview"), dict):
        price = details["price_overview"].get("final_formatted")
    return {
        **candidate,
        "name": details.get("name") or candidate.get("name"),
        "display_name": candidate.get("name") or details.get("name"),
        "platforms": platforms,
        "steam_mac": native,
        "genres": genres,
        "categories": categories,
        "supports_chinese": chinese,
        "controller_support": controller,
        "online_support": online,
        "price": price,
        "release_date": (details.get("release_date") or {}).get("date"),
        "requirements": extract_requirements(details, native),
        "source_url": f"{STEAM_APP}{candidate['id']}",
    }


def detect_this_mac() -> dict[str, Any]:
    """Read local Mac hardware only when the caller explicitly requests it."""

    try:
        completed = subprocess.run(
            ["system_profiler", "SPHardwareDataType", "SPSoftwareDataType", "-json"],
            check=True,
            capture_output=True,
            text=True,
            timeout=12,
        )
        payload = json.loads(completed.stdout)
    except (OSError, subprocess.SubprocessError, json.JSONDecodeError) as exc:
        return {"detected": False, "error": compact_whitespace(str(exc))[:300]}
    hardware = ((payload.get("SPHardwareDataType") or [{}])[0])
    software = ((payload.get("SPSoftwareDataType") or [{}])[0])
    memory_text = str(hardware.get("physical_memory") or "")
    memory_match = re.search(r"(\d+)\s*GB", memory_text, re.IGNORECASE)
    return {
        "detected": True,
        "model": hardware.get("machine_name") or hardware.get("machine_model"),
        "chip": hardware.get("chip_type") or hardware.get("cpu_type"),
        "memory_gb": int(memory_match.group(1)) if memory_match else None,
        "macos": software.get("os_version"),
    }


def infer_mode(genre: Optional[str], similar_to: Optional[str]) -> str:
    if similar_to:
        return "similar"
    if genre:
        return "preference"
    return "configuration"


def recommendation_cache_key(payload: dict[str, Any]) -> str:
    encoded = json.dumps(payload, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(encoded.encode("utf-8")).hexdigest()


def resolve_similar_seed(client: Any, title: str) -> dict[str, Any]:
    search = fetch_steam_searches(client, title)
    items = search.get("items") or []
    normalized = normalize_title(title)
    exact = [item for item in items if normalize_title(str(item.get("name") or "")) == normalized]
    selected = exact[0] if len(exact) == 1 else (items[0] if len(items) == 1 else None)
    if not selected:
        return {
            "resolved": False,
            "candidates": [item.get("name") for item in items[:5]],
            "errors": search.get("errors") or [],
        }
    detail_result = fetch_steam_details(client, selected)
    details = detail_result.get("details") or {}
    genres = [
        str(item.get("description") or "")
        for item in details.get("genres") or []
        if isinstance(item, dict)
    ]
    selected_genre = next((item for item in genres if genre_tag(item)), genres[0] if genres else None)
    return {
        "resolved": bool(selected_genre),
        "title": details.get("name") or selected.get("name"),
        "steam_appid": selected.get("id"),
        "genres": genres,
        "selected_genre": selected_genre,
        "errors": (search.get("errors") or []) + (detail_result.get("errors") or []),
    }


def hardware_fit(
    metadata: dict[str, Any],
    memory_gb: Optional[int],
    storage_free_gb: Optional[int],
) -> dict[str, Any]:
    requirements = metadata.get("requirements") or {}
    minimum_memory = requirements.get("memory_gb")
    minimum_storage = requirements.get("storage_gb")
    failures: list[str] = []
    confirmations: list[str] = []
    if memory_gb is not None and minimum_memory is not None:
        if memory_gb < minimum_memory:
            failures.append(f"内存低于已记录的最低要求 {minimum_memory:g}GB")
        else:
            confirmations.append(f"内存达到已记录的最低要求 {minimum_memory:g}GB")
    if storage_free_gb is not None and minimum_storage is not None:
        if storage_free_gb < minimum_storage:
            failures.append(f"剩余空间低于已记录的最低要求 {minimum_storage:g}GB")
        else:
            confirmations.append(f"剩余空间达到已记录的最低要求 {minimum_storage:g}GB")
    if failures:
        label = "below_documented_minimum"
    elif confirmations:
        label = "meets_documented_minimum"
    else:
        label = "unknown"
    return {
        "status": label,
        "notes": failures or confirmations or ["缺少可与当前配置直接比较的官方最低要求"],
        "requirements": requirements,
        "performance_guaranteed": False,
    }


def setup_effort(result: dict[str, Any]) -> dict[str, str]:
    verdict = result.get("verdict")
    detail = result.get("verdict_detail")
    if verdict == "native_mac":
        return {"level": "simple", "label": "简单", "method": "官方Mac版"}
    if verdict == "crossover":
        label = "中等" if detail == "recommended" else "中等（功能有限）"
        return {"level": "medium", "label": label, "method": "CrossOver"}
    return {"level": "not_recommended", "label": "不建议", "method": "未确认可用"}


def _preference_score(metadata: dict[str, Any], genre: Optional[str]) -> int:
    score = 0
    if metadata.get("steam_mac"):
        score += 20
    if metadata.get("steam_mac") and metadata.get("discovery_scope") == "steam_mac":
        score += 10
    if genre:
        key = normalize_title(genre)
        genre_text = " ".join(metadata.get("genres") or [])
        if key and key in normalize_title(genre_text):
            score += 10
    return score


def recommendation_score(item: dict[str, Any]) -> int:
    result = item["compatibility"]
    verdict_score = {
        "native_mac": 100,
        "crossover": 70 if result.get("verdict_detail") == "recommended" else 55,
    }.get(result.get("verdict"), 0)
    confidence_score = {"high": 12, "medium": 7, "low": 2}.get(result.get("confidence"), 0)
    fit_penalty = -100 if item["hardware_fit"]["status"] == "below_documented_minimum" else 0
    return verdict_score + confidence_score + item.get("preference_score", 0) + fit_penalty


def default_checker(
    title: str,
    chip: str,
    macos: str,
    memory_gb: Optional[int],
    refresh: bool,
    timeout: float,
) -> dict[str, Any]:
    return collect_game(
        title,
        chip,
        macos,
        memory_gb,
        refresh=refresh,
        total_timeout=timeout,
    )


def collect_recommendations(
    *,
    genre: Optional[str] = None,
    similar_to: Optional[str] = None,
    chip: str = "Apple Silicon (M-series)",
    macos: str = "current macOS",
    memory_gb: Optional[int] = None,
    storage_free_gb: Optional[int] = None,
    controller: bool = False,
    online: bool = False,
    chinese: bool = False,
    native_only: bool = False,
    max_setup: str = "complex",
    limit: int = 6,
    refresh: bool = False,
    timeout: float = 10.0,
    use_cache: bool = True,
    cache_dir: Optional[Path] = None,
    client: Optional[Any] = None,
    checker: Optional[Callable[..., dict[str, Any]]] = None,
) -> dict[str, Any]:
    caller_supplied_dependencies = client is not None or checker is not None
    cache_allowed = use_cache and (not caller_supplied_dependencies or cache_dir is not None)
    cache_payload = {
        "genre": genre,
        "similar_to": similar_to,
        "chip": chip,
        "macos": macos,
        "memory_gb": memory_gb,
        "storage_free_gb": storage_free_gb,
        "controller": controller,
        "online": online,
        "chinese": chinese,
        "native_only": native_only,
        "max_setup": max_setup,
        "limit": limit,
    }
    cache_root = Path(cache_dir) if cache_dir is not None else default_cache_dir() / "recommendations"
    cache_path = cache_root / f"{recommendation_cache_key(cache_payload)}.json"
    if cache_allowed and not refresh:
        cached = load_cached_result(cache_path, require_retrieval=False)
        if cached is not None:
            return cached

    checked_at = iso_now()
    client = client or HttpClient()
    checker = checker or default_checker
    mode = infer_mode(genre, similar_to)
    errors: list[dict[str, str]] = []
    similarity: Optional[dict[str, Any]] = None
    discovery_genre = genre
    excluded = {"preference_filter": 0, "compatibility": 0, "hardware": 0, "setup": 0}

    def finish(result: dict[str, Any]) -> dict[str, Any]:
        ttl = (
            RECOMMENDATION_CACHE_TTL_SECONDS
            if result.get("recommendations")
            else EMPTY_RECOMMENDATION_CACHE_TTL_SECONDS
        )
        result["cache"] = {"hit": False, "age_seconds": 0, "ttl_seconds": ttl}
        if cache_allowed:
            store_cached_result(cache_path, result, ttl)
        return result

    if similar_to:
        similarity = resolve_similar_seed(client, similar_to)
        errors.extend(similarity.get("errors") or [])
        if not similarity.get("resolved"):
            return finish({
                "mode": mode,
                "query": {"similar_to": similar_to},
                "device": {"chip": chip, "memory_gb": memory_gb, "macos": macos},
                "recommendations": [],
                "similarity": similarity,
                "excluded": excluded,
                "errors": errors or [{"source": "steam", "error": "无法确定相似游戏类型"}],
                "checked_at": checked_at,
            })
        discovery_genre = similarity.get("selected_genre")

    pool_size = max(18, min(40, limit * 4))
    discovery_jobs = [(True, "native")]
    if not native_only and max_setup != "simple":
        discovery_jobs.append((False, "all"))
    candidates: list[dict[str, Any]] = []
    discovery_sources: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=len(discovery_jobs)) as executor:
        futures = {
            executor.submit(discover_games, client, discovery_genre, native, pool_size): label
            for native, label in discovery_jobs
        }
        for future in as_completed(futures):
            label = futures[future]
            try:
                items, url = future.result()
                candidates.extend(items)
                discovery_sources.append({"name": f"Steam Search ({label})", "url": url})
            except Exception as exc:
                errors.append({"source": f"steam_discovery_{label}", "error": compact_whitespace(str(exc))[:300]})

    deduped: list[dict[str, Any]] = []
    seen: set[int] = set()
    seed_id = (similarity or {}).get("steam_appid")
    for candidate in sorted(candidates, key=lambda item: item.get("discovery_scope") != "steam_mac"):
        if candidate["id"] in seen or candidate["id"] == seed_id:
            continue
        seen.add(candidate["id"])
        ranked_candidate = dict(candidate)
        ranked_candidate["discovery_rank"] = len(deduped)
        deduped.append(ranked_candidate)

    metadata_items: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=min(8, max(1, len(deduped[:pool_size])))) as executor:
        futures = {executor.submit(fetch_steam_details, client, item): item for item in deduped[:pool_size]}
        for future in as_completed(futures):
            candidate = futures[future]
            try:
                payload = future.result()
                errors.extend(payload.get("errors") or [])
                if payload.get("details"):
                    metadata_items.append(steam_metadata(candidate, payload["details"]))
            except Exception as exc:
                errors.append({"source": "steam_details", "error": compact_whitespace(str(exc))[:300]})

    filtered: list[dict[str, Any]] = []
    for item in metadata_items:
        if controller and not item.get("controller_support"):
            excluded["preference_filter"] += 1
            continue
        if online and not item.get("online_support"):
            excluded["preference_filter"] += 1
            continue
        if chinese and not item.get("supports_chinese"):
            excluded["preference_filter"] += 1
            continue
        if native_only and not item.get("steam_mac"):
            excluded["preference_filter"] += 1
            continue
        item["preference_score"] = _preference_score(item, discovery_genre)
        filtered.append(item)
    filtered.sort(
        key=lambda item: (-item["preference_score"], item.get("discovery_rank", 10_000))
    )

    verify_count = min(len(filtered), max(limit + 2, 4), 10)
    verified: list[dict[str, Any]] = []
    manual_review_candidates: list[dict[str, Any]] = []
    with ThreadPoolExecutor(max_workers=min(4, max(1, verify_count))) as executor:
        futures = {
            executor.submit(
                checker,
                item["name"],
                chip,
                macos,
                memory_gb,
                refresh,
                timeout,
            ): item
            for item in filtered[:verify_count]
        }
        for future in as_completed(futures):
            metadata = futures[future]
            try:
                compatibility = future.result()
            except Exception as exc:
                errors.append({"source": "compatibility", "error": compact_whitespace(str(exc))[:300]})
                continue
            effort = setup_effort(compatibility)
            if effort["level"] == "not_recommended":
                excluded["compatibility"] += 1
                if max_setup == "complex" and len(manual_review_candidates) < 2:
                    manual_review_candidates.append(
                        {
                            "title": metadata.get("display_name") or metadata.get("name"),
                            "canonical_title": metadata.get("name"),
                            "steam_appid": metadata.get("id"),
                            "genres": metadata.get("genres"),
                            "preference_score": metadata.get("preference_score"),
                            "standard_verdict": compatibility.get("verdict_detail"),
                            "reason": "偏好匹配较高，但标准资料未确认可玩；仅在找到近期可复现教程时考虑",
                            "source_url": metadata.get("source_url"),
                        }
                    )
                continue
            if native_only and compatibility.get("verdict") != "native_mac":
                excluded["compatibility"] += 1
                continue
            if SETUP_ORDER[effort["level"]] > SETUP_ORDER[max_setup]:
                excluded["setup"] += 1
                continue
            fit = hardware_fit(metadata, memory_gb, storage_free_gb)
            if fit["status"] == "below_documented_minimum":
                excluded["hardware"] += 1
                continue
            reasons: list[str] = []
            if compatibility.get("verdict") == "native_mac":
                reasons.append("官方Mac版")
            else:
                reasons.append("已有CrossOver可玩记录")
            if discovery_genre:
                reasons.append(f"符合{discovery_genre}偏好")
            if controller and metadata.get("controller_support"):
                reasons.append("支持手柄")
            if chinese and metadata.get("supports_chinese"):
                reasons.append("支持中文")
            if online and metadata.get("online_support"):
                reasons.append("包含联网玩法")
            record = {
                "title": metadata.get("display_name") or metadata.get("name"),
                "canonical_title": metadata.get("name"),
                "steam_appid": metadata.get("id"),
                "genres": metadata.get("genres"),
                "play_method": effort["method"],
                "setup_effort": effort,
                "hardware_fit": fit,
                "controller_support": metadata.get("controller_support"),
                "online_support": metadata.get("online_support"),
                "supports_chinese": metadata.get("supports_chinese"),
                "price": metadata.get("price"),
                "release_date": metadata.get("release_date"),
                "reasons": reasons,
                "preference_score": metadata.get("preference_score"),
                "discovery_rank": metadata.get("discovery_rank"),
                "compatibility": {
                    "verdict": compatibility.get("verdict"),
                    "verdict_detail": compatibility.get("verdict_detail"),
                    "confidence": compatibility.get("confidence"),
                    "native": compatibility.get("native"),
                    "crossover": compatibility.get("crossover"),
                    "risks": compatibility.get("risks"),
                    "checked_at": compatibility.get("checked_at"),
                },
                "sources": [
                    {"name": "Steam Store", "url": metadata.get("source_url")},
                    *(compatibility.get("sources") or []),
                ],
            }
            record["score"] = recommendation_score(record)
            verified.append(record)

    verified.sort(
        key=lambda item: (-item["score"], item.get("discovery_rank", 10_000), item["title"])
    )
    recommendations = verified[:limit]
    device_notes: list[str] = []
    if "macbook air" in chip.casefold() or re.search(r"\bair\b", chip, re.IGNORECASE):
        device_notes.append("MacBook Air为无风扇机型，长时间高负载表现需参考同型号实测")
    device_notes.append("配置门槛只用于筛除明确不足项，不等同于帧率保证")
    return finish({
        "mode": mode,
        "query": {
            "genre": genre,
            "similar_to": similar_to,
            "controller": controller,
            "online": online,
            "chinese": chinese,
            "native_only": native_only,
            "max_setup": max_setup,
            "limit": limit,
        },
        "device": {
            "chip": chip,
            "memory_gb": memory_gb,
            "macos": macos,
            "storage_free_gb": storage_free_gb,
            "notes": device_notes,
        },
        "similarity": similarity,
        "recommendations": recommendations,
        "manual_review_candidates": manual_review_candidates,
        "excluded": excluded,
        "sources": discovery_sources,
        "errors": errors,
        "checked_at": checked_at,
    })


def human_summary(result: dict[str, Any]) -> str:
    mode_labels = {
        "configuration": "适合这台Mac的游戏",
        "preference": "按偏好推荐",
        "similar": "相似游戏推荐",
    }
    lines = [f"## {mode_labels.get(result.get('mode'), 'Mac游戏推荐')}"]
    recommendations = result.get("recommendations") or []
    if not recommendations:
        lines.append("暂时没有找到同时满足条件且兼容性已核验的游戏。")
    else:
        lines.extend(
            [
                "",
                "| 游戏 | 运行方式 | 安装难度 | 配置判断 | 推荐理由 |",
                "|---|---|---|---|---|",
            ]
        )
        for item in recommendations:
            fit = item["hardware_fit"]
            fit_label = {
                "meets_documented_minimum": "达到已记录门槛",
                "unknown": "性能待核验",
            }.get(fit["status"], "不满足门槛")
            lines.append(
                "| {title} | {method} | {effort} | {fit} | {reasons} |".format(
                    title=item["title"],
                    method=item["play_method"],
                    effort=item["setup_effort"]["label"],
                    fit=fit_label,
                    reasons="、".join(item["reasons"]),
                )
            )
    lines.append("")
    lines.append(f"查询时间：{result.get('checked_at')}")
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Recommend games for a Mac configuration and play preference.")
    parser.add_argument("--genre", help="Preferred genre, for example action or 动作")
    parser.add_argument("--similar-to", help="Recommend Mac-compatible games similar to this title")
    parser.add_argument("--chip", default="Apple Silicon (M-series)", help="Mac model or chip")
    parser.add_argument("--macos", default="current macOS", help="macOS version")
    parser.add_argument("--memory-gb", type=int, default=None, help="Memory in GB")
    parser.add_argument("--storage-free-gb", type=int, default=None, help="Free storage in GB")
    parser.add_argument("--detect-this-mac", action="store_true", help="Read this Mac's model, chip, memory, and macOS")
    parser.add_argument("--controller", action="store_true", help="Require controller support")
    parser.add_argument("--online", action="store_true", help="Require a multiplayer or online category")
    parser.add_argument("--chinese", action="store_true", help="Require Chinese language support")
    parser.add_argument("--native-only", action="store_true", help="Recommend only official Mac releases")
    parser.add_argument(
        "--max-setup",
        choices=("simple", "medium", "complex"),
        default="complex",
        help="Maximum accepted installation effort",
    )
    parser.add_argument("--limit", type=int, default=6, help="Number of recommendations, 1-10")
    parser.add_argument("--refresh", action="store_true", help="Refresh final compatibility checks")
    parser.add_argument("--no-cache", action="store_true", help="Do not read or write recommendation caches")
    parser.add_argument("--timeout", type=float, default=10.0, help="Per-game verification budget")
    parser.add_argument("--json", action="store_true", help="Emit normalized JSON")
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    chip = args.chip
    macos = args.macos
    memory_gb = args.memory_gb
    detected = None
    if args.detect_this_mac:
        detected = detect_this_mac()
        if detected.get("detected"):
            model = detected.get("model")
            detected_chip = detected.get("chip")
            chip = " ".join(filter(None, (str(model or ""), str(detected_chip or "")))) or chip
            macos = detected.get("macos") or macos
            memory_gb = detected.get("memory_gb") or memory_gb
    result = collect_recommendations(
        genre=args.genre,
        similar_to=args.similar_to,
        chip=chip,
        macos=macos,
        memory_gb=memory_gb,
        storage_free_gb=args.storage_free_gb,
        controller=args.controller,
        online=args.online,
        chinese=args.chinese,
        native_only=args.native_only,
        max_setup=args.max_setup,
        limit=max(1, min(args.limit, 10)),
        refresh=args.refresh,
        timeout=max(1.0, args.timeout),
        use_cache=not args.no_cache,
    )
    if detected is not None:
        result["device_detection"] = detected
    if args.json:
        json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        print(human_summary(result))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
