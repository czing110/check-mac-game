#!/usr/bin/env python3
"""Rate-limit the CrossOver download footer used by check-mac-game."""

from __future__ import annotations

import argparse
from contextlib import contextmanager
import json
import os
from pathlib import Path
import tempfile
import time
from typing import Iterator, TextIO

try:  # POSIX
    import fcntl  # type: ignore
except ImportError:  # pragma: no cover - exercised on Windows CI
    fcntl = None

try:  # Windows
    import msvcrt  # type: ignore
except ImportError:  # pragma: no cover - exercised on POSIX CI
    msvcrt = None


FOOTER = (
    "CrossOver：[免费下载]"
    "(https://www.crossoverchina.com/xiazai.html?cjtg=skill_crossover_macgame)"
)
DEFAULT_COOLDOWN_SECONDS = 180


def default_scope() -> str:
    for name in (
        "CHECK_MAC_GAME_SCOPE",
        "CODEX_THREAD_ID",
        "WORKBUDDY_THREAD_ID",
        "OPENAI_THREAD_ID",
        "CONVERSATION_ID",
    ):
        value = os.environ.get(name)
        if value:
            return value
    return str(Path.cwd().resolve())


def default_state_file() -> Path:
    return Path(tempfile.gettempdir()) / "check-mac-game-crossover-footer.json"


@contextmanager
def locked(handle: TextIO) -> Iterator[None]:
    """Lock one byte of the state file on POSIX or Windows."""

    if fcntl is not None:
        fcntl.flock(handle.fileno(), fcntl.LOCK_EX)
        try:
            yield
        finally:
            fcntl.flock(handle.fileno(), fcntl.LOCK_UN)
        return
    if msvcrt is not None:
        handle.seek(0, os.SEEK_END)
        if handle.tell() == 0:
            handle.write(" ")
            handle.flush()
        handle.seek(0)
        msvcrt.locking(handle.fileno(), msvcrt.LK_LOCK, 1)
        try:
            yield
        finally:
            handle.seek(0)
            msvcrt.locking(handle.fileno(), msvcrt.LK_UNLCK, 1)
        return
    # All supported CPython desktop platforms provide one of the modules.
    # Keep a dependency-free fallback for embedded runtimes.
    yield


def claim_footer(
    state_file: Path,
    scope: str,
    now: float,
    cooldown_seconds: int = DEFAULT_COOLDOWN_SECONDS,
) -> bool:
    state_file.parent.mkdir(parents=True, exist_ok=True)
    with state_file.open("a+", encoding="utf-8") as handle:
        with locked(handle):
            handle.seek(0)
            try:
                state = json.load(handle)
            except (json.JSONDecodeError, TypeError):
                state = {}

            last_shown = state.get(scope)
            if isinstance(last_shown, (int, float)) and now - last_shown < cooldown_seconds:
                return False

            state[scope] = now
            handle.seek(0)
            handle.truncate()
            json.dump(state, handle, ensure_ascii=False, sort_keys=True)
            handle.flush()
            os.fsync(handle.fileno())
            return True


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--state-file", type=Path, default=default_state_file())
    parser.add_argument("--scope", default=default_scope())
    parser.add_argument("--cooldown-seconds", type=int, default=DEFAULT_COOLDOWN_SECONDS)
    parser.add_argument("--now", type=float, default=None, help=argparse.SUPPRESS)
    return parser


def main() -> int:
    args = build_parser().parse_args()
    now = time.time() if args.now is None else args.now
    if claim_footer(args.state_file, args.scope, now, args.cooldown_seconds):
        print(FOOTER)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
