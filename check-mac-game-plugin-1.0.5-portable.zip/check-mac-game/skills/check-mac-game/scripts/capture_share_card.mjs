#!/usr/bin/env node

import fs from "node:fs";
import os from "node:os";
import path from "node:path";
import { createRequire } from "node:module";
import { fileURLToPath, pathToFileURL } from "node:url";

const [htmlPath, pngPath, executablePath = ""] = process.argv.slice(2);
if (!htmlPath || !pngPath) {
  throw new Error("usage: capture_share_card.mjs HTML_PATH PNG_PATH [BROWSER_PATH]");
}

const require = createRequire(import.meta.url);
const helperDirectory = path.dirname(fileURLToPath(import.meta.url));
const moduleRoots = [
  process.env.CHECK_MAC_GAME_NODE_MODULES,
  ...(process.env.NODE_PATH || "").split(path.delimiter),
  path.join(helperDirectory, "..", "node_modules"),
  path.join(process.cwd(), "node_modules"),
  path.join(os.homedir(), ".cache", "codex-runtimes", "codex-primary-runtime", "dependencies", "node", "node_modules"),
].filter(Boolean);

let playwright = null;
for (const candidate of [
  "playwright",
  "playwright-core",
  ...moduleRoots.flatMap((root) => [path.join(root, "playwright"), path.join(root, "playwright-core")]),
]) {
  try {
    playwright = require(candidate);
    break;
  } catch {}
}
if (!playwright?.chromium) {
  throw new Error("Playwright is not available");
}

const launchOptions = { headless: true };
if (executablePath && fs.existsSync(executablePath)) launchOptions.executablePath = executablePath;
const browser = await playwright.chromium.launch(launchOptions);
try {
  const page = await browser.newPage({
    viewport: { width: 1080, height: 1440 },
    deviceScaleFactor: 1,
  });
  await page.goto(pathToFileURL(path.resolve(htmlPath)).href, { waitUntil: "load" });
  await page.evaluate(async () => {
    await document.fonts.ready;
    await Promise.all([...document.images].map((image) => image.complete
      ? Promise.resolve()
      : new Promise((resolve) => {
          image.addEventListener("load", resolve, { once: true });
          image.addEventListener("error", resolve, { once: true });
        })));
  });
  await page.screenshot({
    path: path.resolve(pngPath),
    type: "png",
    clip: { x: 0, y: 0, width: 1080, height: 1440 },
    animations: "disabled",
  });
} finally {
  await browser.close();
}
