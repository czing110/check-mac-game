---
name: check-mac-game
description: Check whether a named game can be played on a Mac, recommend games for a Mac configuration or preference, and export single-game results as any approved HTML/CSS-rendered poster style with official game art. Distinguish official macOS releases, CrossOver, required third-party patches, and unavailable or unknown results. Resolve Chinese nicknames and editions or ask the user to choose.
---

# Check Mac Game

Determine Mac game compatibility and make evidence-backed recommendations from current sources. Default to an Apple silicon Mac on the current macOS release when the user supplies no device details.

## Runtime portability

The bundled Python scripts require Python 3.9 or newer and otherwise use only
the standard library. Resolve every script and reference relative to this
`SKILL.md`; never assume a Codex home directory, current working directory, or
absolute installation path. Examples use `python3`; on hosts where that command
is unavailable, use `python`, `py -3`, or the platform-provided Python launcher.

This skill is a standalone distributable package. Do not require `agent-reach`
or any other separately installed skill, plugin, connector, MCP server, or
vendor-specific search integration. Use the bundled collectors as the primary
retrieval path. For evidence that is not covered by a bundled collector, use
whatever generic HTTP, browser, or web-search capability the host already
provides. If none is available, record that source as unreachable and continue
through the fail-closed evidence rules; never turn a missing optional integration
into a compatibility conclusion or an installation failure.

On first use after installation, run `scripts/self_check.py` and
`scripts/portable_preflight.py`. The structural check must pass before relying
on generated results. For the approved eight-card poster set, a Chromium-family
browser plus Node.js/Playwright is required. If `approved_poster_ready` is
false, stop and explain the missing rendering capability; never silently publish
a Pillow, SVG, HTML, or placeholder substitute as an approved poster.
If the host has no Python execution capability, perform the same live source
workflow with its browser/search tools and omit unavailable generated artifacts;
never turn a missing runtime into a game-compatibility conclusion.

## Choose a mode

- **Single-title check**: the user names one game and asks whether or how it runs.
  Follow the compatibility workflow and single-title answer shape below.
- **Configuration recommendation**: the user asks what a Mac configuration can
  play. Read [references/recommendation-rules.md](references/recommendation-rules.md)
  and run `recommend_games.py` with the supplied chip, memory, macOS, storage, and
  setup tolerance.
- **Preference recommendation**: the user asks for action, RPG, co-op, Chinese,
  controller, native-only, or similar preference filters. Read the recommendation
  rules and pass only the stated filters.
- **Similar-game recommendation**: the user asks for Mac-compatible games similar
  to a named title. Use `--similar-to`; do not treat the seed game's own
  compatibility as the recommendation result.

## Workflow

1. For a single-title check, extract the game name and any supplied chip, memory, macOS version, store, or edition. Do not ask for hardware details unless they are essential to disambiguate the result.
2. Run the bundled collector:

   ```bash
   python3 scripts/check_game.py --game "GAME NAME" --json
   ```

   Add `--chip`, `--macos`, or `--memory-gb` only when the user provides them. The
   collector queries independent primary sources concurrently, applies a shared
   live-query deadline, and reuses a short-lived local cache. Add `--refresh` only
   when the user explicitly asks for a fresh recheck or when a cited update may be
   newer than the cached result; do not routinely disable the cache.
   If Steam's JSON search omits a localized title, the collector falls back to
   Steam's localized web search and then retries compatibility sources with the
   English title from Steam App Details. If CodeWeavers' detail page returns
   403 while its official search table is available, retain the table rating as
   discovery metadata only. Its platform/version is not a verified Mac review.
   Continue the recovery workflow to obtain the exact Mac rating and version.
3. First inspect `retrieval.status` and `retrieval.final_answer_allowed`. Exit code 2 with valid JSON means collection is incomplete, not an incompatible game. When `recovery_required`, execute `retrieval.next_actions` using the host's authorized network/browser/search capabilities before composing a verdict. Do not rerun an unchanged sandbox DNS failure; use authorized network access. Error results are not cached. Native-version failure is not evidence against the Windows version through CrossOver. If all recovery paths fail, report “暂时无法确认” without a numeric rating and explicitly state the unavailable sources. Never replace unknown with zero stars. The collector cannot enforce an assistant's final prose: the assistant must honor this gate and document recovered evidence.
   Inspect `verdict`, `verdict_detail`, `confidence`, `risks`, `errors`, `answer_sources`, `crossover.user_feedback`, `crossover.setting_advice`, and every evidence date. Keep raw `sources` for internal classification, but render only `answer_sources` in the user-facing source block. Read [references/compatibility-rules.md](references/compatibility-rules.md) before resolving a conflict, translating feedback, or using fallback search. Whenever the answer includes CrossOver installation, bottle, graphics, synchronization, or troubleshooting steps, also read [references/crossover-operations.md](references/crossover-operations.md).
   Apply the fail-closed retrieval gate in `references/compatibility-rules.md` immediately before drafting: source/network errors, empty matches, or timeouts never mean “当前不可玩”; with no decisive usable evidence, the result must remain “暂时无法确认”.
   If the collector has source errors and no match, complete the required fallback recovery pass: resolve localized titles via an official page, then inspect the exact canonical CodeWeavers page and official store metadata. A search miss alone must never be reported as “没有 CodeWeavers 条目”.
   **CodeWeavers hard gate:** before emitting any final verdict for a concrete game, confirm that the exact CodeWeavers Compatibility Center page was checked, or record that the direct page was unreachable after a fallback attempt. If the bundled CodeWeavers query fails, times out, returns no match, or returns an empty result, immediately perform a direct canonical-page lookup using the resolved title and inspect its Mac rating, last-tested CrossOver version, stale-rating warning, Tips, and Forum sections. Do not output `当前不可玩`, `需要 CrossOver`, `暂时无法确认`, a star rating, or a poster trigger until this recovery pass is complete. A collector/network failure is a retrieval problem, never compatibility evidence.
   **Recovery must produce a checked result:** read [references/recovery.md](references/recovery.md) whenever the gate is pending. Complete its English-title resolution and one exact-path lookup, save actual host-tool evidence, and run `scripts/recover_game.py`. Draft the compatibility answer from the resulting `verified.json`, not from the failed collector output or a verbal override. A generic web search does not complete this recovery. The script cannot run host browser tools or enforce the assistant's prose; the assistant must perform and record that handoff.
4. If `verdict_detail` is `ambiguous`, output only the numbered plausible game candidates and `请选择 1/2` (or the matching count). Do not add an explanation, device assumptions, compatibility verdict, star rating, or setup advice; do not guess an edition, remake, DLC, or sequel.
5. For a verified `crossover` result, perform the how-to evidence pass in [references/tutorial-evidence.md](references/tutorial-evidence.md) after the primary compatibility route is established. Batch no more than three title-specific searches in parallel and stop after 20 seconds; tutorials enrich `怎么玩` and confidence but never block a verified primary result. For `unknown/not_playable`, do not perform tutorial discovery until a user specifically asks for a workaround. Search only terms relevant to the route; the named creator is an optional high-value target, not a required separate query.
   If the user supplies a Bilibili URL, open that exact URL first and inspect its title, uploader, publish date, tags, description, and visible player state. For an unresolved verdict, do not start a Bilibili search unless the user asks for a workaround.
   This describes optional supporting evidence, not a dependency on a named
   search skill. Prefer direct source URLs and the host's built-in web capability;
   if tutorial discovery is unavailable, say so under confidence without
   weakening or strengthening the primary compatibility verdict.
6. If verdict evidence is missing, contradictory, or low-confidence, search current official publisher/store pages first, followed by MacGamingDB and Porting Kit. Do not rerun the collector with guessed translations when `matched_game` or `candidates` already resolves the title. Never turn “not found” into “not supported.”
7. Do not generate posters during the initial single-title compatibility check.
   Return the verified result first and invite the user to reply with exactly
   `海报` if they want the poster set. This keeps the initial answer fast and avoids
   artwork search and rendering when the user only needs compatibility evidence.
   When the user subsequently replies `海报` (or clearly requests posters) for the
   most recently verified, non-ambiguous title, reuse that result, read
   [references/share-card.md](references/share-card.md), complete its mandatory
   artwork dimension, aspect-ratio, focal-point, and crop suitability pass before
   rendering; do not force one image into every layout. Then generate one share
   card per approved style and build one aggregate page with
   `scripts/build_share_gallery.py`.
   Resolve the current style set at run time instead of assuming a fixed count:

   ```bash
   python3 scripts/render_share_card.py --default-set
   ```

   The renderer is strict by default and prints one approved style id per line in the order used by the
   aggregate page; add `--json` for `{"default_style": ..., "styles": [...],
   "count": N}`. Generate exactly one card per printed id and pass every card to
   the gallery builder. Keep the
   returned absolute aggregate-page link and place it in the `### 分享与反馈`
   block after the sources. The aggregate page is the user-facing share entry point: it
   shows one preview per generated card and one `下载海报` button per preview, without style
   names, audit badges, design notes, or other explanatory copy. Prefer PNG or JPG
   siblings as download targets and inline the selected image file in the button so a
   click triggers a direct image download even from a local `file://` page. Before
   publishing, require one raster sibling per preview and verify that different
   poster styles have different image-content hashes. Stop gallery generation on
   a missing or duplicate raster instead of silently substituting a placeholder,
   SVG, HTML document, or another style's image.
   The default gallery is the final eight-card template, in this exact order:
   `imac-aluminum`, `polaroid`, `serif-study`, `frosted-band`, `glitch-sys`,
   `about-this-mac`, `industrial-plate`, `macos-desktop`. The gallery page must
   use a centered masthead, deep-gray textured background with subtle circular
   line motifs (no star field), a 4×2 poster grid, and the real macOS desktop
   notification/Dock card in position 8. Do not substitute the old `cover-story`
   card for position 8 or rebuild the page with the earlier asymmetric title
   layout. Poster hover is limited to a slight elastic scale-up; downloads remain
   direct image downloads.
   Before sending any completed compatibility or poster response, write the final
   Markdown draft to a temporary file and run
   `python3 scripts/validate_user_response.py --file <draft>`. If it fails, remove
   all internal progress, audit, hash, artwork-selection, style-order, and retry
   language, then validate again. The feedback link must be the final visible
   line; do not emit any text after it. Do not generate cards for candidate-selection, completely offline, unresolved-title,
   or source-free results. If the previous compatibility result is unavailable in
   context, ask for the game name instead of guessing.
8. Answer in the user's language. For a Chinese single-title result, use the output order below.

## Recommendation workflow

Run the dedicated collector rather than looping over arbitrary remembered titles:

```bash
python3 scripts/recommend_games.py [--genre "动作"] [--similar-to "GAME"] \
  [--chip "M3 Pro"] [--memory-gb 18] [--macos "15.6"] \
  [--storage-free-gb 200] [--controller] [--online] [--chinese] \
  [--native-only] [--max-setup simple|medium|complex] [--limit 6] --json
```

If the user explicitly says “这台 Mac” and the tool is running on that Mac, use
`--detect-this-mac`; otherwise do not inspect the host as a substitute for the
user's device. The collector discovers live Steam candidates first and deep-checks
only a shortlist, so do not invoke `check_game.py` sequentially over a large list.

Inspect `recommendations`, `manual_review_candidates`, `excluded`, `hardware_fit`, `setup_effort`,
`compatibility`, `reasons`, and all evidence dates. Exclude unknown and unavailable
games rather than padding the result. For at most two excellent preference matches
listed in `manual_review_candidates`, and only when the user accepts `complex`
setup, the normal tutorial pass may recover a current,
reproducible CrossOver-plus-patch route. Never invent performance from the chip
name; meeting published minimum requirements is not a frame-rate guarantee.

Render recommendation results using the compact table and top-three guidance in
[references/recommendation-rules.md](references/recommendation-rules.md). The
single-title headline template does not apply to recommendation lists.

## Chinese nicknames and abbreviations

Treat a Chinese nickname, abbreviation, transliteration, or regional suffix as an alias candidate rather than as a literal official title. Normalize full-width characters, punctuation, spacing, and common suffixes such as `国服`, `国际服`, `中国版`, `PC版`, and `Windows版` for discovery, but preserve the suffix as an edition constraint. Cross-check the expanded name against Steam, the compatibility database, AppleGamingWiki, and current official pages.

- If one canonical title is the only reasonable match, continue with `match_kind: single_non_exact` and lower confidence internally. Do not print a Chinese-name-to-English-name mapping or describe the title as an alias/non-exact match in the final answer; once verified, answer directly about the requested game.
- If a nickname or abbreviation maps to multiple games, editions, remakes, mobile/PC builds, or DLCs, stop before issuing a verdict. Return `verdict_detail: ambiguous` and output only numbered candidate titles, editions, stores, and exact source links, followed by `请选择 1/2` (or the matching count).
- Never invent an alias mapping from memory. If live evidence cannot resolve the alias, return `暂时无法确认` and explain what is missing; never turn an unresolved nickname into `当前不可玩`.

## Required Answer Shape

Every non-ambiguous compatibility result must be rendered as one self-contained,
page-like Markdown response. Do not prepend progress commentary, a JSON dump, or
an unstructured paragraph. Keep the layout compact and scannable: the verdict is
the page title, the sections below are the content blocks, and sources are the
footer. Use the exact section order and template below; omit a block only when it
has no evidence to report.

When no verified method-specific playable route exists, start with this H2 heading on its own line:

```markdown
## 结果：<primary conclusion>｜<star display>
```

During the initial compatibility answer, do not generate a share card. Add exactly
`生成海报：回复“海报”` in the final `### 分享与反馈` block only when the result
confirms a playable route (`native_mac`, `crossover`, or a method-specific
playable result). For `not_playable` and `unknown` / `暂时无法确认` results, omit
the poster trigger entirely and do not offer poster generation. The word `海报`
is the two-character follow-up trigger; do not replace it with “生成海报”,
“下载海报”, a URL, button, or icon.

After the user replies `海报` and a share card was generated, place its returned
aggregate-page Markdown link inside the final `### 分享与反馈` block, above the
feedback form link. Use exactly
`下载海报：[立即下载](<absolute aggregate-page path>)`: keep the plain-text label
outside the link and make only `立即下载` blue/clickable. Pair it visually with
`兼容反馈：[填写反馈](https://wj.qq.com/s2/27740110/7ceg/)`; both rows use a four-character
label, a full-width colon, and a four-character action. Do not add icons, the game
name, “打开”, “分享”, “聚合页”, or explanatory wording. The `### 分享与反馈` block
must contain only these two rows. Do not show poster
counts, file formats, verification status, download behavior, gallery
descriptions, or any other explanatory sentence in that block. If the
CrossOver download footer is emitted, place that footer on the first line below
the H2 result heading. Do not invent a link when rendering failed. Recommendation
lists do not receive share cards in v1.

Render a numeric rating as five symbols, for example `★★☆☆☆` for 2 stars. When no CodeWeavers macOS rating exists, use `未评级`. Do not print `CodeWeavers：` or an English rating label in this headline; retain the canonical `rating_label` only in structured evidence and internal classification.

Use exactly one primary conclusion in that line:

- `原生 Mac 版` — an official macOS build exists. If it is Intel-only, say `官方 macOS 版，需 Rosetta 2` and do not call it Apple-silicon-native.
- `需要 CrossOver` — no confirmed official macOS build is available and CrossOver evidence indicates the game runs.
- `当前不可玩` or `暂时无法确认` — distinguish explicit incompatibility from missing or conflicting evidence.

If a current, title-specific tutorial shows that the exact game or regional edition reaches gameplay through an in-scope non-official desktop method, replace the standard verdict headline with the practical playable result. Render only this one H2 heading:

```markdown
## 结果：使用CrossOver+第三方插件可玩
```

- Use `结果：使用CrossOver+第三方插件可玩` when a CrossOver route also requires a patch, modified library, mod, or other extra component to reach gameplay. Keep this exact compact spelling so both requirements are visible.
- Use `结果：使用 CrossOver Preview 可玩` when Preview itself is the distinguishing requirement and no third-party component is required.
- Use `结果：调整 CrossOver 配置后可玩` when current evidence requires only non-default CrossOver settings.
- Use `结果：使用 Windows 虚拟机可玩` for a verified Parallels or other Windows-VM route.
- Use `结果：使用第三方工具可玩` only when none of the more precise headings applies.

Do not add a star rating or a second `标准兼容状态` heading when this method-specific playable result is shown. The rating describes the standard route rather than the third-party method and would make the practical result harder to read. If the standard database record conflicts with the working method, mention that briefly under `关键限制` or `可信度` only when it helps explain the evidence. Do not print `社区方案可玩`. Do not use the method-specific headline for PlayCover/iOS sideloading, a generic tutorial, database listing, install-only report, stale or mismatched edition, or an unsupported claim.

Under the result heading, present these page blocks as H3 headings, in order:

```markdown
### 怎么玩
<put the most reproducible working route first; include required community components, numbered steps, and exact tutorial links with publication dates; in Chinese answers, put a qualifying Bilibili tutorial first>

### 适用设备
<assumed or supplied chip, memory, and macOS version>

### 关键限制
<anti-cheat, offline-only play, launcher failures, crashes, performance gaps, and stale evidence>

### CodeWeavers 用户反馈
<include only when crossover.user_feedback is non-empty; translate every item with a faithful Chinese translation, and retain the original text>

### 可信度
<高、中或低，并简要说明理由>

### 来源
- <exact link from `answer_sources`>（test/update date; query date）

When citing a video, use its real title, uploader, and date. Never add visible
research-strategy labels such as `B站参考（中文优先）`, `中文优先`, `检索优先`,
or `补充证据`; those are internal selection criteria, not user-facing content.

### 分享与反馈
<before generation: 生成海报：回复“海报”>
<after generation: 下载海报：[立即下载](<absolute aggregate-page path>)>
<feedback form link as the final line>
```

### Chinese wording rules for CrossOver results

- Treat a verified CrossOver route as an affirmative conclusion. Start the first
  sentence below the result heading with exactly `需要 CrossOver 玩。` Do not lead
  with a contrast such as `可以玩，但不是原生 Mac 版` or explain the absence of a
  native build unless the user specifically asks about native availability.
- The user-facing answer is macOS-only. Never mention Linux ratings, Linux
  blocks, or a macOS-versus-Linux distinction. Keep that separation only in the
  internal evidence check that prevents platform-rating mix-ups.
- Immediately before sending, verify the response has the prescribed H2 result
  heading and H3 blocks in order, and that `### 分享与反馈` is present. Its last
  line must be exactly `兼容反馈：[填写反馈](https://wj.qq.com/s2/27740110/7ceg/)`.
  For a verified playable route before poster generation, the only preceding
  line in that block is `生成海报：回复“海报”`.

Use short paragraphs, bullets, or a compact table inside each block when that
makes the result easier to scan. Keep the default page concise; do not repeat the
same fact in multiple blocks. `CodeWeavers 用户反馈` remains optional and must be
omitted when there are no returned user notes. In `可信度`, explain evidence
quality, freshness, conflicts, or device coverage; do not expose title-resolution
mechanics such as `alias`, `single_non_exact`, or “中文名对应英文名”.

Keep the default response concise. Offer deeper installation or tuning steps only after the compatibility conclusion is clear.

## CrossOver download footer

When the final answer visibly mentions CrossOver anywhere—including a verdict,
installation method, limitation, source, or user-feedback block—run this gate
immediately before sending the answer. Resolve `scripts/` relative to the
directory containing this `SKILL.md`, not the caller's working directory:

```bash
python3 scripts/crossover_footer_gate.py
```

- If the command prints a line, append it verbatim on the first line immediately
  below the H2 result heading, before the aggregate-page link and all answer
  sections.
- If the command prints nothing, omit the footer. The gate suppresses another
  copy for 180 seconds.
- Do not run the gate and do not add the footer when the visible answer does not
  mention CrossOver.
- Call the gate only once per answer. Do not recreate, shorten, translate, or
  otherwise alter the returned Markdown link.

## Compatibility feedback

Every completed compatibility answer must end with this link on its own line,
inside `### 分享与反馈`:

`兼容反馈：[填写反馈](https://wj.qq.com/s2/27740110/7ceg/)`

Keep it after every other block so it is always the final line. Do not add it to
ambiguous candidate-only answers.

## Guardrails

- Treat a Steam `mac: false` flag as “no Steam Mac build,” not proof that no Mac version exists in another store.
- Show a Steam Store link in the user-facing `来源` block only when `verdict` is `native_mac` and `native.steam_mac` is `true`. Hide Steam links for CrossOver, third-party-plugin, virtual-machine, unavailable, and unknown results. A Windows Steam purchase or launcher may be part of the setup steps, but it is not a native Mac store link. Preserve Steam in raw structured evidence for classification.
- Prefer an official macOS build over CrossOver even when both work.
- Preserve a CrossOver verdict for a playable single-player game whose online mode is blocked, but prominently label it `仅离线可玩`.
- Mark an online-only game as currently unplayable when required anti-cheat cannot run.
- Never invent frame rates, graphics settings, CrossOver versions, backends, or performance guarantees.
- For CrossOver 26 or later, present the listed application profile and `Auto` graphics selection as the baseline path unless a current title-specific official recipe or reproducible community route explicitly requires another backend. When a community route requires DXVK, a patched MoltenVK, or another component to reach gameplay, put it in `怎么玩` and label it `该社区方案必需`; do not mislabel it as a CrossOver default.
- Label every non-default CrossOver setting as `官方配置`, `实测建议`, or `排障尝试`. Include its source date and tested CrossOver version when available. A stale community setting must be described as an old record to try only if the baseline path fails.
- Treat graphics and synchronization settings as bottle-scoped. Never combine DXVK, D3DMetal, DXMT, MSync, ESync, registry edits, or patches from different reports into a synthetic recipe. Prefer a separate bottle and advise archiving it before material changes.
- Do not omit a necessary community patch merely because it is unofficial. State what fails without it, what the patch changes, its tested version/device, and how to back up or revert. Prefer the original project/release page over a short link or cloud mirror. Never link cracked games, license bypasses, or unverifiable repacks.
- Do not treat PlayCover, iOS/iPadOS sideloading, or mobile-device wrappers as a Mac-game option or compatibility evidence. They are out of scope for this Skill and cannot trigger a playable-method heading; if they are the only way found, keep the primary verdict based on native/CrossOver evidence or return `暂时无法确认`.
- Keep current title-specific Bilibili videos from any verified uploader identity when they demonstrate an in-scope desktop method such as CrossOver, GPTK, Wine, DXMT, or Parallels. Search `我是艾文喵` as an additional target, but do not exclude other creators. For Chinese answers, place a qualifying Bilibili tutorial before tutorials from other platforms. Cite the exact `BV` video page, uploader UID, edition, method, and publication date directly beside the link in `YYYY-MM-DD` form. If the Bilibili video shows gameplay but omits reproducible setup steps, label it `B站实机演示（非完整教程）`; it may appear first among video links but must not replace the detailed instructions or original patch documentation.
- When a verified method-specific route is playable, render only its `结果：...可玩` H2 headline. Do not add the standard verdict or star rating as another heading; explain a conflicting standard record later only when useful.
- Treat the collector's CodeWeavers `rating` and `rating_label` as the canonical macOS rating for classification. Use the numeric rating to render the star symbols, but omit the `rating_label` and `CodeWeavers：` prefix from the Chinese headline.
- Do not claim that a rating for Linux applies to macOS. CodeWeavers pages place the Linux block beside the Mac block; use the macOS JSON-LD review only. In particular, 2 stars means `Installs, Will Not Run`, while 1 star means `Will Not Install`.
- Translate CodeWeavers user feedback without softening failures, strengthening praise, or changing version numbers, frame rates, settings, hardware, and uncertainty. Preserve each `original_text` beside its translation. Feedback can add a reported limitation or setup clue but cannot override the canonical macOS rating or independently decide the verdict.
- Treat MacGamingDB, Porting Kit, and community videos as supplementary verdict sources, but use detailed current tutorials to establish the steps and required components of that demonstrated community route. They do not become an official CrossOver rating. Do not translate a Porting Kit recipe into a CodeWeavers rating or assume its Wine settings transfer directly to CrossOver.
- Mention that compatibility can change after game, launcher, macOS, or CrossOver updates. Recommend a current trial test when the user is about to purchase software or hardware.
