#!/usr/bin/env python3
"""Validate source excerpts gathered by host tools and resume a failed query.

This does not search the web. Evidence must be copied from actual tool output.
Numeric ratings supplied by the caller are not trusted; parse the Mac block.
"""
from __future__ import annotations

import argparse
import copy
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import re
from urllib.parse import urlparse

import check_game as collector


def parse_mac_excerpt(text: str, title: str) -> dict:
    if not isinstance(text, str) or not isinstance(title, str):
        raise ValueError('Page excerpt and title must be strings')
    # Require the page's own heading, not a passing reference in another page.
    headings = [line.strip().lstrip('#').strip() for line in text.splitlines()]
    if title not in headings:
        raise ValueError('Exact CodeWeavers game heading missing')
    mac_sections = list(re.finditer(r'^\s*#{0,6}\s*Mac Rating\s*$', text, re.M))
    if len(mac_sections) != 1:
        raise ValueError('Mac Rating section missing; Linux ratings are not Mac evidence')
    mac = mac_sections[0]
    block = text[mac.end():]
    # Keep Markdown warning headings inside the Mac block until its platform
    # boundary, so an Outdated Rating heading cannot disappear during parsing.
    block = re.split(r'^\s*#{0,6}\s*(?:CrossOver )?Linux Rating\s*$', block, maxsplit=1, flags=re.M)[0]
    if 'outdated rating' in block.casefold():
        raise ValueError('Mac rating is explicitly outdated; fresh evidence needed')
    block = re.split(r'^\s*#{1,6}\s*', block, maxsplit=1, flags=re.M)[0]
    labels = [(number, label) for number, label in collector.RATING_LABELS.items()
              if re.search(r'(?<!\w)' + re.escape(label) + r'(?!\w)', block)]
    if len(labels) != 1:
        raise ValueError('Mac rating label missing or conflicting; star glyph counts are not evidence')
    version = re.search(r'Last Tested:\s*([0-9]+(?:\.[0-9]+){1,3})\b', block)
    if not version:
        raise ValueError('Last-tested CrossOver version missing from Mac block')
    return {'rating': labels[0][0], 'rating_label': labels[0][1],
            'last_tested_version': version.group(1), 'last_tested_date': None}


def validate_record(record: dict, host: str, path_pattern: str) -> tuple[str, str]:
    if not isinstance(record, dict):
        raise ValueError('Source record must be an object')
    url = record.get('url', '')
    if not isinstance(url, str):
        raise ValueError('Source URL must be a string')
    parsed = urlparse(url)
    if parsed.scheme != 'https' or parsed.netloc != host or not re.fullmatch(path_pattern, parsed.path):
        raise ValueError('Invalid exact source URL: ' + url)
    text = record.get('text')
    if not isinstance(text, str) or not text.strip():
        raise ValueError('Source excerpt missing')
    raw_stamp = record.get('retrieved_at', '')
    if not isinstance(raw_stamp, str):
        raise ValueError('Retrieval timestamp must be a string')
    stamp = datetime.fromisoformat(raw_stamp.replace('Z', '+00:00'))
    if stamp.tzinfo is None:
        raise ValueError('Retrieval timestamp needs timezone')
    age = (datetime.now(timezone.utc) - stamp).total_seconds()
    if age < -300 or age > 7 * 86400:
        raise ValueError('Recovery excerpt must have been retrieved within seven days')
    return url, text


def recover(result: dict, evidence: dict) -> dict:
    if not isinstance(result, dict) or not isinstance(evidence, dict):
        raise ValueError('Collected result and recovery evidence must be objects')
    if not isinstance(result.get('query'), str) or not result['query'].strip():
        raise ValueError('Original query missing')
    result = copy.deepcopy(result)
    if result.get('verdict_detail') == 'ambiguous':
        raise ValueError('Resolve ambiguous identity before recovery')
    if evidence.get('query') != result.get('query'):
        raise ValueError('Recovery query does not match original query')
    identity = evidence['identity']
    store_url, store_text = validate_record(identity, 'store.steampowered.com', r'/app/[0-9]+/?')
    title = identity.get('english_title', '')
    if not isinstance(title, str) or not title or title not in store_text or result['query'] not in store_text:
        raise ValueError('Official excerpt must connect original query and English title')
    appid = int(urlparse(store_url).path.strip('/').split('/')[1])
    previous_id = (result.get('matched_game') or {}).get('steam_appid')
    if previous_id is not None and int(previous_id) != appid:
        raise ValueError('Recovery Steam App ID conflicts with the collected game')
    cw = evidence['codeweavers']
    url, text = validate_record(cw, 'www.codeweavers.com', r'/compatibility/crossover/[^/]+/?')
    if cw.get('method') not in {'direct_page_text', 'exact_page_index'}:
        raise ValueError('Use direct page text or exact-page indexed evidence')
    if cw['method'] == 'exact_page_index':
        lookup = cw.get('lookup_query', '')
        if urlparse(url).path not in lookup or 'Mac Rating' not in lookup:
            raise ValueError('Indexed recovery requires a query targeting the exact path and Mac Rating')
    parsed = parse_mac_excerpt(text, title)
    parsed.update({'url': url, 'user_feedback': [], 'settings': [], 'setting_advice': [],
                   'notes': [], 'evidence': [{'source': 'CodeWeavers Compatibility Center',
                    'url': url, 'method': cw['method'], 'checked_at': cw['retrieved_at'],
                    'rating': parsed['rating'], 'version': parsed['last_tested_version']}]})
    old = result.get('crossover') or {}
    old_rating = old.get('rating') or old.get('search_table_rating')
    # Never silently reconcile two claimed Mac detail ratings. Table summaries
    # remain discovery metadata; their scope and version have not been verified.
    if old.get('last_tested_version') and old.get('rating') != parsed['rating']:
        raise ValueError('Conflicting Mac detail ratings require manual freshness review')
    result['recovery'] = {'status': 'verified', 'query': result['query'],
        'identity': identity, 'codeweavers': cw,
        'evidence_sha256': hashlib.sha256((store_text + '\n' + text).encode()).hexdigest(),
        'previous_rating': old_rating,
        'limitations': ['Test date, hardware, Tips and Forum are not inferred from indexed rating text.']}
    result['matched_game'] = {**result.get('matched_game', {}), 'title': title,
                             'steam_appid': appid, 'match_kind': 'exact'}
    result['crossover'] = parsed
    result['retrieved_errors'] = result.get('errors', [])
    result['sources'] = [s for s in result.get('sources', []) if s.get('url') != url]
    result['sources'].extend([
        {'name': 'Steam Store', 'url': store_url, 'kind': 'official_store', 'checked_at': identity['retrieved_at']},
        {'name': 'CodeWeavers Compatibility Center', 'url': url,
         'kind': cw['method'], 'checked_at': cw['retrieved_at'], 'date': None}])
    native = result.get('native') or {}
    # Do not import a caller-supplied native availability flag from this bundle.
    agw = {'crossover_status': old.get('agw_status'), 'crossover_report_date': old.get('agw_date')} if old.get('agw_status') else None
    verdict, detail, confidence, risks = collector.classify(
        native, parsed, agw, datetime.now(timezone.utc), 'exact', result.get('errors', []), result.get('risks', []))
    result.update(verdict=verdict, verdict_detail=detail, confidence='medium' if confidence == 'high' else confidence, risks=risks)
    if old_rating is not None and old_rating != parsed['rating']:
        result['risks'].append({'kind': 'search_detail_discrepancy', 'severity': 'medium',
            'message': f"搜索表评级为 {old_rating}，精确页面记录为 {parsed['rating']}；保留精确页面的版本对应评级，当前搜索表与索引存在差异。",
            'source': url})
    collector.apply_retrieval_gate(result)
    result['answer_sources'] = collector.answer_sources(result)
    result['cache'] = {'hit': False, 'ttl_seconds': 0, 'age_seconds': 0}
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--result', type=Path, required=True)
    parser.add_argument('--evidence', type=Path, required=True)
    parser.add_argument('--output', type=Path, required=True)
    args = parser.parse_args()
    try:
        result = recover(json.loads(args.result.read_text()), json.loads(args.evidence.read_text()))
    except (ValueError, KeyError, TypeError) as exc:
        parser.exit(2, 'Recovery rejected: ' + str(exc) + '\n')
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
    print(collector.human_summary(result))
    return 0 if result['retrieval']['final_answer_allowed'] else 2


if __name__ == '__main__':
    raise SystemExit(main())
