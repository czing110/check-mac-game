#!/usr/bin/env python3
"""Collect and normalize public evidence about Mac game compatibility."""

from __future__ import annotations

import argparse
import base64
import binascii
from concurrent.futures import ThreadPoolExecutor, as_completed
import hashlib
import html
from html.parser import HTMLParser
from http.cookiejar import CookieJar
import json
import os
from pathlib import Path
import re
import sys
import tempfile
import time
import unicodedata
from datetime import datetime, timezone
from typing import Any, Iterable, Optional
from urllib.error import HTTPError, URLError
from urllib.parse import quote, urlencode
from urllib.request import HTTPCookieProcessor, Request, build_opener


USER_AGENT = "check-mac-game/1.0 (+https://github.com/)"
STALE_DAYS = 548
CONFLICT_MARGIN_DAYS = 90
REQUEST_TIMEOUT_SECONDS = 6.0
TOTAL_TIMEOUT_SECONDS = 14.0
CACHE_TTL_SECONDS = 24 * 60 * 60
UNKNOWN_CACHE_TTL_SECONDS = 60 * 60
ERROR_CACHE_TTL_SECONDS = 5 * 60

STEAM_SEARCH = "https://store.steampowered.com/api/storesearch/"
STEAM_WEB_SEARCH = "https://store.steampowered.com/search/"
STEAM_DETAILS = "https://store.steampowered.com/api/appdetails"
CODEWEAVERS_SEARCH = "https://www.codeweavers.com/compatibility"
CODEWEAVERS_ROOT = "https://www.codeweavers.com"
CODEWEAVERS_BREAKDOWN = CODEWEAVERS_ROOT + "/bin/json/plugin/app_breakdown/"
AGW_API = "https://www.applegamingwiki.com/w/api.php"
AGW_ROOT = "https://www.applegamingwiki.com/wiki/"

POSITIVE_STATUSES = {"perfect", "playable", "runs", "runs well", "good"}
NEGATIVE_STATUSES = {"unplayable"}
INCONCLUSIVE_STATUSES = {"", "unknown", "na", "n/a", "none", "unrated"}
RATING_LABELS = {
    1: "Will Not Install",
    2: "Installs, Will Not Run",
    3: "Limited Functionality",
    4: "Runs Well",
    5: "Runs Great",
}
CONFIDENCE_ORDER = ["low", "medium", "high"]


class FetchError(RuntimeError):
    pass


class HttpClient:
    """Small deadline-aware HTTP client using only the standard library."""

    def __init__(self, timeout: float = REQUEST_TIMEOUT_SECONDS, retries: int = 0) -> None:
        self.timeout = timeout
        self.retries = retries
        self.opener = build_opener(HTTPCookieProcessor(CookieJar()))
        self.deadline: Optional[float] = None

    def start_budget(self, seconds: float = TOTAL_TIMEOUT_SECONDS) -> None:
        self.deadline = time.monotonic() + max(0.1, seconds)

    def _request_timeout(self) -> float:
        if self.deadline is None:
            return self.timeout
        remaining = self.deadline - time.monotonic()
        if remaining <= 0:
            raise FetchError("query time budget exhausted")
        return max(0.1, min(self.timeout, remaining))

    def get_text(self, url: str, headers: Optional[dict[str, str]] = None) -> str:
        last_error: Optional[Exception] = None
        for attempt in range(self.retries + 1):
            try:
                request_headers = {
                    "User-Agent": USER_AGENT,
                    "Accept": "application/json,text/html;q=0.9,*/*;q=0.8",
                }
                if headers:
                    request_headers.update(headers)
                request = Request(
                    url,
                    headers=request_headers,
                )
                with self.opener.open(request, timeout=self._request_timeout()) as response:
                    charset = response.headers.get_content_charset() or "utf-8"
                    return response.read().decode(charset, errors="replace")
            except (HTTPError, URLError, TimeoutError, OSError) as exc:
                last_error = exc
                if attempt < self.retries:
                    delay = 0.25 * (attempt + 1)
                    if self.deadline is not None and time.monotonic() + delay >= self.deadline:
                        break
                    time.sleep(delay)
        raise FetchError(str(last_error) if last_error else "unknown fetch error")

    def get_json(self, url: str, headers: Optional[dict[str, str]] = None) -> Any:
        try:
            return json.loads(self.get_text(url, headers=headers))
        except json.JSONDecodeError as exc:
            raise FetchError(f"invalid JSON: {exc}") from exc


class SteamWebSearchParser(HTMLParser):
    """Read localized Steam titles when the storesearch JSON omits them."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.current: Optional[dict[str, Any]] = None
        self.title_depth = 0
        self.results: list[dict[str, Any]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, Optional[str]]]) -> None:
        values = dict(attrs)
        classes = set((values.get("class") or "").split())
        if tag == "a" and "search_result_row" in classes:
            app_id = values.get("data-ds-appid")
            href = values.get("href") or ""
            if app_id and app_id.isdigit():
                self.current = {"id": int(app_id), "href": href, "title": []}
            return
        if self.current is not None and tag == "span" and "title" in classes:
            self.title_depth = 1

    def handle_data(self, data: str) -> None:
        if self.current is not None and self.title_depth:
            self.current["title"].append(data)

    def handle_endtag(self, tag: str) -> None:
        if self.current is None:
            return
        if tag == "span" and self.title_depth:
            self.title_depth = 0
            return
        if tag == "a":
            title = compact_whitespace("".join(self.current["title"]))
            if title:
                self.results.append(
                    {
                        "name": title,
                        "id": self.current["id"],
                        "url": self.current["href"],
                        "aliases": [title],
                    }
                )
            self.current = None


def parse_steam_web_search(document: str) -> list[dict[str, Any]]:
    parser = SteamWebSearchParser()
    parser.feed(document)
    return unique_dicts(parser.results, "id")


class CodeWeaversSearchParser(HTMLParser):
    """Extract application links from the search-results table only."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tbody_depth = 0
        self.current_href: Optional[str] = None
        self.current_text: list[str] = []
        self.results: list[dict[str, str]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, Optional[str]]]) -> None:
        if tag == "tbody":
            self.tbody_depth += 1
            return
        if tag != "a" or self.tbody_depth == 0:
            return
        values = dict(attrs)
        href = values.get("href") or ""
        if href.startswith("/compatibility/crossover/"):
            self.current_href = href
            self.current_text = []

    def handle_data(self, data: str) -> None:
        if self.current_href is not None:
            self.current_text.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self.current_href is not None:
            title = compact_whitespace("".join(self.current_text))
            if title:
                self.results.append(
                    {
                        "name": title,
                        "url": CODEWEAVERS_ROOT + self.current_href,
                    }
                )
            self.current_href = None
            self.current_text = []
        elif tag == "tbody" and self.tbody_depth:
            self.tbody_depth -= 1


class CodeWeaversSearchRowParser(HTMLParser):
    """Extract rating metadata from the compatibility search table.

    CodeWeavers sometimes serves the table while blocking detail pages.
    Preserve the row as discovery metadata; its platform and tested version
    are not established by counting styled list items.
    """

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.tbody_depth = 0
        self.row: Optional[dict[str, Any]] = None
        self.cell: Optional[dict[str, Any]] = None
        self.anchor: Optional[dict[str, str]] = None
        self.rows: list[dict[str, Any]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, Optional[str]]]) -> None:
        values = dict(attrs)
        if tag == "tbody":
            self.tbody_depth += 1
            return
        if self.tbody_depth == 0:
            return
        if tag == "tr" and self.row is None:
            self.row = {"cells": [], "rating": 0}
            return
        if self.row is None:
            return
        if tag == "td" and self.cell is None:
            self.cell = {"text": [], "rating": 0, "classes": set()}
            return
        if self.cell is None:
            return
        if tag == "a":
            href = values.get("href") or ""
            if href.startswith("/compatibility/crossover/"):
                self.anchor = {"href": href, "text": ""}
        if tag == "li" and "active" in set((values.get("class") or "").split()):
            self.cell["rating"] += 1

    def handle_data(self, data: str) -> None:
        if self.cell is not None:
            self.cell["text"].append(data)
        if self.anchor is not None:
            self.anchor["text"] += data

    def handle_endtag(self, tag: str) -> None:
        if tag == "a" and self.anchor is not None:
            self.anchor["text"] = compact_whitespace(self.anchor["text"])
            if self.row is not None:
                self.row["href"] = self.anchor["href"]
                self.row["name"] = self.anchor["text"]
            self.anchor = None
            return
        if tag == "td" and self.cell is not None and self.row is not None:
            self.cell["value"] = compact_whitespace("".join(self.cell["text"]))
            self.row["cells"].append(self.cell)
            self.row["rating"] = max(self.row["rating"], self.cell["rating"])
            self.cell = None
            return
        if tag == "tr" and self.row is not None:
            cells = self.row["cells"]
            # The application anchor is captured on the row when it closes.
            href = self.row.get("href")
            name = self.row.get("name")
            if href and name:
                item: dict[str, Any] = {
                    "name": name,
                    "url": CODEWEAVERS_ROOT + href,
                    "rating": self.row["rating"] or None,
                }
                if len(cells) > 2:
                    item["last_updated"] = cells[2].get("value") or None
                self.rows.append(item)
            self.row = None
            self.cell = None
            return
        if tag == "tbody" and self.tbody_depth:
            self.tbody_depth -= 1

    def handle_startendtag(self, tag: str, attrs: list[tuple[str, Optional[str]]]) -> None:
        self.handle_starttag(tag, attrs)
        self.handle_endtag(tag)


class JsonLdParser(HTMLParser):
    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.capturing = False
        self.buffer: list[str] = []
        self.documents: list[Any] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, Optional[str]]]) -> None:
        if tag != "script":
            return
        values = {key.lower(): value for key, value in attrs}
        if (values.get("type") or "").lower() == "application/ld+json":
            self.capturing = True
            self.buffer = []

    def handle_data(self, data: str) -> None:
        if self.capturing:
            self.buffer.append(data)

    def handle_endtag(self, tag: str) -> None:
        if tag != "script" or not self.capturing:
            return
        raw = "".join(self.buffer).strip()
        if raw:
            try:
                self.documents.append(json.loads(raw))
            except json.JSONDecodeError:
                pass
        self.capturing = False
        self.buffer = []


class CodeWeaversBreakdownParser(HTMLParser):
    """Extract ordered rating-breakdown identifiers from an application page."""

    def __init__(self) -> None:
        super().__init__(convert_charrefs=True)
        self.current: Optional[dict[str, Any]] = None
        self.row_depth = 0
        self.rows: list[dict[str, Any]] = []

    def handle_starttag(self, tag: str, attrs: list[tuple[str, Optional[str]]]) -> None:
        values = dict(attrs)
        row_match = re.fullmatch(r"row_(\d+)", values.get("id") or "")
        if tag == "div" and self.current is None and row_match:
            self.current = {
                "cache_id": row_match.group(1),
                "rating": 0,
                "platform": None,
                "text": [],
            }
            self.row_depth = 1
            return
        if self.current is None:
            return
        if tag == "div":
            self.row_depth += 1
        classes = set((values.get("class") or "").split())
        if tag == "li" and "active" in classes:
            self.current["rating"] += 1
        if tag == "i":
            if "fa-apple" in classes:
                self.current["platform"] = "macos"
            elif "fa-linux" in classes:
                self.current["platform"] = "linux"

    def handle_data(self, data: str) -> None:
        if self.current is not None:
            self.current["text"].append(data)

    def handle_endtag(self, tag: str) -> None:
        if self.current is None or tag != "div":
            return
        self.row_depth -= 1
        if self.row_depth:
            return
        text = compact_whitespace("".join(self.current.pop("text")))
        version_match = re.search(r"\b\d+(?:\.\d+)+\b", text)
        self.current["version"] = version_match.group(0) if version_match else None
        if self.current.get("platform") is None:
            if "macos" in text.casefold():
                self.current["platform"] = "macos"
            elif "linux" in text.casefold():
                self.current["platform"] = "linux"
        self.rows.append(self.current)
        self.current = None


def strip_html_markup(value: Any) -> str:
    return compact_whitespace(html.unescape(re.sub(r"<[^>]+>", " ", str(value or ""))))


def extract_codeweavers_csrf(document: str) -> Optional[str]:
    match = re.search(
        r"<div\b[^>]*\bid=[\"']userdata[\"'][^>]*>([^<]+)</div>",
        document,
        re.IGNORECASE,
    )
    if not match:
        return None
    encoded = html.unescape(match.group(1)).strip()
    try:
        encoded += "=" * (-len(encoded) % 4)
        payload = json.loads(base64.b64decode(encoded).decode("utf-8"))
    except (binascii.Error, ValueError, UnicodeDecodeError, json.JSONDecodeError):
        return None
    token = payload.get("csrf_token") if isinstance(payload, dict) else None
    return str(token) if token else None


def parse_codeweavers_user_feedback(
    payload: Any,
    crossover_version: Optional[str],
    page_url: str,
) -> list[dict[str, Any]]:
    if not isinstance(payload, dict):
        return []
    feedback: list[dict[str, Any]] = []
    for source_key, source_type in (("adv", "bettertester"), ("cust", "customer")):
        entries = payload.get(source_key)
        if not isinstance(entries, list):
            continue
        for entry in entries:
            if not isinstance(entry, dict):
                continue
            original_text = strip_html_markup(entry.get("notes"))
            if not original_text:
                continue
            medal = str(entry.get("medal") or "")
            rating = len(
                re.findall(
                    r"<li\b[^>]*\bclass=[\"'][^\"']*\bactive\b[^\"']*[\"']",
                    medal,
                    re.IGNORECASE,
                )
            )
            feedback.append(
                {
                    "source_type": source_type,
                    "author": strip_html_markup(entry.get("customer")) or "Anonymous",
                    "rating": rating or None,
                    "date": compact_whitespace(str(entry.get("rank_time") or "")) or None,
                    "crossover_version": crossover_version,
                    "original_text": original_text,
                    "translation_required": not bool(re.search(r"[\u3400-\u9fff]", original_text)),
                    "url": page_url,
                }
            )
    return sorted(
        feedback,
        key=lambda item: (str(item.get("date") or ""), item["source_type"]),
        reverse=True,
    )


def utc_now() -> datetime:
    return datetime.now(timezone.utc)


def iso_now() -> str:
    return utc_now().replace(microsecond=0).isoformat().replace("+00:00", "Z")


def compact_whitespace(value: str) -> str:
    return re.sub(r"\s+", " ", value).strip()


def normalize_title(value: str) -> str:
    normalized = unicodedata.normalize("NFKC", value).casefold()
    normalized = normalized.replace("™", "").replace("®", "").replace("©", "")
    normalized = re.sub(r"[^\w]+", " ", normalized, flags=re.UNICODE)
    return compact_whitespace(normalized)


def contains_cjk(value: str) -> bool:
    return bool(re.search(r"[\u3400-\u9fff]", value))


def default_cache_dir() -> Path:
    configured = os.environ.get("CHECK_MAC_GAME_CACHE_DIR")
    if configured:
        return Path(configured).expanduser()
    return Path(tempfile.gettempdir()) / "check-mac-game-cache"


def cache_key(game: str, chip: str, macos: str, memory_gb: Optional[int]) -> str:
    payload = json.dumps(
        {
            "game": normalize_title(game),
            "chip": normalize_title(chip),
            "macos": normalize_title(macos),
            "memory_gb": memory_gb,
        },
        ensure_ascii=False,
        sort_keys=True,
    )
    return hashlib.sha256(payload.encode("utf-8")).hexdigest()


def load_cached_result(path: Path, require_retrieval: bool = True) -> Optional[dict[str, Any]]:
    try:
        payload = json.loads(path.read_text(encoding="utf-8"))
        stored_at = float(payload["stored_at"])
        ttl = int(payload["ttl_seconds"])
        result = payload["result"]
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError):
        return None
    age = max(0, int(time.time() - stored_at))
    if age >= ttl or not isinstance(result, dict):
        return None
    if result.get("errors"):
        return None
    if require_retrieval and (result.get("retrieval", {}).get("schema_version") != 2 or result.get("retrieval", {}).get("status") != "complete"):
        return None
    result["cache"] = {
        "hit": True,
        "age_seconds": age,
        "ttl_seconds": ttl,
        "served_at": iso_now(),
    }
    return result


def result_cache_ttl(result: dict[str, Any]) -> int:
    if result.get("errors") or result.get("retrieval", {}).get("status") != "complete":
        return 0
    if result.get("verdict_detail") in {"unknown", "ambiguous"}:
        return UNKNOWN_CACHE_TTL_SECONDS
    return CACHE_TTL_SECONDS


def store_cached_result(path: Path, result: dict[str, Any], ttl: int) -> None:
    payload = {
        "stored_at": time.time(),
        "ttl_seconds": ttl,
        "result": result,
    }
    try:
        path.parent.mkdir(parents=True, exist_ok=True)
        temporary = path.with_suffix(f".{os.getpid()}.tmp")
        temporary.write_text(
            json.dumps(payload, ensure_ascii=False, separators=(",", ":")),
            encoding="utf-8",
        )
        temporary.replace(path)
    except OSError:
        return


def unique_dicts(items: Iterable[dict[str, Any]], key: str) -> list[dict[str, Any]]:
    seen: set[Any] = set()
    result: list[dict[str, Any]] = []
    for item in items:
        marker = item.get(key)
        if marker in seen:
            continue
        seen.add(marker)
        result.append(item)
    return result


def is_steam_source(source: dict[str, Any]) -> bool:
    """Identify Steam evidence without relying on one display label."""

    name = str(source.get("name") or source.get("source") or "").casefold()
    url = str(source.get("url") or "").casefold()
    return "steam" in name or "store.steampowered.com" in url


def answer_sources(result: dict[str, Any]) -> list[dict[str, Any]]:
    """Return sources suitable for the user-facing answer.

    Steam remains in ``sources`` as classification evidence.  It is shown to the
    user only when the result confirms that this exact Steam build has native
    macOS support; a Windows Steam purchase used through a compatibility layer is
    not presented as a Mac download link.
    """

    show_steam = (
        result.get("verdict") == "native_mac"
        and (result.get("native") or {}).get("steam_mac") is True
    )
    return [
        source
        for source in (result.get("sources") or [])
        if show_steam or not is_steam_source(source)
    ]


def choose_candidate(
    query: str, candidates: list[dict[str, Any]], name_key: str = "name"
) -> tuple[Optional[dict[str, Any]], str, list[dict[str, Any]]]:
    """Choose only an exact normalized title or a sole returned candidate."""

    dedupe_key = "id" if candidates and all(item.get("id") is not None for item in candidates) else name_key
    candidates = unique_dicts(candidates, dedupe_key)
    query_key = normalize_title(query)
    exact = [item for item in candidates if normalize_title(str(item.get(name_key, ""))) == query_key]
    if len(exact) == 1:
        return exact[0], "exact", candidates
    if len(exact) > 1:
        return None, "ambiguous", exact
    alias_exact = [
        item
        for item in candidates
        if any(normalize_title(str(alias)) == query_key for alias in item.get("aliases", []))
    ]
    if len(alias_exact) == 1:
        return alias_exact[0], "single_non_exact", candidates
    if len(alias_exact) > 1:
        return None, "ambiguous", alias_exact
    if len(candidates) == 1:
        return candidates[0], "single_non_exact", candidates
    if len(candidates) > 1:
        return None, "ambiguous", candidates
    return None, "none", []


def parse_codeweavers_search(document: str) -> list[dict[str, str]]:
    parser = CodeWeaversSearchParser()
    parser.feed(document)
    return unique_dicts(parser.results, "url")


def parse_codeweavers_search_rows(document: str) -> list[dict[str, Any]]:
    """Parse application links plus Mac rating metadata from search results."""

    parser = CodeWeaversSearchRowParser()
    parser.feed(document)
    return unique_dicts(parser.rows, "url")


def _walk_jsonld(document: Any) -> Iterable[dict[str, Any]]:
    if isinstance(document, dict):
        graph = document.get("@graph")
        if isinstance(graph, list):
            for item in graph:
                if isinstance(item, dict):
                    yield item
        yield document
    elif isinstance(document, list):
        for item in document:
            if isinstance(item, dict):
                yield item


def parse_codeweavers_detail(document: str, url: str) -> dict[str, Any]:
    parser = JsonLdParser()
    parser.feed(document)
    breakdown_parser = CodeWeaversBreakdownParser()
    breakdown_parser.feed(document)
    nodes = [node for doc in parser.documents for node in _walk_jsonld(doc)]
    game = next((node for node in nodes if node.get("@type") == "VideoGame"), {})
    mac_reviews = list(
        (
            node
            for node in nodes
            if node.get("@type") == "Review"
            and "macos" in str(node.get("reviewAspect", "")).casefold()
            and "linux" not in str(node.get("reviewAspect", "")).casefold()
        ),
    )
    # Multiple Mac reviews need version/freshness reconciliation, never first-hit
    # selection. Leave evidence pending rather than inventing a canonical rank.
    review = mac_reviews[0] if len(mac_reviews) == 1 else {}
    raw_rating = (review.get("reviewRating") or {}).get("ratingValue")
    try:
        number = float(raw_rating) if raw_rating is not None and not isinstance(raw_rating, bool) else None
        rating = int(number) if number is not None and number.is_integer() and 1 <= number <= 5 else None
    except (TypeError, ValueError):
        rating = None
    publisher = game.get("publisher") or {}
    about = review.get("about") or {}
    macos_breakdowns = [
        row for row in breakdown_parser.rows if row.get("platform") == "macos"
    ][:3]
    return {
        "name": game.get("name"),
        "publisher": publisher.get("name") if isinstance(publisher, dict) else None,
        "url": game.get("url") or url,
        "rating": rating,
        "rating_label": RATING_LABELS.get(rating),
        "last_tested_date": review.get("datePublished"),
        "last_tested_version": about.get("softwareVersion") if isinstance(about, dict) else None,
        "same_as": game.get("sameAs") or [],
        "feedback_breakdowns": macos_breakdowns,
        "_csrf_token": extract_codeweavers_csrf(document),
        "user_feedback": [],
    }


def extract_balanced_template(wikitext: str, template_name: str) -> Optional[str]:
    match = re.search(r"\{\{\s*" + re.escape(template_name) + r"\b", wikitext, re.IGNORECASE)
    if not match:
        return None
    index = match.start()
    depth = 0
    cursor = index
    while cursor < len(wikitext) - 1:
        pair = wikitext[cursor : cursor + 2]
        if pair == "{{":
            depth += 1
            cursor += 2
            continue
        if pair == "}}":
            depth -= 1
            cursor += 2
            if depth == 0:
                return wikitext[index:cursor]
            continue
        cursor += 1
    return None


def parse_template_fields(template: str) -> dict[str, str]:
    body = template.split("\n", 1)[1] if "\n" in template else template
    body = re.sub(r"\}\}\s*$", "", body)
    pattern = re.compile(
        r"^\|\s*([^=\n]+?)\s*=\s*(.*?)(?=^\|\s*[^=\n]+?\s*=|\Z)",
        re.MULTILINE | re.DOTALL,
    )
    fields: dict[str, str] = {}
    for match in pattern.finditer(body):
        key = compact_whitespace(match.group(1)).casefold()
        fields[key] = match.group(2).strip()
    return fields


def remove_nested_templates(value: str) -> str:
    previous = None
    while value != previous:
        previous = value
        value = re.sub(r"\{\{[^{}]*\}\}", " ", value, flags=re.DOTALL)
    return value


def wikitext_to_text(value: str) -> str:
    value = re.sub(r"<ref\b[^>]*>.*?</ref>", " ", value, flags=re.IGNORECASE | re.DOTALL)
    value = re.sub(r"<ref\b[^>]*/>", " ", value, flags=re.IGNORECASE)
    value = remove_nested_templates(value)
    value = re.sub(r"\[\[([^\]|]+)\|([^\]]+)\]\]", r"\2", value)
    value = re.sub(r"\[\[([^\]]+)\]\]", r"\1", value)
    value = re.sub(r"\[(https?://\S+)\s+([^\]]+)\]", r"\2", value)
    value = re.sub(r"\[(https?://[^\]]+)\]", r"\1", value)
    value = re.sub(r"<[^>]+>", " ", value)
    value = value.replace("'''", "").replace("''", "")
    return compact_whitespace(html.unescape(value))


def newest_date_in_wikitext(value: str) -> Optional[str]:
    dates = re.findall(r"\|\s*date\s*=\s*(\d{4}-\d{2}-\d{2})", value, re.IGNORECASE)
    return max(dates) if dates else None


def normalize_status(value: Optional[str]) -> str:
    return compact_whitespace(wikitext_to_text(value or "")).casefold()


def parse_agw_compatibility(wikitext: str, page_title: str, page_timestamp: Optional[str]) -> dict[str, Any]:
    template = extract_balanced_template(wikitext, "Compatibility/macOS")
    fields = parse_template_fields(template) if template else {}
    raw_notes = {
        "native": fields.get("native notes", ""),
        "rosetta_2": fields.get("rosetta 2 notes", ""),
        "crossover": fields.get("crossover notes", ""),
    }
    combined = "\n".join(raw_notes.values()) + "\n" + wikitext
    return {
        "page_title": page_title,
        "url": AGW_ROOT + quote(page_title.replace(" ", "_"), safe=":_()-"),
        "page_timestamp": page_timestamp,
        "latest_report_date": newest_date_in_wikitext(combined),
        "native_report_date": newest_date_in_wikitext(
            "\n".join((raw_notes["native"], raw_notes["rosetta_2"]))
        ),
        "crossover_report_date": newest_date_in_wikitext(raw_notes["crossover"]),
        "native_status": normalize_status(fields.get("native")),
        "native_notes": wikitext_to_text(raw_notes["native"]),
        "rosetta_2_status": normalize_status(fields.get("rosetta 2")),
        "rosetta_2_notes": wikitext_to_text(raw_notes["rosetta_2"]),
        "crossover_status": normalize_status(fields.get("crossover")),
        "crossover_notes": wikitext_to_text(raw_notes["crossover"]),
        "raw_crossover_notes": raw_notes["crossover"],
        "raw_wikitext": wikitext,
    }


def parse_date(value: Optional[str]) -> Optional[datetime]:
    if not value:
        return None
    cleaned = value.strip().replace("Z", "+00:00")
    try:
        result = datetime.fromisoformat(cleaned)
    except ValueError:
        try:
            result = datetime.strptime(cleaned[:10], "%Y-%m-%d")
        except ValueError:
            return None
    if result.tzinfo is None:
        result = result.replace(tzinfo=timezone.utc)
    return result.astimezone(timezone.utc)


def is_stale(value: Optional[str], checked_at: datetime) -> bool:
    parsed = parse_date(value)
    return bool(parsed and (checked_at - parsed).days > STALE_DAYS)


def downgrade_confidence(confidence: str, steps: int = 1) -> str:
    try:
        index = CONFIDENCE_ORDER.index(confidence)
    except ValueError:
        return "low"
    return CONFIDENCE_ORDER[max(0, index - steps)]


def compare_dates(left: Optional[str], right: Optional[str]) -> int:
    """Return 1 when left is decisively newer, -1 for right, otherwise 0."""

    left_date = parse_date(left)
    right_date = parse_date(right)
    if not left_date or not right_date:
        return 0
    delta = (left_date - right_date).days
    if delta >= CONFLICT_MARGIN_DAYS:
        return 1
    if delta <= -CONFLICT_MARGIN_DAYS:
        return -1
    return 0


def status_signal(status: Optional[str]) -> Optional[str]:
    normalized = normalize_status(status)
    if normalized in POSITIVE_STATUSES:
        return "positive"
    if normalized in NEGATIVE_STATUSES:
        return "negative"
    return None


def split_source_sentences(notes: str) -> list[str]:
    return [compact_whitespace(part) for part in re.split(r"(?<=[.!?。！？])\s+", notes) if part.strip()]


def extract_settings(notes: str) -> list[str]:
    keywords = ("d3dmetal", "dxmt", "dxvk", "msync", "esync", "gptk", "cxpatcher", "graphics backend")
    settings: list[str] = []
    for sentence in split_source_sentences(notes):
        if any(keyword in sentence.casefold() for keyword in keywords):
            settings.append(sentence[:500])
    return list(dict.fromkeys(settings))[:6]


def build_setting_advice(
    notes: str,
    source_url: str,
    source_date: Optional[str],
    checked_at: datetime,
    *,
    source: str = "AppleGamingWiki",
    source_type: str = "community_database",
    source_version: Optional[str] = None,
    source_author: Optional[str] = None,
) -> list[dict[str, Any]]:
    """Tag raw community settings so renderers do not present them as defaults."""

    backend_metadata = {
        "dxvk": ("DXVK", "graphics_backend", "Direct3D 10/11", "bottle"),
        "d3dmetal": ("D3DMetal", "graphics_backend", "Direct3D 11/12", "bottle"),
        "dxmt": ("DXMT", "graphics_backend", "Direct3D 11", "bottle"),
        "msync": ("MSync", "synchronization", None, "bottle"),
        "esync": ("ESync", "synchronization", None, "bottle"),
        "gptk": ("GPTK", "translation_layer", None, "method"),
        "cxpatcher": ("CXPatcher", "patch", None, "bottle"),
        "graphics backend": ("graphics backend", "graphics_backend", None, "bottle"),
    }
    stale = is_stale(source_date, checked_at)
    advice: list[dict[str, Any]] = []
    for raw_text in extract_settings(notes):
        lowered = raw_text.casefold()
        matched_tokens = [token for token in backend_metadata if token in lowered]
        for matched in matched_tokens:
            display_name, kind, api_scope, setting_scope = backend_metadata[matched]
            advice.append(
                {
                    "setting": display_name,
                    "kind": kind,
                    "api_scope": api_scope,
                    "scope": setting_scope,
                    "guidance_level": "stale_community_tip" if stale else "community_tip",
                    "mandatory": False,
                    "raw_text": raw_text,
                    "source": source,
                    "source_type": source_type,
                    "source_url": source_url,
                    "source_date": source_date,
                    "source_version": source_version,
                    "source_author": source_author,
                }
            )
    return advice


def extract_risks(notes: str, source_url: str) -> list[dict[str, str]]:
    lowered = notes.casefold()
    risks: list[dict[str, str]] = []
    if any(token in lowered for token in ("anti-cheat", "anticheat", "easy anti-cheat", "vanguard", "battleye")):
        risks.append(
            {
                "kind": "anti_cheat",
                "severity": "high",
                "message": "Source notes an anti-cheat limitation; verify whether the required online mode works.",
                "source": source_url,
            }
        )
    if any(token in lowered for token in ("offline only", "online functionality unavailable", "online mode unavailable")):
        risks.append(
            {
                "kind": "online_play",
                "severity": "high",
                "message": "Source reports that online functionality is unavailable; treat the game as offline-only.",
                "source": source_url,
            }
        )
    if "launcher" in lowered and any(token in lowered for token in ("fail", "broken", "crash", "does not", "unable")):
        risks.append(
            {
                "kind": "launcher",
                "severity": "medium",
                "message": "Source reports a launcher-related failure or workaround.",
                "source": source_url,
            }
        )
    if any(token in lowered for token in ("low framerate", "low frame rate", "stutter", "resolution issues", "crash")):
        risks.append(
            {
                "kind": "performance",
                "severity": "medium",
                "message": "Source reports performance, resolution, stuttering, or crash limitations.",
                "source": source_url,
            }
        )
    return risks


def add_stale_risk(risks: list[dict[str, str]], source: str, date: Optional[str]) -> None:
    if not date:
        return
    risks.append(
        {
            "kind": "stale_evidence",
            "severity": "medium",
            "message": f"The decisive evidence from {date[:10]} is older than 18 months.",
            "source": source,
        }
    )


def classify(
    native: dict[str, Any],
    crossover: dict[str, Any],
    agw: Optional[dict[str, Any]],
    checked_at: datetime,
    match_kind: str,
    errors: list[dict[str, str]],
    risks: list[dict[str, str]],
) -> tuple[str, str, str, list[dict[str, str]]]:
    if native.get("available") is True:
        if native.get("rosetta_required"):
            detail = "official_mac_rosetta"
        elif native.get("architecture") == "apple_silicon":
            detail = "apple_silicon_native"
        else:
            detail = "official_mac_arch_unknown"
        confidence = "high" if native.get("steam_mac") else "medium"
        if match_kind == "single_non_exact":
            confidence = downgrade_confidence(confidence)
        if len(errors) >= 2:
            confidence = downgrade_confidence(confidence)
        return "native_mac", detail, confidence, risks

    rating = crossover.get("rating")
    cw_signal: Optional[str] = None
    cw_detail: Optional[str] = None
    if isinstance(rating, int):
        if rating >= 4:
            cw_signal, cw_detail = "positive", "recommended"
        elif rating == 3:
            cw_signal, cw_detail = "positive", "limited"
        elif rating <= 2:
            cw_signal, cw_detail = "negative", "not_playable"

    agw_signal = status_signal(agw.get("crossover_status")) if agw else None
    agw_date = None
    if agw:
        agw_date = agw.get("crossover_report_date") or agw.get("page_timestamp")
    cw_date = crossover.get("last_tested_date")

    decisive_source = "codeweavers"
    signal = cw_signal
    detail = cw_detail

    if cw_signal and agw_signal and cw_signal != agw_signal:
        newer = compare_dates(cw_date, agw_date)
        if newer > 0:
            signal, decisive_source = cw_signal, "codeweavers"
        elif newer < 0:
            signal, decisive_source = agw_signal, "applegamingwiki"
            detail = "recommended" if agw_signal == "positive" else "not_playable"
        else:
            risks.append(
                {
                    "kind": "conflicting_evidence",
                    "severity": "high",
                    "message": "CodeWeavers and AppleGamingWiki provide conflicting compatibility results without a decisive date gap.",
                    "source": crossover.get("url") or (agw or {}).get("url") or "",
                }
            )
            return "unavailable_or_unknown", "unknown", "low", risks
    elif not signal and agw_signal:
        signal, decisive_source = agw_signal, "applegamingwiki"
        detail = "recommended" if agw_signal == "positive" else "not_playable"

    if signal is None:
        return "unavailable_or_unknown", "unknown", "low", risks

    decisive_date = cw_date if decisive_source == "codeweavers" else agw_date
    decisive_url = crossover.get("url") if decisive_source == "codeweavers" else (agw or {}).get("url")
    stale = is_stale(decisive_date, checked_at)
    if stale:
        add_stale_risk(risks, decisive_url or decisive_source, decisive_date)

    if signal == "negative":
        confidence = "high" if decisive_source == "codeweavers" and not stale else "medium"
        verdict, detail = "unavailable_or_unknown", "not_playable"
    else:
        if decisive_source == "codeweavers":
            confidence = "high" if rating in (4, 5) else "medium"
        else:
            confidence = "medium" if agw_date else "low"
        verdict = "crossover"
        detail = detail or "recommended"

    if stale or match_kind == "single_non_exact":
        confidence = downgrade_confidence(confidence)
    if len(errors) >= 2:
        confidence = downgrade_confidence(confidence)
    return verdict, detail, confidence, risks


def make_url(base: str, params: dict[str, Any]) -> str:
    return base + "?" + urlencode(params)


def safe_error(source: str, exc: Exception) -> dict[str, str]:
    message = compact_whitespace(str(exc))[:300] or exc.__class__.__name__
    return {"source": source, "error": message}


def empty_codeweavers() -> dict[str, Any]:
    return {
        "rating": None,
        "rating_label": None,
        "last_tested_version": None,
        "last_tested_date": None,
        "url": None,
        "feedback_breakdowns": [],
        "user_feedback": [],
    }


def fetch_steam_searches(client: Any, game: str) -> dict[str, Any]:
    locales = ["english"]
    if contains_cjk(game):
        locales = ["english", "schinese", "tchinese"]
    urls = {
        locale: make_url(STEAM_SEARCH, {"term": game, "l": locale, "cc": "US"})
        for locale in locales
    }
    payloads: dict[str, Any] = {}
    failures: list[Exception] = []
    with ThreadPoolExecutor(max_workers=len(locales)) as executor:
        future_locales = {
            executor.submit(client.get_json, url): locale for locale, url in urls.items()
        }
        for future in as_completed(future_locales):
            locale = future_locales[future]
            try:
                payloads[locale] = future.result()
            except Exception as exc:
                failures.append(exc)

    merged: dict[Any, dict[str, Any]] = {}
    order: list[Any] = []
    for locale in locales:
        payload = payloads.get(locale) or {}
        for item in payload.get("items", []):
            if item.get("type") != "app":
                continue
            marker = item.get("id") or (locale, normalize_title(str(item.get("name", ""))))
            if marker not in merged:
                merged[marker] = dict(item)
                merged[marker]["aliases"] = []
                order.append(marker)
            name = compact_whitespace(str(item.get("name") or ""))
            if name and name not in merged[marker]["aliases"]:
                merged[marker]["aliases"].append(name)
            if locale == "english" and name:
                merged[marker]["name"] = name

    errors: list[dict[str, str]] = []
    # Steam's JSON endpoint often indexes only the English title.  For a CJK
    # query, fall back to the public localized search page, which carries the
    # same app id and localized display name.  This keeps nickname/localized
    # title resolution live and avoids a hard-coded alias list.
    if not merged and contains_cjk(game):
        web_urls = [
            make_url(STEAM_WEB_SEARCH, {"term": game, "l": "schinese", "cc": "US"}),
            make_url(STEAM_WEB_SEARCH, {"term": game, "l": "tchinese", "cc": "US"}),
        ]
        web_failures: list[Exception] = []
        for web_url in web_urls:
            try:
                for item in parse_steam_web_search(client.get_text(web_url)):
                    marker = item.get("id")
                    if marker not in merged:
                        merged[marker] = dict(item)
                        order.append(marker)
            except Exception as exc:
                web_failures.append(exc)
        if web_failures and not merged:
            errors.append(safe_error("steam_web_search", web_failures[0]))
    if failures and not payloads:
        errors.append(safe_error("steam_search", failures[0]))
    elif failures:
        errors.append(safe_error("steam_search_partial", failures[0]))
    return {
        "items": [merged[marker] for marker in order],
        "urls": list(urls.values()),
        "errors": errors,
    }


def fetch_steam_details(client: Any, selected: dict[str, Any]) -> dict[str, Any]:
    app_id = selected.get("id")
    url = make_url(STEAM_DETAILS, {"appids": app_id, "l": "english", "cc": "US"})
    try:
        payload = client.get_json(url)
        entry = payload.get(str(app_id), {})
        return {"details": entry.get("data") or {} if entry.get("success") else None, "errors": []}
    except Exception as exc:
        return {"details": None, "errors": [safe_error("steam_details", exc)]}


def codeweavers_recovery_plan(title: str) -> dict[str, Any]:
    """A guessed slug is a discovery target, never proof of an identity match."""
    slug = re.sub(r"[^a-z0-9]+", "-", title.casefold()).strip("-")
    url = ("https://www.codeweavers.com/compatibility/crossover/" + slug
           if slug and title.isascii() else None)
    return {
        "title": title,
        "candidate_url": url,
        "queries": [
            f'site:codeweavers.com/compatibility/crossover "{title}"',
            *([f'site:{url.split("https://www.", 1)[1]} "Mac Rating"',
               f'site:{url.split("https://www.", 1)[1]} "{title}"'] if url else []),
        ],
        "requires_official_english_title": not bool(url),
    }


def fetch_codeweavers(client: Any, canonical: str, checked_iso: str) -> dict[str, Any]:
    result = empty_codeweavers()
    errors: list[dict[str, str]] = []
    prefetched = None
    search_url = make_url(CODEWEAVERS_SEARCH, {"search": "app", "name": canonical})
    try:
        document = client.get_text(search_url)
        # Keep row metadata for discovery; only the detail Mac review supplies
        # the canonical rating, version and test date.
        items = parse_codeweavers_search_rows(document)
        if not items:
            items = parse_codeweavers_search(document)
    except Exception as exc:
        errors.append(safe_error("codeweavers_search", exc))
        items = []

    selected, match_kind, all_items = choose_candidate(canonical, items)
    if not selected:
        direct_url = codeweavers_recovery_plan(canonical)["candidate_url"]
        if direct_url:
            try:
                document = client.get_text(direct_url)
                direct = parse_codeweavers_detail(document, direct_url)
                if normalize_title(direct.get("name") or "") == normalize_title(canonical):
                    selected = {"name": direct["name"], "url": direct_url}
                    match_kind = "exact"
                    all_items = [selected]
                    prefetched = document
                else:
                    errors.append({"source": "codeweavers_direct", "error": "Direct-page title mismatch; not compatibility evidence"})
            except Exception as exc:
                errors.append(safe_error("codeweavers_direct", exc))
    sources: list[dict[str, Any]] = []
    if selected:
        try:
            detail_document = prefetched if prefetched is not None else client.get_text(selected["url"])
            result = parse_codeweavers_detail(detail_document, selected["url"])
            if normalize_title(result.get("name") or "") != normalize_title(selected["name"]):
                result = empty_codeweavers()
                raise ValueError("Detail page identity differs from selected game")
            csrf_token = result.get("_csrf_token")
            breakdowns = [
                item
                for item in result.get("feedback_breakdowns") or []
                if csrf_token and item.get("cache_id")
            ]
            feedback_by_index: dict[int, list[dict[str, Any]]] = {}
            feedback_errors: list[Exception] = []

            def fetch_feedback(index: int, breakdown: dict[str, Any]) -> tuple[int, list[dict[str, Any]]]:
                feedback_url = CODEWEAVERS_BREAKDOWN + str(breakdown["cache_id"])
                payload = client.get_json(
                    feedback_url,
                    headers={
                        "Accept": "application/json, text/javascript, */*; q=0.01",
                        "Referer": selected["url"],
                        "X-CSRF-Token": str(csrf_token),
                        "X-Requested-With": "XMLHttpRequest",
                    },
                )
                return index, parse_codeweavers_user_feedback(
                    payload,
                    breakdown.get("version"),
                    result.get("url") or selected["url"],
                )

            if breakdowns:
                with ThreadPoolExecutor(max_workers=len(breakdowns)) as executor:
                    futures = {
                        executor.submit(fetch_feedback, index, breakdown): index
                        for index, breakdown in enumerate(breakdowns)
                    }
                    for future in as_completed(futures):
                        try:
                            index, feedback = future.result()
                            feedback_by_index[index] = feedback
                        except Exception as exc:
                            feedback_errors.append(exc)
                for index in range(len(breakdowns)):
                    if feedback_by_index.get(index):
                        result["user_feedback"] = feedback_by_index[index]
                        break
                if not result.get("user_feedback") and feedback_errors:
                    errors.append(safe_error("codeweavers_feedback", feedback_errors[0]))

            sources.append(
                {
                    "name": "CodeWeavers Compatibility Center",
                    "url": result.get("url") or selected["url"],
                    "kind": "official_compatibility",
                    "checked_at": checked_iso,
                    "date": result.get("last_tested_date"),
                }
            )
        except Exception as exc:
            errors.append(safe_error("codeweavers_detail", exc))
            # Preserve table metadata without promoting it to a Mac review.
            table_rating = selected.get("rating")
            if isinstance(table_rating, int):
                result = {
                    "name": selected.get("name"),
                    "publisher": None,
                    "url": selected.get("url"),
                    "rating": None,
                    "rating_label": None,
                    "search_table_rating": table_rating,
                    "search_table_updated": selected.get("last_updated"),
                    "last_tested_date": None,
                    "last_tested_version": None,
                    "same_as": [],
                    "feedback_breakdowns": [],
                    "_csrf_token": None,
                    "user_feedback": [],
                }
                sources.append(
                    {
                        "name": "CodeWeavers Compatibility Center",
                        "url": selected.get("url"),
                        "kind": "official_compatibility_search",
                        "checked_at": checked_iso,
                        "date": selected.get("last_updated"),
                    }
                )
    return {
        "data": result,
        "selected": selected,
        "match_kind": match_kind,
        "candidates": all_items,
        "sources": sources,
        "errors": errors,
    }


def fetch_applegamingwiki(client: Any, canonical: str, checked_iso: str) -> dict[str, Any]:
    search_url = make_url(
        AGW_API,
        {
            "action": "query",
            "list": "search",
            "srsearch": canonical,
            "srnamespace": 0,
            "srlimit": 8,
            "format": "json",
            "formatversion": 2,
        },
    )
    try:
        payload = client.get_json(search_url)
        items = [
            {
                "name": item.get("title"),
                "pageid": item.get("pageid"),
                "timestamp": item.get("timestamp"),
            }
            for item in (payload.get("query") or {}).get("search", [])
        ]
    except Exception as exc:
        return {
            "data": None,
            "selected": None,
            "match_kind": "none",
            "candidates": [],
            "sources": [],
            "errors": [safe_error("applegamingwiki_search", exc)],
        }

    selected, match_kind, all_items = choose_candidate(canonical, items)
    agw: Optional[dict[str, Any]] = None
    errors: list[dict[str, str]] = []
    sources: list[dict[str, Any]] = []
    if selected:
        parse_url = make_url(
            AGW_API,
            {
                "action": "parse",
                "page": selected["name"],
                "prop": "wikitext",
                "format": "json",
                "formatversion": 2,
            },
        )
        try:
            parsed = client.get_json(parse_url)
            wikitext = (parsed.get("parse") or {}).get("wikitext")
            if isinstance(wikitext, str):
                agw = parse_agw_compatibility(
                    wikitext,
                    selected["name"],
                    selected.get("timestamp"),
                )
                sources.append(
                    {
                        "name": "AppleGamingWiki",
                        "url": agw["url"],
                        "kind": "community_compatibility",
                        "checked_at": checked_iso,
                        "date": agw.get("latest_report_date") or agw.get("page_timestamp"),
                    }
                )
        except Exception as exc:
            errors.append(safe_error("applegamingwiki_page", exc))
    return {
        "data": agw,
        "selected": selected,
        "match_kind": match_kind,
        "candidates": all_items,
        "sources": sources,
        "errors": errors,
    }


def collect_game(
    game: str,
    chip: str = "Apple Silicon (M-series)",
    macos: str = "current macOS",
    memory_gb: Optional[int] = None,
    client: Optional[HttpClient] = None,
    checked_at: Optional[datetime] = None,
    use_cache: bool = True,
    refresh: bool = False,
    total_timeout: float = TOTAL_TIMEOUT_SECONDS,
    cache_dir: Optional[Path] = None,
) -> dict[str, Any]:
    caller_supplied_client = client is not None
    cache_allowed = (
        use_cache
        and checked_at is None
        and (not caller_supplied_client or cache_dir is not None)
    )
    cache_root = Path(cache_dir) if cache_dir is not None else default_cache_dir()
    cache_path = cache_root / f"{cache_key(game, chip, macos, memory_gb)}.json"
    if cache_allowed and not refresh:
        cached = load_cached_result(cache_path)
        if cached is not None:
            apply_retrieval_gate(cached)
            cached["answer_sources"] = answer_sources(cached)
            return cached

    checked = checked_at or utc_now()
    checked_iso = checked.replace(microsecond=0).isoformat().replace("+00:00", "Z")
    client = client or HttpClient()
    if isinstance(client, HttpClient):
        client.start_budget(total_timeout)

    def finish(result: dict[str, Any]) -> dict[str, Any]:
        apply_retrieval_gate(result)
        result["answer_sources"] = answer_sources(result)
        ttl = result_cache_ttl(result)
        result["cache"] = {
            "hit": False,
            "age_seconds": 0,
            "ttl_seconds": ttl,
        }
        if cache_allowed and ttl > 0:
            store_cached_result(cache_path, result, ttl)
        return result

    errors: list[dict[str, str]] = []
    sources: list[dict[str, Any]] = []
    candidates: list[dict[str, Any]] = []
    steam_selected: Optional[dict[str, Any]] = None
    steam_details: Optional[dict[str, Any]] = None
    match_kind = "none"

    steam_search = fetch_steam_searches(client, game)
    errors.extend(steam_search["errors"])
    steam_selected, match_kind, steam_all = choose_candidate(
        game, steam_search["items"]
    )
    candidates.extend(
        {
            "source": "Steam",
            "title": item.get("name"),
            "id": item.get("id"),
            "url": f"https://store.steampowered.com/app/{item.get('id')}",
        }
        for item in steam_all[:8]
    )
    if match_kind == "ambiguous":
        return finish(
            {
                "query": game,
                "matched_game": None,
                "device": {"chip": chip, "memory_gb": memory_gb, "macos": macos},
                "verdict": "unavailable_or_unknown",
                "verdict_detail": "ambiguous",
                "confidence": "low",
                "native": {
                    "available": None,
                    "architecture": "unknown",
                    "rosetta_required": None,
                    "steam_mac": None,
                    "evidence": [],
                },
                "crossover": {
                    "rating": None,
                    "rating_label": None,
                    "last_tested_version": None,
                    "last_tested_date": None,
                    "agw_status": None,
                    "settings": [],
                    "setting_advice": [],
                    "notes": [],
                    "user_feedback": [],
                    "evidence": [],
                },
                "risks": [],
                "candidates": candidates,
                "sources": [
                    {
                        "name": "Steam Store Search",
                        "url": steam_search["urls"][0],
                        "checked_at": checked_iso,
                    }
                ],
                "errors": errors,
                "checked_at": checked_iso,
            }
        )

    canonical = (steam_selected or {}).get("name") or game
    initial_canonical = canonical
    codeweavers_result: dict[str, Any] = {
        "data": empty_codeweavers(),
        "selected": None,
        "match_kind": "none",
        "candidates": [],
        "sources": [],
        "errors": [],
    }
    agw_result: dict[str, Any] = {
        "data": None,
        "selected": None,
        "match_kind": "none",
        "candidates": [],
        "sources": [],
        "errors": [],
    }

    with ThreadPoolExecutor(max_workers=3) as executor:
        futures: dict[Any, str] = {
            executor.submit(
                fetch_codeweavers, client, canonical, checked_iso
            ): "codeweavers",
            executor.submit(
                fetch_applegamingwiki, client, canonical, checked_iso
            ): "applegamingwiki",
        }
        if steam_selected:
            futures[executor.submit(fetch_steam_details, client, steam_selected)] = (
                "steam_details"
            )
        for future in as_completed(futures):
            label = futures[future]
            try:
                payload = future.result()
            except Exception as exc:
                errors.append(safe_error(label, exc))
                continue
            if label == "codeweavers":
                codeweavers_result = payload
            elif label == "applegamingwiki":
                agw_result = payload
            else:
                steam_details = payload["details"]
                errors.extend(payload["errors"])

    codeweavers = codeweavers_result["data"]
    cw_selected = codeweavers_result["selected"]
    cw_match_kind = codeweavers_result["match_kind"]
    agw = agw_result["data"]
    agw_match_kind = agw_result["match_kind"]
    errors.extend(codeweavers_result["errors"])
    errors.extend(agw_result["errors"])
    sources.extend(codeweavers_result["sources"])
    sources.extend(agw_result["sources"])
    candidates.extend(
        {
            "source": "CodeWeavers",
            "title": item.get("name"),
            "id": None,
            "url": item.get("url"),
        }
        for item in codeweavers_result["candidates"][:8]
    )
    candidates.extend(
        {
            "source": "AppleGamingWiki",
            "title": item.get("name"),
            "id": item.get("pageid"),
            "url": AGW_ROOT
            + quote(str(item.get("name", "")).replace(" ", "_"), safe=":_()-"),
        }
        for item in agw_result["candidates"][:8]
    )
    if not steam_selected and cw_match_kind != "none":
        match_kind = cw_match_kind
    if (
        not steam_selected
        and match_kind == "none"
        and agw_match_kind != "none"
    ):
        match_kind = agw_match_kind

    if steam_details is not None and steam_selected:
        sources.append(
            {
                "name": "Steam Store",
                "url": f"https://store.steampowered.com/app/{steam_selected.get('id')}",
                "kind": "official_store",
                "checked_at": checked_iso,
                "date": (steam_details.get("release_date") or {}).get("date"),
            }
        )

    resolved_canonical = (
        codeweavers.get("name")
        or (cw_selected or {}).get("name")
        or (agw or {}).get("page_title")
    )
    if (
        not steam_selected
        and resolved_canonical
        and normalize_title(resolved_canonical) != normalize_title(canonical)
    ):
        canonical = resolved_canonical
        alias_search = fetch_steam_searches(client, canonical)
        errors.extend(alias_search["errors"])
        alias_selected, alias_match_kind, alias_all = choose_candidate(
            canonical, alias_search["items"]
        )
        candidates.extend(
            {
                "source": "Steam",
                "title": item.get("name"),
                "id": item.get("id"),
                "url": f"https://store.steampowered.com/app/{item.get('id')}",
            }
            for item in alias_all[:8]
        )
        if alias_selected and alias_match_kind != "ambiguous":
            steam_selected = alias_selected
            detail_result = fetch_steam_details(client, steam_selected)
            steam_details = detail_result["details"]
            errors.extend(detail_result["errors"])
            if steam_details is not None:
                sources.append(
                    {
                        "name": "Steam Store",
                        "url": f"https://store.steampowered.com/app/{steam_selected.get('id')}",
                        "kind": "official_store",
                        "checked_at": checked_iso,
                        "date": (steam_details.get("release_date") or {}).get("date"),
                    }
                )

    canonical = (
        (steam_details or {}).get("name")
        or (steam_selected or {}).get("name")
        or canonical
    )
    # The localized Steam search result can resolve a Chinese display name,
    # while CodeWeavers indexes the English title.  Retry the compatibility
    # lookup with Steam's authoritative English name before classifying.
    if (
        codeweavers.get("rating") is None
        and steam_details
        and normalize_title(canonical) != normalize_title(initial_canonical)
    ):
        retry_cw = fetch_codeweavers(client, canonical, checked_iso)
        errors.extend(retry_cw["errors"])
        sources.extend(retry_cw["sources"])
        candidates.extend(
            {
                "source": "CodeWeavers",
                "title": item.get("name"),
                "id": None,
                "url": item.get("url"),
            }
            for item in retry_cw["candidates"][:8]
        )
        if retry_cw.get("selected"):
            codeweavers_result = retry_cw
            codeweavers = retry_cw["data"]
            cw_selected = retry_cw["selected"]
            cw_match_kind = retry_cw["match_kind"]
    if (
        agw is None
        and normalize_title(canonical) != normalize_title(initial_canonical)
    ):
        retry_agw = fetch_applegamingwiki(client, canonical, checked_iso)
        errors.extend(retry_agw["errors"])
        sources.extend(retry_agw["sources"])
        candidates.extend(
            {
                "source": "AppleGamingWiki",
                "title": item.get("name"),
                "id": item.get("pageid"),
                "url": AGW_ROOT
                + quote(
                    str(item.get("name", "")).replace(" ", "_"),
                    safe=":_()-",
                ),
            }
            for item in retry_agw["candidates"][:8]
        )
        if retry_agw["data"] is not None:
            agw = retry_agw["data"]

    steam_mac = None
    if steam_details is not None:
        steam_mac = bool((steam_details.get("platforms") or {}).get("mac"))
    elif steam_selected is not None and "platforms" in steam_selected:
        steam_mac = bool((steam_selected.get("platforms") or {}).get("mac"))

    native_status = (agw or {}).get("native_status", "")
    rosetta_status = (agw or {}).get("rosetta_2_status", "")
    native_positive = status_signal(native_status) == "positive"
    rosetta_positive = status_signal(rosetta_status) == "positive"
    if native_positive:
        native_available: Optional[bool] = True
        architecture = "apple_silicon"
        rosetta_required: Optional[bool] = False
    elif rosetta_positive:
        native_available = True
        architecture = "intel"
        rosetta_required = True
    elif steam_mac is True:
        native_available = True
        architecture = "unknown"
        rosetta_required = None
    elif (
        steam_mac is False
        and native_status in INCONCLUSIVE_STATUSES
        and rosetta_status in INCONCLUSIVE_STATUSES
    ):
        native_available = False
        architecture = "unknown"
        rosetta_required = None
    else:
        native_available = None
        architecture = "unknown"
        rosetta_required = None

    native_evidence: list[dict[str, Any]] = []
    if steam_mac is not None and steam_selected:
        native_evidence.append(
            {
                "source": "Steam Store",
                "mac_build": steam_mac,
                "scope": "Steam build only",
                "url": f"https://store.steampowered.com/app/{steam_selected.get('id')}",
            }
        )
    if agw:
        native_evidence.append(
            {
                "source": "AppleGamingWiki",
                "native_status": native_status or None,
                "rosetta_2_status": rosetta_status or None,
                "url": agw["url"],
                "date": agw.get("native_report_date")
                or agw.get("page_timestamp"),
            }
        )
    native = {
        "available": native_available,
        "architecture": architecture,
        "rosetta_required": rosetta_required,
        "steam_mac": steam_mac,
        "notes": list(
            filter(
                None,
                [
                    (agw or {}).get("native_notes"),
                    (agw or {}).get("rosetta_2_notes"),
                ],
            )
        ),
        "evidence": native_evidence,
    }

    agw_notes = (agw or {}).get("crossover_notes", "")
    if native_available is True:
        agw_risk_text = " ".join(
            filter(
                None,
                [
                    (agw or {}).get("native_notes"),
                    (agw or {}).get("rosetta_2_notes"),
                ],
            )
        )
    else:
        agw_risk_text = agw_notes
    if native_available is not True and agw and agw.get("raw_wikitext"):
        agw_risk_text += " " + agw["raw_wikitext"]
    risks = extract_risks(agw_risk_text, (agw or {}).get("url", ""))
    agw_date = (agw or {}).get("crossover_report_date") or (agw or {}).get("page_timestamp")
    setting_advice = build_setting_advice(
        agw_notes,
        (agw or {}).get("url", ""),
        agw_date,
        checked,
    )
    for feedback in codeweavers.get("user_feedback") or []:
        setting_advice.extend(
            build_setting_advice(
                feedback.get("original_text", ""),
                feedback.get("url", ""),
                feedback.get("date"),
                checked,
                source="CodeWeavers user feedback",
                source_type=feedback.get("source_type") or "customer",
                source_version=feedback.get("crossover_version"),
                source_author=feedback.get("author"),
            )
        )
    crossover = {
        "rating": codeweavers.get("rating"),
        "search_table_rating": codeweavers.get("search_table_rating"),
        "search_table_updated": codeweavers.get("search_table_updated"),
        "rating_label": codeweavers.get("rating_label"),
        "last_tested_version": codeweavers.get("last_tested_version"),
        "last_tested_date": codeweavers.get("last_tested_date"),
        "url": codeweavers.get("url"),
        "agw_status": (agw or {}).get("crossover_status") or None,
        "agw_date": agw_date,
        "settings": extract_settings(agw_notes),
        "setting_advice": setting_advice,
        "notes": [agw_notes] if agw_notes else [],
        "user_feedback": codeweavers.get("user_feedback") or [],
        "evidence": list(
            filter(
                None,
                [
                    {
                        "source": "CodeWeavers Compatibility Center",
                        "rating": codeweavers.get("rating"),
                        "label": codeweavers.get("rating_label"),
                        "version": codeweavers.get("last_tested_version"),
                        "date": codeweavers.get("last_tested_date"),
                        "user_feedback_count": len(
                            codeweavers.get("user_feedback") or []
                        ),
                        "url": codeweavers.get("url"),
                    }
                    if codeweavers.get("url")
                    else None,
                    {
                        "source": "AppleGamingWiki",
                        "status": (agw or {}).get("crossover_status"),
                        "date": (agw or {}).get("crossover_report_date")
                        or (agw or {}).get("page_timestamp"),
                        "url": (agw or {}).get("url"),
                    }
                    if agw
                    else None,
                ],
            )
        ),
    }

    verdict, verdict_detail, confidence, risks = classify(
        native,
        crossover,
        agw,
        checked,
        match_kind,
        errors,
        risks,
    )
    matched_title = (
        (steam_details or {}).get("name")
        or (steam_selected or {}).get("name")
        or codeweavers.get("name")
        or (agw or {}).get("page_title")
        or game
    )
    publishers = (steam_details or {}).get("publishers") or []
    publisher = (
        publishers[0] if publishers else codeweavers.get("publisher")
    )
    return finish(
        {
            "query": game,
            "matched_game": {
                "title": matched_title,
                "publisher": publisher,
                "steam_appid": (steam_selected or {}).get("id"),
                "match_kind": match_kind,
            },
            "device": {
                "chip": chip,
                "memory_gb": memory_gb,
                "macos": macos,
            },
            "verdict": verdict,
            "verdict_detail": verdict_detail,
            "confidence": confidence,
            "native": native,
            "crossover": crossover,
            "risks": risks,
            "candidates": unique_dicts(candidates, "url"),
            "sources": unique_dicts(sources, "url"),
            "errors": errors,
            "checked_at": checked_iso,
        }
    )

def apply_retrieval_gate(result: dict[str, Any]) -> dict[str, Any]:
    """Separate failed evidence retrieval from an actual compatibility verdict."""
    if result.get("verdict_detail") == "ambiguous":
        result["retrieval"] = {"status": "needs_disambiguation", "final_answer_allowed": False}
        return result
    cw = result.get("crossover") or {}
    rating = cw.get("rating")
    cw_checked = isinstance(rating, int) and not isinstance(rating, bool) and 1 <= rating <= 5 and bool(cw.get("url"))
    reasons = []
    if not cw_checked:
        reasons.append("CodeWeavers macOS evidence missing: direct canonical-page and official search-table recovery required")
    elif not cw.get("last_tested_version"):
        reasons.append("Only partial CodeWeavers evidence: recover exact-page Mac rating and last-tested version before finalizing")
    if result.get("verdict_detail") == "unknown":
        reasons.append("No decisive compatible or incompatible evidence")
    pending = bool(reasons)
    result["retrieval"] = {
        "schema_version": 2,
        "status": "recovery_required" if pending else "complete",
        "final_answer_allowed": not pending,
        "codeweavers_mac_checked": bool(cw_checked),
        "reasons": reasons,
        "exact_lookup": codeweavers_recovery_plan((result.get("matched_game") or {}).get("title") or result.get("query") or "") if pending else None,
        "next_actions": ([
            "Retry network access with the host's authorized network capability; do not repeat a sandbox DNS failure unchanged.",
            "Resolve the title through an official store page, then check the exact CodeWeavers detail page and official search table.",
            "If direct access fails, inspect indexed exact-page evidence with the host browser/search; distinguish Mac from Linux ratings.",
            "Check title-specific Tips, Forum and gameplay evidence before drafting; if recovery fails, report uncertainty, never incompatibility.",
        ] if pending else []),
    }
    if pending and result.get("verdict_detail") == "not_playable":
        result["verdict"] = "unavailable_or_unknown"
        result["verdict_detail"] = "unknown"
        result["confidence"] = "low"
    return result


def human_summary(result: dict[str, Any]) -> str:
    apply_retrieval_gate(result)
    if result["retrieval"]["status"] == "recovery_required":
        return "查询未完成：必须继续恢复查询 CodeWeavers。网络失败或未匹配不是不可玩的证据；禁止据此输出不可玩或零星评级。"
    labels = {
        ("native_mac", "apple_silicon_native"): "原生 Mac 版",
        ("native_mac", "official_mac_arch_unknown"): "原生 Mac 版（架构待确认）",
        ("native_mac", "official_mac_rosetta"): "官方 macOS 版，需 Rosetta 2",
        ("crossover", "recommended"): "需要 CrossOver",
        ("crossover", "limited"): "需要 CrossOver，但功能有限",
        ("unavailable_or_unknown", "not_playable"): "当前不可玩",
        ("unavailable_or_unknown", "unknown"): "暂时无法确认",
        ("unavailable_or_unknown", "ambiguous"): "需要确认具体游戏",
    }
    label = labels.get((result.get("verdict"), result.get("verdict_detail")), "暂时无法确认")
    game = (result.get("matched_game") or {}).get("title") or result.get("query")
    rating = (result.get("crossover") or {}).get("rating")
    stars = "★" * int(rating) + "☆" * (5 - int(rating)) if isinstance(rating, int) and 1 <= rating <= 5 else "未评级"
    lines = [f"结果：{label}｜{stars}", f"游戏：{game}"]
    device = result.get("device") or {}
    memory = f"，{device.get('memory_gb')} GB 内存" if device.get("memory_gb") else ""
    lines.append(f"适用设备：{device.get('chip')}，{device.get('macos')}{memory}")
    crossover = result.get("crossover") or {}
    if result.get("verdict") == "crossover":
        version = crossover.get("last_tested_version") or "未记录版本"
        lines.append(f"怎么玩：使用 CrossOver；来源最后测试版本为 {version}。")
    elif result.get("verdict") == "native_mac":
        if (result.get("native") or {}).get("rosetta_required"):
            lines.append("怎么玩：安装官方 macOS 版本，并通过 Rosetta 2 运行；不需要 CrossOver。")
        else:
            lines.append("怎么玩：安装官方 macOS 版本，不需要 CrossOver。")
    else:
        lines.append("怎么玩：先核验缺失或冲突的最新证据，再决定是否安装。")
    risks = result.get("risks") or []
    lines.append("关键限制：" + ("；".join(risk["message"] for risk in risks) if risks else "未发现已记录的关键限制。"))
    feedback = crossover.get("user_feedback") or []
    if feedback:
        lines.append("CodeWeavers 用户反馈原文：")
        for item in feedback:
            rating = f"{item.get('rating')} 星，" if item.get("rating") else ""
            version = item.get("crossover_version") or "版本未记录"
            date = item.get("date") or "日期未记录"
            lines.append(
                f"- {rating}CrossOver {version}，{date}，{item.get('author')}：{item.get('original_text')}"
            )
    confidence_labels = {"high": "高", "medium": "中", "low": "低"}
    lines.append(f"可信度：{confidence_labels.get(result.get('confidence'), '低')}")
    visible_sources = result.get("answer_sources")
    if visible_sources is None:
        visible_sources = answer_sources(result)
    if visible_sources:
        lines.append("来源：")
        for source in visible_sources:
            date = f"（{str(source.get('date'))[:10]}）" if source.get("date") else ""
            lines.append(f"- {source.get('name')}{date}: {source.get('url')}")
    lines.append(f"查询时间：{result.get('checked_at')}")
    return "\n".join(lines)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Check whether a game runs on a Mac.")
    parser.add_argument("--game", required=True, help="Game name in Chinese or English")
    parser.add_argument("--chip", default="Apple Silicon (M-series)", help="Mac chip/model")
    parser.add_argument("--macos", default="current macOS", help="macOS version")
    parser.add_argument("--memory-gb", type=int, default=None, help="Memory in GB")
    parser.add_argument(
        "--refresh",
        action="store_true",
        help="Ignore a valid cached result and query live sources",
    )
    parser.add_argument(
        "--no-cache",
        action="store_true",
        help="Do not read or write the local result cache",
    )
    parser.add_argument(
        "--timeout",
        type=float,
        default=TOTAL_TIMEOUT_SECONDS,
        help=f"Overall live-query budget in seconds (default: {TOTAL_TIMEOUT_SECONDS:g})",
    )
    parser.add_argument("--json", action="store_true", help="Emit normalized JSON")
    return parser


def main(argv: Optional[list[str]] = None) -> int:
    args = build_parser().parse_args(argv)
    result = collect_game(
        args.game,
        args.chip,
        args.macos,
        args.memory_gb,
        use_cache=not args.no_cache,
        refresh=args.refresh,
        total_timeout=max(1.0, args.timeout),
    )
    if args.json:
        json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        print(human_summary(result))
    return 2 if result.get("retrieval", {}).get("status") == "recovery_required" else 0


if __name__ == "__main__":
    raise SystemExit(main())
