#!/usr/bin/env python3
"""Dependency-free installation and portability check for check-mac-game."""

from __future__ import annotations

import argparse
import importlib.util
import json
import os
from pathlib import Path
import shutil
import sys
import tempfile
from typing import Any, Optional


SKILL_ROOT = Path(__file__).resolve().parents[1]
SCRIPT_ROOT = SKILL_ROOT / "scripts"
MINIMUM_PYTHON = (3, 9)
REQUIRED_FILES = (
    "SKILL.md",
    "agents/openai.yaml",
    "assets/share-card-template-v2.html",
    "references/compatibility-rules.md",
    "references/crossover-operations.md",
    "references/recommendation-rules.md",
    "references/share-card.md",
    "references/tutorial-evidence.md",
    "scripts/check_game.py",
    "scripts/crossover_footer_gate.py",
    "scripts/recommend_games.py",
    "scripts/render_share_card.py",
    "scripts/build_share_gallery.py",
    "scripts/capture_share_card.mjs",
    "scripts/portable_preflight.py",
    "scripts/validate_user_response.py",
)
PYTHON_SCRIPTS = tuple(
    path for path in REQUIRED_FILES if path.startswith("scripts/") and path.endswith(".py")
) + ("scripts/self_check.py",)


def compile_scripts() -> list[str]:
    failures: list[str] = []
    for relative in PYTHON_SCRIPTS:
        path = SKILL_ROOT / relative
        try:
            compile(path.read_text(encoding="utf-8"), str(path), "exec")
        except (OSError, SyntaxError, UnicodeError) as exc:
            failures.append(f"{relative}: {exc}")
    return failures


def optional_capabilities() -> dict[str, Any]:
    browser_names = (
        "google-chrome-stable",
        "google-chrome",
        "chromium",
        "chromium-browser",
        "microsoft-edge",
    )
    browser = next((shutil.which(name) for name in browser_names if shutil.which(name)), None)
    try:
        import PIL  # type: ignore  # noqa: F401

        pillow = True
    except ImportError:
        pillow = False
    return {
        "node": shutil.which("node"),
        "browser": browser,
        "pillow": pillow,
        "rsvg_convert": shutil.which("rsvg-convert"),
        "poster_renderer": "run scripts/portable_preflight.py before final poster generation",
    }


def package_hygiene() -> dict[str, Any]:
    generated = sorted(
        str(path.relative_to(SKILL_ROOT))
        for path in SKILL_ROOT.rglob("*")
        if path.name == "__pycache__" or path.suffix in {".pyc", ".pyo"}
    )
    leaks: list[str] = []
    text_suffixes = {".md", ".py", ".mjs", ".yaml", ".yml", ".html"}
    markers = ("/Users/", "C:\\Users\\", ".chatgpt-projects/")
    for path in SKILL_ROOT.rglob("*"):
        if not path.is_file() or path.suffix.lower() not in text_suffixes:
            continue
        if path.resolve() == Path(__file__).resolve():
            continue
        try:
            content = path.read_text(encoding="utf-8")
        except (OSError, UnicodeError):
            continue
        if any(marker in content for marker in markers):
            leaks.append(str(path.relative_to(SKILL_ROOT)))
    return {
        "ok": not generated and not leaks,
        "generated_files": generated,
        "absolute_path_leaks": sorted(leaks),
    }


def online_check(game: str) -> dict[str, Any]:
    module_path = SCRIPT_ROOT / "check_game.py"
    spec = importlib.util.spec_from_file_location("check_mac_game_online_check", module_path)
    if not spec or not spec.loader:
        return {"ok": False, "error": "cannot load collector"}
    module = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    try:
        spec.loader.exec_module(module)
        result = module.collect_game(
            game,
            use_cache=False,
            refresh=True,
            total_timeout=20,
        )
    except Exception as exc:  # network and TLS failures must be reported clearly
        return {"ok": False, "error": str(exc)[:300]}
    sources = result.get("sources") or []
    return {
        "ok": bool(result.get("matched_game") and sources),
        "matched_game": result.get("matched_game"),
        "verdict": result.get("verdict"),
        "source_count": len(sources),
        "errors": result.get("errors") or [],
    }


def run(online_game: Optional[str] = None) -> dict[str, Any]:
    missing = [relative for relative in REQUIRED_FILES if not (SKILL_ROOT / relative).is_file()]
    syntax_failures = compile_scripts() if not missing else []
    temp_write_ok = False
    temp_error = None
    try:
        with tempfile.TemporaryDirectory(prefix="check-mac-game-self-check-") as directory:
            probe = Path(directory) / "probe.txt"
            probe.write_text("ok", encoding="utf-8")
            temp_write_ok = probe.read_text(encoding="utf-8") == "ok"
    except OSError as exc:
        temp_error = str(exc)

    python_ok = sys.version_info[:2] >= MINIMUM_PYTHON
    hygiene = package_hygiene()
    report: dict[str, Any] = {
        "ok": python_ok and not missing and not syntax_failures and temp_write_ok and hygiene["ok"],
        "skill_root": str(SKILL_ROOT),
        "python": {
            "version": ".".join(map(str, sys.version_info[:3])),
            "executable": sys.executable,
            "minimum": ".".join(map(str, MINIMUM_PYTHON)),
            "ok": python_ok,
        },
        "required_files": {"ok": not missing, "missing": missing},
        "syntax": {"ok": not syntax_failures, "failures": syntax_failures},
        "temporary_storage": {"ok": temp_write_ok, "error": temp_error},
        "package_hygiene": hygiene,
        "optional_capabilities": optional_capabilities(),
        "environment": {
            "platform": sys.platform,
            "path_separator": os.sep,
        },
    }
    if online_game:
        report["online"] = online_check(online_game)
        report["ok"] = report["ok"] and report["online"]["ok"]
    return report


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--online-game",
        help="also perform a live no-key query for this exact game title",
    )
    parser.add_argument("--json", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    report = run(args.online_game)
    if args.json:
        json.dump(report, sys.stdout, ensure_ascii=False, indent=2)
        sys.stdout.write("\n")
    else:
        print("check-mac-game structural check: " + ("OK" if report["ok"] else "FAILED"))
        print("Poster renderer: run scripts/portable_preflight.py (a structural pass does not approve poster output)")
        print(f"Python {report['python']['version']} ({report['python']['executable']})")
        if report["required_files"]["missing"]:
            print("Missing: " + ", ".join(report["required_files"]["missing"]))
        if report["syntax"]["failures"]:
            print("Syntax errors: " + "; ".join(report["syntax"]["failures"]))
        if args.online_game:
            print("Online query: " + ("OK" if report["online"]["ok"] else "FAILED"))
    return 0 if report["ok"] else 1


if __name__ == "__main__":
    raise SystemExit(main())
